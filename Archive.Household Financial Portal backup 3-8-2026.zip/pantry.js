const firebaseConfig = {
  apiKey: "AIzaSyCp2GPQWhV_LY1SJKfPFgjpR1f1KqRqh9U",
  authDomain: "homefund-3b81a.firebaseapp.com",
  databaseURL: "https://homefund-3b81a-default-rtdb.firebaseio.com",
  projectId: "homefund-3b81a",
  storageBucket: "homefund-3b81a.firebasestorage.app",
  messagingSenderId: "597780469252",
  appId: "1:597780469252:web:95b8136a4db32111bc4751"
};

if (!firebase.apps.length) firebase.initializeApp(firebaseConfig);
const db = firebase.database();
const auth = firebase.auth();

let currentUser = null;
let pantry = {};
let html5QrcodeScanner = null;
let manualModal = null;
let editPantryModal = null;

const $ = (id) => document.getElementById(id);
const defaultImage = "https://placehold.co/100x100?text=No+Photo";

// Ensure user is logged in
auth.onAuthStateChanged((user) => {
  if (user) {
    currentUser = user.uid;
    db.ref('pantry').on('value', (snap) => {
      pantry = snap.val() || {};
      renderPantry();
      renderCart();
    });
  } else {
    window.location.href = 'index.html';
  }
});

function showToast(msg, type = 'info') {
  const container = $('toast-container');
  const toast = document.createElement('div');
  const map = { success: 'success', danger: 'danger', warning: 'warning', info: 'primary' };
  toast.className = `alert alert-${map[type] || 'primary'} shadow-lg border-0 mb-2 text-white fw-bold`;
  if (type === 'success') toast.style.backgroundColor = 'var(--success)';
  if (type === 'danger') toast.style.backgroundColor = 'var(--danger)';
  toast.style.borderRadius = '8px';
  toast.innerHTML = msg;
  container.appendChild(toast); setTimeout(() => toast.remove(), 3000);
}

// --- RENDER PANTRY ---
function renderPantry() {
  const list = $('pantry-inventory-list');
  const items = Object.entries(pantry).sort((a, b) => a[1].name.localeCompare(b[1].name));

  $('total-items').textContent = `${items.length} Items`;

  if (items.length === 0) {
    list.innerHTML = `<tr><td colspan="2" class="text-center py-5 muted fw-bold fs-5">Pantry is empty. Start adding items!</td></tr>`;
    return;
  }

  list.innerHTML = items.map(([barcode, data]) => `
  <tr>
  <td style="cursor: pointer;" onclick="openEditPantryItem('${barcode}')" title="Click to Edit">
  <div class="d-flex align-items-center gap-3">
  <img src="${data.imageUrl || defaultImage}" style="width: 60px; height: 60px; object-fit: contain; border-radius: 8px; border: 1px solid #dee2e6; background: white; padding: 2px;">
  <div>
  <div class="fw-bold text-dark fs-6 lh-sm mb-1">${data.name} <i class="fa-solid fa-pen ms-1 text-primary opacity-50" style="font-size: 0.8em;"></i></div>
  <div class="d-flex align-items-center gap-2 flex-wrap mt-1">
  <small class="text-muted fw-bold border rounded px-1 bg-light">${barcode}</small>
  ${data.inCart ? `<span class="badge bg-warning text-dark shadow-sm"><i class="fa-solid fa-cart-shopping me-1"></i>In Cart</span>` : ''}
  ${data.price ? `<span class="badge bg-success text-white shadow-sm">$${Number(data.price).toFixed(2)}</span>` : ''}
  </div>
  </div>
  </div>
  </td>
  <td class="text-center" style="vertical-align: middle;">
  <div class="d-flex justify-content-center align-items-center gap-2">
  <button class="btn btn-outline-danger shadow-sm px-3 py-2" onclick="updateQty('${barcode}', -1)"><i class="fa-solid fa-minus"></i></button>
  <div class="text-center mx-2" style="min-width: 50px;">
  <span class="fw-bold fs-4">${data.qty}</span><br>
  <span style="font-size:0.7em; text-transform:uppercase; letter-spacing: 0.5px;" class="text-primary fw-bold">${data.unit || 'UNIT'}</span>
  </div>
  <button class="btn btn-outline-success shadow-sm px-3 py-2" onclick="updateQty('${barcode}', 1)"><i class="fa-solid fa-plus"></i></button>
  </div>
  </td>
  </tr>
  `).join('');
}

// --- RENDER SHOPPING CART ---
function renderCart() {
  const cartList = $('shopping-cart-list');
  const cartItems = Object.entries(pantry).filter(([_, data]) => data.inCart === true);

  $('cart-badge').textContent = cartItems.length;

  let cartTotal = 0;

  if (cartItems.length === 0) {
    cartList.innerHTML = `<div class="text-center text-muted p-4 fw-bold mt-4"><i class="fa-solid fa-basket-shopping fs-1 mb-3 text-secondary opacity-50"></i><br>Your cart is empty.</div>`;
    $('cart-total-display').textContent = "$0.00";
    return;
  }

  cartList.innerHTML = cartItems.map(([barcode, data]) => {
    cartTotal += Number(data.price || 0);

    return `
    <div class="card border-0 shadow-sm rounded-3">
    <div class="card-body p-3 d-flex gap-3 align-items-center">
    <img src="${data.imageUrl || defaultImage}" style="width: 60px; height: 60px; object-fit: contain; border-radius: 8px; border: 1px solid #dee2e6; background: white;">
    <div class="flex-grow-1">
    <div class="fw-bold text-dark lh-sm mb-1">${data.name}</div>
    <div class="d-flex justify-content-between align-items-center">
    <small class="text-muted">Need to buy.</small>
    <span class="fw-bold text-success">${data.price ? '$' + Number(data.price).toFixed(2) : '$0.00'}</span>
    </div>
    </div>
    </div>
    <div class="card-footer bg-white border-top-0 pt-0 pb-3 px-3 d-flex flex-wrap gap-2">
    <button class="btn btn-outline-primary btn-sm fw-bold w-100 mb-1" onclick="comparePrice('${barcode}')"><i class="fa-solid fa-tag me-1"></i> Compare Local Prices</button>
    <button class="btn btn-outline-danger btn-sm fw-bold flex-grow-1" onclick="removeFromCart('${barcode}')">Remove</button>
    <button class="btn btn-success btn-sm fw-bold flex-grow-1" onclick="markAsBought('${barcode}')"><i class="fa-solid fa-check me-1"></i> Bought It</button>
    </div>
    </div>
    `;
  }).join('');

  $('cart-total-display').textContent = "$" + cartTotal.toFixed(2);
}

window.comparePrice = function(barcode) {
  const item = pantry[barcode];
  if (!item) return;
  const query = encodeURIComponent(item.name);
  window.open(`https://www.google.com/search?tbm=shop&q=${query}`, '_blank');
};

window.removeFromCart = async function(barcode) {
  await db.ref(`pantry/${barcode}/inCart`).set(false);
}

window.markAsBought = async function(barcode) {
  const currentQty = pantry[barcode].qty;
  await db.ref(`pantry/${barcode}`).update({
    inCart: false,
    qty: currentQty + 1
  });
  showToast('Item purchased and added to pantry!', 'success');
}

window.updateQty = async function(barcode, change) {
  const item = pantry[barcode];
  if (!item) return;

  const newQty = item.qty + change;
  if (newQty <= 0) {
    if(confirm(`Remove ${item.name} from pantry entirely?`)) {
      await db.ref(`pantry/${barcode}`).remove();
      showToast('Item removed.', 'danger');
    }
  } else {
    await db.ref(`pantry/${barcode}/qty`).set(newQty);
  }
}

// --- SCANNER LOGIC ---
async function onScanSuccess(decodedText) {
  if(window.lastScanned === decodedText) return;
  window.lastScanned = decodedText;

  const statusEl = $('scan-status');
  statusEl.classList.remove('d-none');
  statusEl.className = 'alert alert-warning mt-3 mb-0 fw-bold';
  statusEl.innerHTML = `<i class="fa-solid fa-spinner fa-spin me-2"></i> Looking up ${decodedText}...`;

  if(html5QrcodeScanner) html5QrcodeScanner.pause();

  try {
    if (pantry[decodedText]) {
      await db.ref(`pantry/${decodedText}/qty`).set(pantry[decodedText].qty + 1);
      statusEl.className = 'alert alert-success mt-3 mb-0 fw-bold';
      statusEl.innerHTML = `<i class="fa-solid fa-check me-2"></i> Added +1 to ${pantry[decodedText].name}`;
    } else {
      const response = await fetch(`https://world.openfoodfacts.org/api/v0/product/${decodedText}.json`);
      const data = await response.json();

      let productName = "Unknown Item (Tap to rename)";
      let imageUrl = "";

      if (data.status === 1 && data.product) {
        if(data.product.product_name) {
          productName = data.product.product_name;
          if(data.product.brands) productName = `${data.product.brands} - ${productName}`;
        }
        if(data.product.image_front_small_url) imageUrl = data.product.image_front_small_url;
        else if (data.product.image_url) imageUrl = data.product.image_url;
      }

      await db.ref(`pantry/${decodedText}`).set({
        name: productName,
        qty: 1,
        unit: "",
        price: 0,
        imageUrl: imageUrl,
        inCart: false,
        addedAt: new Date().toISOString()
      });

      statusEl.className = 'alert alert-success mt-3 mb-0 fw-bold';
      statusEl.innerHTML = `<i class="fa-solid fa-check me-2"></i> Added ${productName}!`;
    }
  } catch (err) {
    statusEl.className = 'alert alert-danger mt-3 mb-0 fw-bold';
    statusEl.innerHTML = `Error looking up item. Added as Unknown.`;
    await db.ref(`pantry/${decodedText}`).set({ name: "Unknown Scan", qty: 1, unit: "", price: 0, imageUrl: "", inCart: false });
  }

  setTimeout(() => {
    window.lastScanned = null;
    statusEl.classList.add('d-none');
    if(html5QrcodeScanner) html5QrcodeScanner.resume();
  }, 2000);
}

// Camera Controls with new slide-down card
$('start-scan-btn')?.addEventListener('click', () => {
  $('scanner-card').style.display = 'block'; // NEW: Show the card
  $('start-scan-btn').style.display = 'none';
  $('stop-scan-btn').style.display = 'inline-block';

  const formats = [
    Html5QrcodeSupportedFormats.UPC_A, Html5QrcodeSupportedFormats.UPC_E,
    Html5QrcodeSupportedFormats.EAN_13, Html5QrcodeSupportedFormats.EAN_8,
    Html5QrcodeSupportedFormats.CODE_128, Html5QrcodeSupportedFormats.CODE_39
  ];

  html5QrcodeScanner = new Html5Qrcode("reader", { formatsToSupport: formats });
  html5QrcodeScanner.start({ facingMode: "environment" }, { fps: 30, disableFlip: false }, onScanSuccess)
  .catch(err => showToast("Camera permission denied.", "danger"));
});

$('stop-scan-btn')?.addEventListener('click', () => {
  if(html5QrcodeScanner) {
    html5QrcodeScanner.stop().then(() => {
      $('scanner-card').style.display = 'none'; // NEW: Hide the card
      $('start-scan-btn').style.display = 'inline-block';
      $('stop-scan-btn').style.display = 'none';
      $('scan-status').classList.add('d-none');
    });
  }
});

// --- EDIT ITEM LOGIC ---
window.openEditPantryItem = function(barcode) {
  const item = pantry[barcode];
  if(!item) return;

  $('edit-pantry-barcode').value = barcode;
  $('edit-pantry-name').value = item.name;
  $('edit-pantry-qty').value = item.qty;
  $('edit-pantry-unit').value = item.unit || '';
  $('edit-pantry-price').value = item.price || '';
  $('edit-image-preview').src = item.imageUrl || defaultImage;
  $('edit-pantry-incart').checked = item.inCart || false;

  if(editPantryModal) editPantryModal.show();
};


// --- INITIALIZATION & EVENTS ---
document.addEventListener('DOMContentLoaded', () => {
  setTimeout(() => {
    if ($('manualModal')) manualModal = new bootstrap.Modal($('manualModal'));
    if ($('editPantryModal')) editPantryModal = new bootstrap.Modal($('editPantryModal'));
  }, 500);

    $('open-manual-btn')?.addEventListener('click', () => {
      $('manual-name').value = '';
      $('manual-barcode-input').value = '';
      $('manual-qty').value = '1';
      $('manual-unit').value = '';
      $('manual-price').value = '';
      $('manual-image-url').value = '';
      $('manual-image-preview-container').classList.add('d-none');
      $('save-manual-item').disabled = false;
      $('save-manual-item').textContent = "Add to Inventory";
      if(manualModal) manualModal.show();
    });

      window.lookupTypedBarcode = async function() {
        const barcode = $('manual-barcode-input').value.trim();
        if (!barcode) return;

        $('save-manual-item').disabled = true;
        $('manual-name').value = "Searching...";
        $('manual-image-url').value = '';
        $('manual-image-preview-container').classList.add('d-none');

        try {
          const response = await fetch(`https://world.openfoodfacts.org/api/v0/product/${barcode}.json`);
          const data = await response.json();

          if (data.status === 1 && data.product && data.product.product_name) {
            let productName = data.product.product_name;
            if(data.product.brands) productName = `${data.product.brands} - ${productName}`;
            $('manual-name').value = productName;

            let imageUrl = "";
            if(data.product.image_front_small_url) imageUrl = data.product.image_front_small_url;
            else if (data.product.image_url) imageUrl = data.product.image_url;

            if(imageUrl) {
              $('manual-image-url').value = imageUrl;
              $('manual-image-preview').src = imageUrl;
              $('manual-image-preview-container').classList.remove('d-none');
            }

          } else {
            $('manual-name').value = "";
            alert("Product not found in database. Please type the name manually.");
          }
        } catch (err) {
          alert("Search failed. Check your internet connection.");
          $('manual-name').value = "";
        }
        $('save-manual-item').disabled = false;
      };

      window.saveManualItem = async function() {
        const name = $('manual-name').value.trim();
        const qty = Number($('manual-qty').value) || 1;
        const unit = $('manual-unit').value.trim();
        const price = Number($('manual-price').value) || 0;
        const imageUrl = $('manual-image-url').value.trim();
        let barcode = $('manual-barcode-input').value.trim();

        barcode = barcode.replace(/[.#$\[\]]/g, "") || Date.now().toString();

        if (!name) return showToast('Please provide an item name.', 'warning');

        const btn = $('save-manual-item');
        btn.textContent = 'Saving...'; btn.disabled = true;

        try {
          await db.ref(`pantry/${barcode}`).set({
            name, qty, unit, price, imageUrl, inCart: false, addedAt: new Date().toISOString()
          });

          manualModal.hide();
          showToast('Item added to pantry!', 'success');
        } catch (error) {
          alert("DATABASE ERROR: " + error.message);
        } finally {
          btn.textContent = 'Add to Inventory'; btn.disabled = false;
        }
      };

      $('save-manual-item')?.addEventListener('click', saveManualItem);

      $('save-edit-pantry-item')?.addEventListener('click', async () => {
        const barcode = $('edit-pantry-barcode').value;
        const name = $('edit-pantry-name').value.trim();
        const qty = Number($('edit-pantry-qty').value);
        const unit = $('edit-pantry-unit').value.trim();
        const price = Number($('edit-pantry-price').value) || 0;
        const inCart = $('edit-pantry-incart').checked;

        if(name && qty >= 0) {
          await db.ref(`pantry/${barcode}`).update({ name, qty, unit, price, inCart });
          editPantryModal.hide();
          showToast('Item updated successfully!', 'success');
        }
      });

      $('delete-pantry-item')?.addEventListener('click', async () => {
        const barcode = $('edit-pantry-barcode').value;
        if(confirm('Are you sure you want to completely remove this item from your inventory?')) {
          await db.ref(`pantry/${barcode}`).remove();
          editPantryModal.hide();
          showToast('Item permanently removed.', 'danger');
        }
      });
});
