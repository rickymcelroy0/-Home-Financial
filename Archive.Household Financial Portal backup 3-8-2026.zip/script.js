const firebaseConfig = {
  apiKey: "AIzaSyCp2GPQWhV_LY1SJKfPFgjpR1f1KqRqh9U",
  authDomain: "homefund-3b81a.firebaseapp.com",
  databaseURL: "https://homefund-3b81a-default-rtdb.firebaseio.com",
  projectId: "homefund-3b81a",
  storageBucket: "homefund-3b81a.firebasestorage.app",
  messagingSenderId: "597780469252",
  appId: "1:597780469252:web:95b8136a4db32111bc4751"
};

if (!firebase.apps.length) firebase.initializeApp(firebaseConfig);
const db = firebase.database();
const auth = firebase.auth();

let currentUser = null;
let users = {}; let bills = {}; let privateBills = {};
let myAccounts = {}; let accountHistoryLogs = {};
let globalVendors = {}; // NEW: The Database Vendor Dictionary

let vaultUnlocked = false;
let billModal, privateBillModal, editBillModal, vaultModal, resetModal, calcModal;
let addAccountModal, editAccountModal, depositModal, transferModal, payConfirmModal, vendorModal;

const $ = (id) => document.getElementById(id);
const number = (n) => Number(Number(n || 0).toFixed(2));
const money = (n) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(number(n));
const nowIso = () => new Date().toISOString();
const todayIso = () => new Date().toISOString().slice(0, 10);

function updateGlassNumber(id, newValue) {
  const el = $(id); if (!el || el.textContent === newValue) return;
  el.classList.add('flip-active');
  setTimeout(() => { el.textContent = newValue; }, 300);
  setTimeout(() => { el.classList.remove('flip-active'); }, 600);
}
function startClock() {
  if (window.__ledgerClockStarted) return;
  window.__ledgerClockStarted = true;
  setInterval(() => {
    const now = new Date(); let h = now.getHours(); let m = now.getMinutes(); const ampm = h >= 12 ? 'PM' : 'AM';
    h = h % 12; h = h ? h : 12; m = m < 10 ? '0' + m : m;
    const clockEl = $('clockTime'); if (clockEl) clockEl.innerHTML = `${h}<span class="blink">:</span>${m} ${ampm}`;
  }, 1000);
}
async function loadBingBackground() {
  try { const res = await fetch('https://api.allorigins.win/raw?url=' + encodeURIComponent('https://www.bing.com/HPImageArchive.aspx?format=js&idx=0&n=1&mkt=en-US'));
    const data = await res.json(); document.body.style.backgroundImage = `linear-gradient(rgba(255, 255, 255, 0.35), rgba(255, 255, 255, 0.65)), url('https://www.bing.com${data.images[0].url}')`;
  } catch(e) {}
}
loadBingBackground();
function showToast(msg, type = 'info') {
  const container = $('toast-container'); const toast = document.createElement('div');
  const map = { success: 'success', danger: 'danger', warning: 'warning', info: 'primary' };
  toast.className = `alert alert-${map[type] || 'primary'} shadow-lg border-0 mb-2 text-white`;
  if (type === 'success') toast.style.backgroundColor = 'var(--success)'; if (type === 'danger') toast.style.backgroundColor = 'var(--danger)';
  toast.style.borderRadius = '8px'; toast.innerHTML = msg; container.appendChild(toast); setTimeout(() => toast.remove(), 3200);
}
function showLoginError(msg) { $('login-err').textContent = msg; $('login-err').classList.remove('d-none'); }
function clearLoginError() { $('login-err').classList.add('d-none'); }
function isAdmin() { return currentUser && users[currentUser]?.role === 'admin'; }
function activeMembers() { return Object.entries(users).filter(([uid, user]) => user.status === 'active'); }
function memberName(uid) { return users[uid]?.name || uid || 'Unknown'; }
function allOpenBills() { return Object.entries(bills).filter(([_, bill]) => bill.status === 'open'); }

// --- AUTHENTICATION ---
auth.onAuthStateChanged(async (user) => {
  if (user) {
    currentUser = user.uid;
    db.ref(`users/${user.uid}`).on('value', async (snap) => {
      let userData = snap.val();
      if (!userData) {
        const nameFallback = user.email.split('@')[0];
        userData = { email: user.email, name: nameFallback.charAt(0).toUpperCase() + nameFallback.slice(1), role: 'member', status: 'active', requiresPasswordReset: true };
        await db.ref(`users/${user.uid}`).set(userData);
      }
      users[user.uid] = userData;
      $('login-wrapper').classList.add('d-none'); $('login-wrapper').classList.remove('d-flex'); $('app-wrapper').classList.remove('d-none');
      if (userData.requiresPasswordReset) resetModal.show(); else { renderCurrentView(); startClock(); }
    });
    db.ref('users').on('value', snap => { users = snap.val() || {}; populateUserSelects(); if (!users[currentUser]?.requiresPasswordReset) renderCurrentView(); });
  } else {
    currentUser = null; vaultUnlocked = false; $('app-wrapper').classList.add('d-none'); $('login-wrapper').classList.remove('d-none'); $('login-wrapper').classList.add('d-flex');
  }
});
async function authenticateUser() {
  const email = $('login-email').value.trim(); const password = $('login-password').value.trim();
  if (!email || !password) return showLoginError('Enter email and password.');
  try { await auth.signInWithEmailAndPassword(email, password); clearLoginError(); $('login-password').value = ''; }
  catch (err) { showLoginError('Invalid email or password.'); }
}
function logoutUser() { auth.signOut(); switchScreen('unified-dashboard'); $('login-email').value = ''; $('login-password').value = ''; }
async function submitPasswordReset() {
  const newPass = $('new-password-field').value.trim(); if (newPass.length < 6) return showToast("Password must be at least 6 characters.", "warning");
  try { await auth.currentUser.updatePassword(newPass); await db.ref(`users/${currentUser}/requiresPasswordReset`).set(false); resetModal.hide(); showToast("Password updated.", "success"); renderCurrentView(); startClock(); } catch (err) { showToast("Error updating password.", "danger"); }
}

// --- NEW: VENDOR DICTIONARY MANAGEMENT ---
function populateVendorDropdowns() {
  const sorted = Object.entries(globalVendors).sort((a,b) => a[1].name.localeCompare(b[1].name));
  let options = `<option value="" disabled selected>Select Vendor...</option>
  <option value="custom" class="fw-bold text-primary">➕ Type Custom Vendor...</option>`;
  sorted.forEach(([id, v]) => { options += `<option value="${v.name}">${v.name}</option>`; });

  ['bill-name', 'private-bill-name', 'edit-bill-name'].forEach(id => {
    const el = $(id);
    if(el) {
      const currentVal = el.value;
      el.innerHTML = options;
      if(currentVal) el.value = currentVal;
    }
  });
}

window.openVendorManager = function() {
  renderVendorManagerList();
  vendorModal.show();
}

function renderVendorManagerList() {
  const list = $('vendor-manager-list');
  const sorted = Object.entries(globalVendors).sort((a,b) => a[1].name.localeCompare(b[1].name));
  if(sorted.length === 0) {
    list.innerHTML = `<div class="text-center text-muted py-3">No vendors found.</div>`;
    return;
  }
  list.innerHTML = sorted.map(([id, v]) => `
  <div class="list-group-item d-flex justify-content-between align-items-center fw-bold text-dark">
  ${v.name}
  <button class="btn btn-sm btn-outline-danger px-2 py-1" onclick="deleteVendor('${id}')" title="Delete Vendor"><i class="fa-solid fa-trash"></i></button>
  </div>
  `).join('');
}

window.addVendorFromManager = async function() {
  const name = $('new-vendor-input').value.trim();
  if(!name) return;

  const existing = Object.values(globalVendors).find(v => v.name.toLowerCase() === name.toLowerCase());
  if(!existing) {
    await db.ref('vendors').push().set({ name });
    $('new-vendor-input').value = '';
    showToast(`${name} added to Dictionary.`, 'success');
  } else {
    showToast("Vendor already exists.", "warning");
  }
}

window.deleteVendor = async function(id) {
  if(!confirm("Delete this vendor from the dictionary?")) return;
  await db.ref(`vendors/${id}`).remove();
  showToast("Vendor deleted.", "warning");
}

// A helper function to auto-save custom typed vendors when you make a bill
async function autoSaveCustomVendor(typedName) {
  if(!typedName) return;
  const existing = Object.values(globalVendors).find(v => v.name.toLowerCase() === typedName.toLowerCase());
  if(!existing) {
    await db.ref('vendors').push().set({ name: typedName });
  }
}

// --- POPULATE OTHER DROPDOWNS ---
function populateUserSelects() {
  const memberOpts = activeMembers().map(([uid, user]) => `<option value="${uid}">${user.name}</option>`).join('');
  if ($('bill-user')) $('bill-user').innerHTML = isAdmin() ? memberOpts : `<option value="${currentUser}">${memberName(currentUser)}</option>`;
  if ($('transfer-recipient')) {
    const transferOpts = activeMembers().filter(([uid]) => uid !== currentUser).map(([uid, user]) => `<option value="${uid}">${user.name}</option>`).join('');
    $('transfer-recipient').innerHTML = transferOpts || `<option disabled>No other active members found</option>`;
  }
}
function populateAccountDropdowns() {
  const accountsList = Object.entries(myAccounts);
  let options = accountsList.map(([id, acc]) => `<option value="${id}">${acc.name} (${money(acc.balance)})</option>`).join('');
  if(options === '') options = '<option disabled selected>No accounts created yet</option>';

  if($('deposit-target-account')) $('deposit-target-account').innerHTML = options;
  if($('transfer-source-account')) $('transfer-source-account').innerHTML = options;
  if($('transfer-internal-target')) $('transfer-internal-target').innerHTML = options;
  if($('pay-confirm-account')) $('pay-confirm-account').innerHTML = options;

  if($('account-ledger-options')) {
    $('account-ledger-options').innerHTML = accountsList.map(([id, acc]) => `<option value="account-${id}">${acc.name} Ledger</option>`).join('');
  }
}

function switchScreen(targetId) { document.querySelectorAll('.view').forEach(v => { v.classList.remove('active'); v.classList.add('d-none'); }); const target = $(targetId); target.classList.remove('d-none'); setTimeout(() => target.classList.add('active'), 10); }
function openVaultAuth() {
  const user = users[currentUser];
  if (!user.vaultPassword) { $('vault-auth-title').innerHTML = `<i class="fa-solid fa-key me-2"></i> Setup Vault`; $('vault-auth-desc').textContent = "Create a new password."; $('vault-auth-btn').textContent = "Set Password & Unlock"; }
  else { $('vault-auth-title').innerHTML = `<i class="fa-solid fa-lock me-2"></i> Private Vault`; $('vault-auth-desc').textContent = "Enter your password to unlock."; $('vault-auth-btn').textContent = "Unlock Vault"; }
  $('vault-password-input').value = ''; vaultModal.show();
}
async function submitVaultAuth() {
  const pass = $('vault-password-input').value.trim(); if (!pass) return showToast("Password required.", "warning");
  const user = users[currentUser];
  if (!user.vaultPassword) { await db.ref(`users/${currentUser}/vaultPassword`).set(pass); vaultUnlocked = true; showToast("Vault password set.", "success"); }
  else { if (user.vaultPassword !== pass) return showToast("Incorrect password.", "danger"); vaultUnlocked = true; }
  vaultModal.hide(); switchScreen('vault-dashboard'); renderVaultScreen();
}
function lockVault() { vaultUnlocked = false; switchScreen('unified-dashboard'); renderMainDashboard(); showToast("Vault locked.", "success"); }

function renderCurrentView() {
  if (!currentUser) return;
  populateUserSelects(); populateAccountDropdowns(); populateVendorDropdowns();
  $('session-user-label').textContent = `${memberName(currentUser)} · ${users[currentUser]?.role || ''}`;
  if (vaultUnlocked && $('vault-dashboard').classList.contains('active')) renderVaultScreen();
  else renderMainDashboard();
}

function renderAccounts() {
  const container = $('my-accounts-container');
  const accountsList = Object.entries(myAccounts);
  let netWorth = 0;

  if(accountsList.length === 0) {
    container.innerHTML = `<div class="col-12"><div class="alert alert-secondary text-center fw-bold border-dashed border-2">You have no accounts setup. Click 'Add Account' to begin.</div></div>`;
    $('total-net-worth-badge').textContent = 'Net Worth: $0.00';
    return;
  }

  container.innerHTML = accountsList.map(([id, acc]) => {
    const isDebt = (acc.type === 'credit' || acc.type === 'loan');
    if(isDebt) netWorth -= Number(acc.balance); else netWorth += Number(acc.balance);
    const icon = acc.type === 'checking' ? 'fa-building-columns text-success' : acc.type === 'savings' ? 'fa-piggy-bank text-info' : acc.type === 'credit' ? 'fa-credit-card text-danger' : 'fa-car text-warning';

    return `
    <div class="col-md-3 col-sm-6">
    <div class="card-panel p-3 border-top border-3 h-100 d-flex flex-column justify-content-between" style="border-top-color: ${isDebt ? 'var(--danger)' : 'var(--success)'}!important;">
    <div>
    <div class="d-flex justify-content-between align-items-center mb-1"><div class="fw-bold fs-6 text-dark"><i class="fa-solid ${icon} me-2"></i>${acc.name}</div></div>
    <div class="fs-4 fw-bold ${isDebt ? 'text-danger' : 'text-success'}">${money(acc.balance)}</div>
    <div class="text-muted small mt-1" style="text-transform: capitalize;">${acc.type}</div>
    </div>
    <div class="mt-3 d-flex gap-2 border-top border-secondary pt-2">
    <button class="btn btn-sm btn-outline-primary flex-grow-1 p-1" onclick="openEditAccount('${id}')"><i class="fa-solid fa-pen"></i> Edit</button>
    <button class="btn btn-sm btn-outline-dark flex-grow-1 p-1" onclick="viewAccountLedger('${id}')"><i class="fa-solid fa-list"></i> Ledger</button>
    </div>
    </div>
    </div>
    `;
  }).join('');

  $('total-net-worth-badge').textContent = `Net Worth: ${money(netWorth)}`;
  $('total-net-worth-badge').className = `badge ${netWorth >= 0 ? 'bg-success' : 'bg-danger'} text-white px-3 py-2 fs-6 shadow-sm`;
}

window.viewAccountLedger = function(id) {
  $('ledger-view-selector').value = `account-${id}`;
  renderMainLedgerTable();
  $('universal-ledger-container').scrollIntoView({ behavior: 'smooth' });
}

function renderMainDashboard() {
  $('welcome-name').textContent = `Welcome, ${memberName(currentUser)}`;
  renderAccounts();
  let houseTotal = 0; let myShare = 0;
  allOpenBills().forEach(([id, b]) => { houseTotal += number(b.amount); if (b.splitMode === 'whole') { if (b.userId === currentUser) myShare += number(b.amount); } else { myShare += number(b.amount) / 2; } });
  updateGlassNumber('tile-house-total', money(houseTotal)); updateGlassNumber('tile-my-share', money(myShare));
  renderMainLedgerTable();
}

function extractEvents(sourceBills, typeStr, isMaster = false) {
  let evs = [];
  Object.entries(sourceBills).forEach(([id, b]) => {
    let amt = number(b.amount); let prefix = '';
    if (typeStr === 'shared') {
      const isSplit = b.splitMode !== 'whole';
      if (!isMaster) {
        if (isSplit) { amt = amt / 2; prefix = `House Bill (50% Share)`; } else { if (b.userId !== currentUser) return; prefix = `House Bill (100% Assigned)`; }
      } else prefix = isSplit ? `Master House Bill (Split 50/50)` : `Master House Bill (Whole 100%)`;
    } else prefix = 'Private Bill';

    evs.push({ id, type: typeStr, status: b.status, isPayment: false, date: b.createdAt, dueDate: b.dueDate, inv: id.slice(-6).toUpperCase(), desc: `${prefix}: ${b.name}`, charge: amt, credit: 0, paidFromId: b.paidFromId });
    if (b.status === 'paid' && b.paidAt) evs.push({ id, type: typeStr, status: b.status, isPayment: true, date: b.paidAt, dueDate: b.dueDate, inv: id.slice(-6).toUpperCase(), desc: `Payment Applied: ${b.name}`, charge: 0, credit: amt, paidFromId: b.paidFromId });
  });
  return evs;
}

function buildSpreadsheetHTML(events, isAccountLedger = false) {
  events.sort((a, b) => new Date(a.date) - new Date(b.date));
  let runningTotal = 0;
  events.forEach(ev => { runningTotal += ev.charge; runningTotal -= ev.credit; ev.balance = runningTotal; });
  events.reverse();

  let rows = '';
  if (events.length === 0) rows = `<tr><td colspan="7" class="text-center py-4 muted fw-bold">No ledger records found for this view.</td></tr>`;
  else {
    events.forEach(ev => {
      const dateStr = new Date(ev.date).toLocaleDateString('en-US');
      let actionsHTML = '';

      if (isAccountLedger) {
        actionsHTML = `<button class="action-btn delete" onclick="deleteAccountTransaction('${ev.accountId}', '${ev.id}')" title="Delete Transaction & Reverse Balance"><i class="fa-solid fa-trash"></i></button>`;
      } else if (ev.isPayment) {
        actionsHTML += `<button class="action-btn undo" onclick="undoBillPayment('${ev.id}', '${ev.type}')" title="Undo Payment"><i class="fa-solid fa-rotate-left"></i></button>`;
      } else {
        if (ev.status === 'open') actionsHTML += `<button class="action-btn pay" onclick="triggerPayConfirm('${ev.id}', '${ev.type}')" title="Pay with Account"><i class="fa-solid fa-check"></i></button>`;
        actionsHTML += `<button class="action-btn edit" onclick="openEditBill('${ev.id}', '${ev.type}')" title="Edit"><i class="fa-solid fa-pen"></i></button>`;
        actionsHTML += `<button class="action-btn delete" onclick="deleteBill('${ev.id}', '${ev.type}')" title="Delete"><i class="fa-solid fa-trash"></i></button>`;
      }

      rows += `<tr>
      <td>${dateStr}</td><td>INV${ev.inv}</td><td>${ev.desc}</td>
      <td class="col-currency">${ev.charge ? `<div class="currency-wrap text-danger"><span>$</span><span>${ev.charge.toFixed(2)}</span></div>` : ''}</td>
      <td class="col-currency">${ev.credit ? `<div class="currency-wrap text-success"><span>$</span><span>${ev.credit.toFixed(2)}</span></div>` : ''}</td>
      <td class="col-currency fw-bold text-primary"><div class="currency-wrap"><span>$</span><span>${ev.balance.toFixed(2)}</span></div></td>
      <td class="text-end" style="min-width: 130px;">${actionsHTML}</td>
      </tr>`;
    });
  }
  return `<div class="spreadsheet-wrap"><table class="spreadsheet-table"><thead><tr><th>Date</th><th>Invoice / Record #</th><th>Description</th><th class="col-currency">Charges / Out</th><th class="col-currency">Credits / In</th><th class="col-currency">Line Total</th><th class="text-end">Actions</th></tr></thead><tbody>${rows}</tbody></table></div>`;
}

function renderMainLedgerTable() {
  const view = $('ledger-view-selector').value;
  let events = [];
  let isAccLedger = false;

  if (view === 'master') events = extractEvents(bills, 'shared', true);
  else if (view === 'shared') events = extractEvents(bills, 'shared', false);
  else if (view === 'overdue') events = extractEvents(bills, 'shared', false).filter(e => e.status === 'open' && e.dueDate && e.dueDate < todayIso() && !e.isPayment);
  else if (view.startsWith('account-')) {
    isAccLedger = true;
    const accId = view.replace('account-', '');
    const logs = accountHistoryLogs[accId] || {};
    events = Object.entries(logs).map(([logId, t]) => {
      return {
        id: logId, type: 'account-log', isPayment: false, accountId: accId,
        date: t.date, inv: logId.slice(-6).toUpperCase(), desc: t.desc,
                                      charge: t.amount < 0 ? Math.abs(t.amount) : 0,
                                      credit: t.amount > 0 ? t.amount : 0
      };
    });
  }
  $('universal-ledger-container').innerHTML = buildSpreadsheetHTML(events, isAccLedger);
}

function renderVaultScreen() {
  if (!vaultUnlocked) return switchScreen('unified-dashboard');
  const events = extractEvents(privateBills[currentUser] || {}, 'private', false);
  const totalDebt = events.filter(e => !e.isPayment && e.status === 'open').reduce((s, e) => s + e.charge, 0);
  const totalPaid = events.filter(e => e.isPayment).reduce((s, e) => s + e.credit, 0);
  updateGlassNumber('vault-total-debt', money(totalDebt)); updateGlassNumber('vault-total-paid', money(totalPaid));
  $('vault-ledger-container').innerHTML = buildSpreadsheetHTML(events);
}

async function logAccountTransaction(accId, amt, desc, linkedBillId = null, linkedBillType = null) {
  if(!accId) return;
  const data = { date: nowIso(), amount: amt, desc: desc };
  if(linkedBillId) data.linkedBillId = linkedBillId;
  if(linkedBillType) data.linkedBillType = linkedBillType;
  await db.ref(`accountHistory/${currentUser}/${accId}`).push().set(data);
}

window.deleteAccountTransaction = async function(accountId, logId) {
  if(!confirm("Are you sure you want to delete this transaction?\n\nThe funds will be automatically reversed to your account balance, and any linked bills will be reopened.")) return;
  const acc = myAccounts[accountId]; if(!acc) return showToast("Account not found.", "danger");
  const logRef = db.ref(`accountHistory/${currentUser}/${accountId}/${logId}`);
  const snap = await logRef.once('value'); const log = snap.val(); if(!log) return showToast("Transaction not found.", "danger");
  const logAmt = Number(log.amount); const isDebt = (acc.type === 'credit' || acc.type === 'loan');
  const newBal = isDebt ? (Number(acc.balance) + logAmt) : (Number(acc.balance) - logAmt);
  await db.ref(`accounts/${currentUser}/${accountId}/balance`).set(newBal);
  if (log.linkedBillId && log.linkedBillType) {
    const path = log.linkedBillType === 'shared' ? `bills/${log.linkedBillId}` : `privateBills/${currentUser}/${log.linkedBillId}`;
    const updates = { status: 'open', paidAt: null, paidFromId: null };
    if (log.linkedBillType === 'shared') updates.paidBy = null;
    await db.ref(path).update(updates);
  }
  await logRef.remove(); showToast("Transaction deleted and balance restored.", "success");
}

$('save-account-btn')?.addEventListener('click', async () => {
  const name = $('new-account-name').value.trim(); const type = $('new-account-type').value; const balance = number($('new-account-balance').value);
  if(!name) return showToast("Account name required.", "warning");
  const newRef = db.ref(`accounts/${currentUser}`).push();
  await newRef.set({ name, type, balance, createdAt: nowIso() });
  await logAccountTransaction(newRef.key, balance, "Starting Balance");
  $('new-account-name').value = ''; $('new-account-balance').value = '';
  addAccountModal.hide(); showToast(`Account '${name}' successfully linked.`, "success");
});

window.openEditAccount = function(id) {
  const acc = myAccounts[id]; if(!acc) return;
  $('edit-account-id').value = id; $('edit-account-name').value = acc.name; $('edit-account-type').value = acc.type; $('edit-account-balance').value = acc.balance;
  editAccountModal.show();
}

$('save-edit-account-btn')?.addEventListener('click', async () => {
  const id = $('edit-account-id').value; const name = $('edit-account-name').value.trim(); const type = $('edit-account-type').value; const balance = number($('edit-account-balance').value);
  if(!name) return showToast("Account name required.", "warning");
  await db.ref(`accounts/${currentUser}/${id}`).update({ name, type, balance });
  editAccountModal.hide(); showToast(`Account updated.`, "success");
});

$('delete-account-btn')?.addEventListener('click', async () => {
  if(!confirm("Are you sure you want to completely delete this account and its ledger history?")) return;
  const id = $('edit-account-id').value;
  await db.ref(`accounts/${currentUser}/${id}`).remove(); await db.ref(`accountHistory/${currentUser}/${id}`).remove();
  editAccountModal.hide(); showToast(`Account permanently deleted.`, "danger");
  $('ledger-view-selector').value = 'shared'; renderMainLedgerTable();
});

$('save-deposit-btn')?.addEventListener('click', async () => {
  const targetId = $('deposit-target-account').value; const amt = number($('deposit-amount').value);
  if (!targetId) return showToast('Please select a destination account.', 'warning');
  if (amt <= 0) return showToast('Enter a valid deposit amount.', 'warning');
  const currentBal = Number(myAccounts[targetId].balance); const isDebt = (myAccounts[targetId].type === 'credit' || myAccounts[targetId].type === 'loan');
  const newBal = isDebt ? (currentBal - amt) : (currentBal + amt);
  await db.ref(`accounts/${currentUser}/${targetId}/balance`).set(newBal);
  await logAccountTransaction(targetId, amt, `Deposit: ${$('deposit-source').value.trim() || 'Manual Deposit'}`);
  $('deposit-source').value = ''; $('deposit-amount').value = ''; depositModal.hide(); showToast('Funds securely deposited into account.', 'success');
});

$('execute-transfer-btn')?.addEventListener('click', async () => {
  const mode = $('transfer-mode').value; const sourceId = $('transfer-source-account').value;
  const amt = number($('transfer-amount').value); const memo = $('transfer-memo').value.trim() || 'Fund Transfer';
  if (!sourceId || amt <= 0) return showToast('Invalid transfer details.', 'warning');
  const currentSourceBal = Number(myAccounts[sourceId].balance); const isSourceDebt = (myAccounts[sourceId].type === 'credit' || myAccounts[sourceId].type === 'loan');

  if (mode === 'internal') {
    const targetId = $('transfer-internal-target').value;
    if (!targetId || sourceId === targetId) return showToast('Select a valid destination account.', 'warning');
    const newSourceBal = isSourceDebt ? (currentSourceBal + amt) : (currentSourceBal - amt);
    await db.ref(`accounts/${currentUser}/${sourceId}/balance`).set(newSourceBal);
    await logAccountTransaction(sourceId, -amt, `Internal Transfer To: ${myAccounts[targetId].name}`);
    const currentTargetBal = Number(myAccounts[targetId].balance); const isTargetDebt = (myAccounts[targetId].type === 'credit' || myAccounts[targetId].type === 'loan');
    const newTargetBal = isTargetDebt ? (currentTargetBal - amt) : (currentTargetBal + amt);
    await db.ref(`accounts/${currentUser}/${targetId}/balance`).set(newTargetBal);
    await logAccountTransaction(targetId, amt, `Internal Transfer From: ${myAccounts[sourceId].name}`);
  } else {
    const recipientUid = $('transfer-recipient').value; if(!recipientUid) return showToast("Select a house member.", "warning");
    const newSourceBal = isSourceDebt ? (currentSourceBal + amt) : (currentSourceBal - amt);
    await db.ref(`accounts/${currentUser}/${sourceId}/balance`).set(newSourceBal);
    await logAccountTransaction(sourceId, -amt, `Sent to ${users[recipientUid]?.name}: ${memo}`);
  }
  $('transfer-amount').value = ''; $('transfer-memo').value = ''; transferModal.hide(); showToast('Transfer executed successfully.', 'success');
});

window.triggerPayConfirm = function(billId, type) {
  if(Object.keys(myAccounts).length === 0) return showToast("You must Add an Account before you can pay a bill!", "danger");
  $('pay-confirm-bill-id').value = billId; $('pay-confirm-bill-type').value = type; payConfirmModal.show();
}

$('execute-pay-btn')?.addEventListener('click', async () => {
  const billId = $('pay-confirm-bill-id').value; const type = $('pay-confirm-bill-type').value; const accountId = $('pay-confirm-account').value;
  if(!accountId) return showToast("Select an account to pay from.", "warning");
  const path = type === 'shared' ? `bills/${billId}` : `privateBills/${currentUser}/${billId}`;
  const snap = await db.ref(path).once('value'); const bill = snap.val(); if (!bill) return;
  let myCost = number(bill.amount); if (type === 'shared' && bill.splitMode !== 'whole') myCost = myCost / 2;
  const acc = myAccounts[accountId]; const isDebt = (acc.type === 'credit' || acc.type === 'loan');
  const newBal = isDebt ? (Number(acc.balance) + myCost) : (Number(acc.balance) - myCost);
  await db.ref(`accounts/${currentUser}/${accountId}/balance`).set(newBal);
  await logAccountTransaction(accountId, -myCost, `Paid Bill: ${bill.name}`, billId, type);
  const updates = { status: 'paid', paidAt: nowIso(), paidFromId: accountId };
  if (type === 'shared') updates.paidBy = currentUser;
  await db.ref(path).update(updates);
  payConfirmModal.hide(); showToast(`Bill paid successfully.`, 'success');
});

window.undoBillPayment = async function(billId, type) {
  const path = type === 'shared' ? `bills/${billId}` : `privateBills/${currentUser}/${billId}`;
  const snap = await db.ref(path).once('value'); const bill = snap.val();
  if (!bill || !bill.paidFromId) return showToast("Cannot undo older un-linked payments.", "warning");
  let myCost = number(bill.amount); if (type === 'shared' && bill.splitMode !== 'whole') myCost = myCost / 2;
  const accountId = bill.paidFromId;
  if (myAccounts[accountId]) {
    const acc = myAccounts[accountId]; const isDebt = (acc.type === 'credit' || acc.type === 'loan');
    const newBal = isDebt ? (Number(acc.balance) - myCost) : (Number(acc.balance) + myCost);
    await db.ref(`accounts/${currentUser}/${accountId}/balance`).set(newBal);
    await logAccountTransaction(accountId, myCost, `Refunded Bill Payment: ${bill.name}`);
  }
  const updates = { status: 'open', paidAt: null, paidFromId: null };
  if (type === 'shared') updates.paidBy = null;
  await db.ref(path).update(updates);
  showToast('Payment reversed. Funds restored.', 'success');
}

window.deleteBill = async function(id, type) {
  if (!confirm('Warning: Delete this entry?')) return;
  const path = type === 'shared' ? `bills/${id}` : `privateBills/${currentUser}/${id}`;
  const snap = await db.ref(path).once('value'); const bill = snap.val();
  if (bill && bill.status === 'paid' && bill.paidFromId && myAccounts[bill.paidFromId]) {
    let myCost = number(bill.amount); if (type === 'shared' && bill.splitMode !== 'whole') myCost = myCost / 2;
    const acc = myAccounts[bill.paidFromId]; const isDebt = (acc.type === 'credit' || acc.type === 'loan');
    const newBal = isDebt ? (Number(acc.balance) - myCost) : (Number(acc.balance) + myCost);
    await db.ref(`accounts/${currentUser}/${bill.paidFromId}/balance`).set(newBal);
    await logAccountTransaction(bill.paidFromId, myCost, `Refund from Deleted Bill: ${bill.name}`);
  }
  await db.ref(path).remove(); showToast('Entry removed from ledger.', 'warning');
}

window.openEditBill = function(id, type) {
  const bill = type === 'shared' ? bills[id] : (privateBills[currentUser] || {})[id]; if (!bill) return;
  $('edit-bill-id').value = id; $('edit-bill-type').value = type;

  // Also check globalVendors to ensure it's in the list, though it should be
  const nameSelect = $('edit-bill-name');
  if (!Array.from(nameSelect.options).some(opt => opt.value === bill.name)) nameSelect.add(new Option(bill.name, bill.name));

  nameSelect.value = bill.name; $('edit-bill-amount').value = bill.amount; $('edit-bill-due-date').value = bill.dueDate || '';
  if (type === 'shared') { $('edit-allocation-wrapper').classList.remove('d-none'); $('edit-bill-split-mode').value = bill.splitMode || 'split'; }
  else $('edit-allocation-wrapper').classList.add('d-none'); editBillModal.show();
}

async function saveEditedBill() {
  const id = $('edit-bill-id').value; const type = $('edit-bill-type').value;
  let name = $('edit-bill-name').value;
  if (name === 'custom' && $('custom-edit-bill-name')) {
    name = $('custom-edit-bill-name').value.trim();
    await autoSaveCustomVendor(name);
  }
  const amount = number($('edit-bill-amount').value); const dueDate = $('edit-bill-due-date').value;
  if (!name || amount <= 0) return showToast('Invalid details provided.', 'warning');
  const updates = { name, amount, dueDate }; if (type === 'shared') updates.splitMode = $('edit-bill-split-mode').value;
  const path = type === 'shared' ? `bills/${id}` : `privateBills/${currentUser}/${id}`;
  await db.ref(path).update(updates);

  if($('custom-edit-bill-name')) $('custom-edit-bill-name').value = ''; if($('custom-edit-bill-name-container')) $('custom-edit-bill-name-container').classList.add('d-none');
  editBillModal.hide(); showToast('Ledger entry updated.', 'success');
}

async function createSharedBill() {
  const userId = isAdmin() ? $('bill-user').value : currentUser;
  let name = $('bill-name').value;
  if (name === 'custom' && $('custom-bill-name')) {
    name = $('custom-bill-name').value.trim();
    await autoSaveCustomVendor(name);
  }
  const splitMode = $('bill-split-mode').value; const amount = number($('bill-amount').value); const dueDate = $('bill-due-date').value;
  if (!userId || !name || amount <= 0) return showToast('Missing required fields.', 'warning');
  await db.ref('bills').push().set({ userId, name, amount, splitMode, dueDate: dueDate || '', status: 'open', createdAt: nowIso(), createdBy: currentUser });
  ['bill-name', 'bill-amount', 'bill-due-date'].forEach(id => $(id).value = '');
  if($('custom-bill-name')) $('custom-bill-name').value = ''; if($('custom-bill-name-container')) $('custom-bill-name-container').classList.add('d-none');
  $('bill-split-mode').value = 'split'; billModal.hide(); showToast('Shared charge logged to ledger.', 'success');
}

async function createPrivateBill() {
  let name = $('private-bill-name').value;
  if (name === 'custom' && $('custom-private-bill-name')) {
    name = $('custom-private-bill-name').value.trim();
    await autoSaveCustomVendor(name);
  }
  const amount = number($('private-bill-amount').value); const dueDate = $('private-bill-due-date').value;
  if (!name || amount <= 0) return showToast('Missing required fields.', 'warning');
  await db.ref(`privateBills/${currentUser}`).push().set({ name, amount, dueDate: dueDate || '', status: 'open', createdAt: nowIso() });
  ['private-bill-name', 'private-bill-amount', 'private-bill-due-date'].forEach(id => $(id).value = '');
  if($('custom-private-bill-name')) $('custom-private-bill-name').value = ''; if($('custom-private-bill-name-container')) $('custom-private-bill-name-container').classList.add('d-none');
  privateBillModal.hide(); showToast('Private charge logged to vault.', 'success');
}

function bindEvents() {
  $('login-btn').addEventListener('click', (e) => { e.preventDefault(); authenticateUser(); }); $('logout-btn').addEventListener('click', logoutUser); $('login-password').addEventListener('keydown', (e) => { if(e.key === 'Enter') authenticateUser(); });
  $('ledger-view-selector').addEventListener('change', renderMainLedgerTable);
  $('open-create-bill-modal-admin')?.addEventListener('click', () => billModal.show()); $('open-calc-btn')?.addEventListener('click', () => calcModal.show());
  $('open-vault-tile')?.addEventListener('click', openVaultAuth); $('close-vault-btn')?.addEventListener('click', lockVault); $('open-private-bill-modal')?.addEventListener('click', () => privateBillModal.show());
  $('vault-auth-btn').addEventListener('click', submitVaultAuth); $('vault-password-input').addEventListener('keydown', (e) => { if(e.key === 'Enter') submitVaultAuth(); });
  $('save-new-password-btn').addEventListener('click', submitPasswordReset); $('new-password-field').addEventListener('keydown', (e) => { if(e.key === 'Enter') submitPasswordReset(); });
  $('save-bill-btn')?.addEventListener('click', createSharedBill); $('save-private-bill-btn')?.addEventListener('click', createPrivateBill); $('save-edit-bill-btn')?.addEventListener('click', saveEditedBill);
}

function initModals() {
  billModal = new bootstrap.Modal($('billModal')); privateBillModal = new bootstrap.Modal($('privateBillModal')); editBillModal = new bootstrap.Modal($('editBillModal'));
  vaultModal = new bootstrap.Modal($('vaultModal')); resetModal = new bootstrap.Modal($('resetModal')); calcModal = new bootstrap.Modal($('calcModal'));
  if($('addAccountModal')) addAccountModal = new bootstrap.Modal($('addAccountModal')); if($('editAccountModal')) editAccountModal = new bootstrap.Modal($('editAccountModal'));
  if($('depositModal')) depositModal = new bootstrap.Modal($('depositModal')); if($('transferModal')) transferModal = new bootstrap.Modal($('transferModal'));
  if($('payConfirmModal')) payConfirmModal = new bootstrap.Modal($('payConfirmModal'));
  if($('vendorModal')) vendorModal = new bootstrap.Modal($('vendorModal'));
}

function subscribe() {
  db.ref('bills').on('value', snap => { bills = snap.val() || {}; if (currentUser) renderCurrentView(); });
  db.ref('privateBills').on('value', snap => { privateBills = snap.val() || {}; if (currentUser) renderCurrentView(); });
  db.ref('accounts').on('value', snap => { const allAccts = snap.val() || {}; if (currentUser) { myAccounts = allAccts[currentUser] || {}; renderCurrentView(); } });
  db.ref('accountHistory').on('value', snap => { const allHistory = snap.val() || {}; if (currentUser) { accountHistoryLogs = allHistory[currentUser] || {}; renderCurrentView(); } });

  // NEW: Listen to the Vendors Dictionary and seed defaults if it is completely empty!
  db.ref('vendors').on('value', async snap => {
    if(!snap.exists()) {
      const defaults = ["Rent", "PNM", "Walmart", "Target", "Amazon", "Capital One", "Chase Card", "SSA DAC", "SSA SSI"];
      for(let v of defaults) { await db.ref('vendors').push().set({ name: v }); }
      return;
    }
    globalVendors = snap.val();
    if (currentUser) {
      populateVendorDropdowns();
      if($('vendorModal').classList.contains('show')) renderVendorManagerList();
    }
  });
}

initModals(); bindEvents(); subscribe();

// --- CALCULATOR ---
let calcExpression = "";
window.calcInput = function(val) { if(calcExpression === "0" || calcExpression === "Error") calcExpression = ""; calcExpression += val; $('calc-display').textContent = calcExpression; };
window.calcOp = function(op) { if(calcExpression !== "" && !isNaN(calcExpression.slice(-1))) { calcExpression += op; $('calc-display').textContent = calcExpression; } };
window.calcClear = function() { calcExpression = ""; $('calc-display').textContent = "0"; };
window.calcEval = function() { try { let result = new Function('return ' + calcExpression)(); calcExpression = Number.isInteger(result) ? result.toString() : result.toFixed(2); $('calc-display').textContent = calcExpression; } catch(e) { $('calc-display').textContent = "Error"; calcExpression = ""; } };
