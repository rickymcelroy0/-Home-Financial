// This is the Service Worker that makes your app installable
const CACHE_NAME = 'homefund-cache-v1';

self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(clients.claim());
});

// Pass all requests through normally to keep Firebase live
self.addEventListener('fetch', (event) => {
  event.respondWith(fetch(event.request));
});
