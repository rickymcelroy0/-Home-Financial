DynamicWeather Beta 2.0 branding-fixed patch

This is the corrected Beta 2.0 patch. It does NOT place new branding images inside the existing images/ weather asset folder.

New branding location:
  assets/branding/dynamicweather-icon.png
  assets/branding/dynamicweather-logo.svg

Install:
  cd ~/Downloads/ModernWeatherApp_beta2_branding_fixed_patch
  ./install.sh /home/admin-1/Documents/ModernWeatherApp

Build/run:
  cd /home/admin-1/Documents/ModernWeatherApp
  rm -rf build
  cmake -S . -B build
  cmake --build build -j$(nproc)
  ./build/modernweather
