DynamicWeather Beta 2.3.1 test update

Visible test changes:
- Header badge now says BETA 2.3.1 • BUILD 231.
- Feature tabs moved into a cleaner Categories bar under the header.
- Side arrow opens the Detailed 7-Day drawer.
- Bottom forecast cards act like glass tabs and open detailed daily weather.
