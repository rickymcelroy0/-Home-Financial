DynamicWeather Beta 2.3 - Auto Update Center

What changed:
- Added a C++ UpdateManager backend.
- Added an Updates tab in the glowing feature drawer.
- The app checks your KDrive version.json automatically on startup.
- If latest_build is higher than the app build, it shows Update Available.
- If version.json includes download_url, the Install Update button downloads the ZIP.
- The app launches tools/update_dynamicweather.sh, closes itself, backs up the old folder, extracts the new ZIP, rebuilds, and relaunches.

Current app version:
- Version: 2.3 beta
- Build: 23

KDrive setup:
1. Upload DynamicWeather-Beta-2.3.zip to your KDrive update folder.
2. Upload version.json to the same folder.
3. In version.json, set download_url to the KDrive link for the ZIP file.
4. For future updates, raise latest_version/latest_build and point download_url to the newer ZIP.

Important:
- A KDrive preview link can be used for checking version.json.
- Automatic install needs a ZIP download URL that the app can download directly.
- If KDrive only provides a preview page for the ZIP, the app can still open the KDrive page, but fully automatic install may require a direct download link.
