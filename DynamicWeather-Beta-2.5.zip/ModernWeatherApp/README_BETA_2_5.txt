DynamicWeather Beta 2.5 Build 250

Major changes:
- Updates now open in their own clean Updates window instead of taking over the Tools drawer.
- Update source is now GitHub raw version.json.
- Update install helper now supports /opt/DynamicWeather and /usr/local/bin/dynamicweather.
- Ubuntu fixes: removed KDE Plasma QML dependency leftovers and i18n references from active weather provider code.
- Fixed duplicate MetNo debug function problem.
- Fixed weather icon paths that could become .png.png.

GitHub version.json raw URL used by the app:
https://raw.githubusercontent.com/rickymcelroy0/-Home-Financial/main/version.json

To publish this update:
1. Upload DynamicWeather-Beta-2.5.zip somewhere downloadable, preferably a GitHub Release.
2. Edit version.json in your GitHub repository.
3. Set latest_version to "2.5 beta" and latest_build to 250.
4. Set download_url to the direct ZIP download link.
