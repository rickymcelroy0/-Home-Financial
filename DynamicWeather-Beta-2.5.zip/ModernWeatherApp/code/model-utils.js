/**
 * Modern Weather Engine Data Parser
 * Maps Met.no / OpenWeatherMap raw payloads directly to dynamic visual properties
 */

function parseCurrentWeather(rawData) {
    if (!rawData) return null;

    try {
        // Target the standard time-series data node from Met.no
        var instantData = rawData.properties.timeseries[0].data.instant.details;
        var nextHourData = rawData.properties.timeseries[0].data.next_1_hours;

        // Clean out old barometer math. Extract precise visual factors for QML layers.
        return {
            temperature: instantData.air_temperature,             // Raw Celsius value
            windSpeed: instantData.wind_speed,                     // Meters per second (m/s)
            windDirection: instantData.wind_from_direction,       // Wind vector angle in degrees (0-360)
            relativeHumidity: instantData.relative_humidity,       // Humidity percentage (0-100)
            airPressure: instantData.air_pressure_at_sea_level,    // Sea level pressure in hPa
            
            // Core Graphical Layer Factors
            cloudCoverTotal: instantData.cloud_area_fraction,      // Total sky cover (0% to 100%)
            cloudCoverLow: instantData.low_cloud_area_fraction,    // Lower heavy stratus cloud density
            cloudCoverHigh: instantData.high_cloud_area_fraction,  // High wispy cirrus cloud density
            
            // Forecast Visual Icon Matching
            conditionSymbol: nextHourData.summary.symbol_code      // String map (e.g., "rain", "clearsky_day")
        };
    } catch(err) {
        console.log("[Data Engine Error] Raw weather payload was structurally invalid: " + err);
        return null;
    }
}

function parseForecastDays(rawData) {
    if (!rawData || !rawData.properties || !rawData.properties.timeseries) return [];

    var forecastList = [];
    var timeseries = rawData.properties.timeseries;
    var processedDays = {};

    // Filter time-series into clean daily high/low forecast arrays
    for (var i = 0; i < timeseries.length; i++) {
        var entry = timeseries[i];
        var dateText = entry.time.split("T")[0]; // Get ISO Date string YYYY-MM-DD
        
        // Skip current day processing to ensure future forecast tracking
        var todayStr = new Date().toISOString().split("T")[0];
        if (dateText === todayStr) continue;

        if (!processedDays[dateText] && entry.data.next_6_hours) {
            processedDays[dateText] = true;
            var details = entry.data.next_6_hours.details;
            
            forecastList.push({
                dateString: dateText,
                tempMax: details.air_temperature_max,
                tempMin: details.air_temperature_min,
                symbol: entry.data.next_6_hours.summary.symbol_code
            });
        }
        
        // Cap visual layout overhead at 3 solid forecast days
        if (forecastList.length >= 3) break;
    }
    return forecastList;
}