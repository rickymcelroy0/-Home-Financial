#!/usr/bin/env bash
set -euo pipefail
TARGET="${1:-/opt/DynamicWeather}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ ! -d "$TARGET" ]]; then
  echo "Creating $TARGET"
  sudo mkdir -p "$TARGET"
fi

echo "Installing DynamicWeather Beta 2.5 files into $TARGET"
sudo cp -a "$SCRIPT_DIR"/. "$TARGET"/
sudo chmod +x "$TARGET/tools/update_dynamicweather.sh" 2>/dev/null || true

cd "$TARGET"
sudo rm -rf build
if command -v ninja >/dev/null 2>&1; then
  sudo cmake -S . -B build -G Ninja
  sudo cmake --build build
else
  sudo cmake -S . -B build
  sudo cmake --build build -j"$(nproc)"
fi
sudo install -Dm755 "$TARGET/build/modernweather" /usr/local/bin/dynamicweather

sudo tee /usr/share/applications/DynamicWeather.desktop >/dev/null <<DESKTOP
[Desktop Entry]
Type=Application
Name=DynamicWeather
Comment=Animated desktop weather application
Exec=/usr/local/bin/dynamicweather
Icon=$TARGET/assets/branding/dynamicweather-icon.png
Terminal=false
Categories=Utility;Science;
StartupNotify=true
DESKTOP
sudo update-desktop-database /usr/share/applications 2>/dev/null || true

echo "Done. Run with: dynamicweather"
