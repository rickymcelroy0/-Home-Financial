#include "liveweather.h"

#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QNetworkRequest>
#include <QUrlQuery>
#include <QtMath>

LiveWeather::LiveWeather(QObject *parent) : QObject(parent) {}

void LiveWeather::setStatus(const QString &status)
{
    if (m_status == status) return;
    m_status = status;
    emit statusChanged();
}

void LiveWeather::setLoading(bool loading)
{
    if (m_loading == loading) return;
    m_loading = loading;
    emit loadingChanged();
}

QString LiveWeather::codeToCondition(int code) const
{
    if (code == 0) return QStringLiteral("Clear Sky");
    if (code == 1 || code == 2) return QStringLiteral("Partly Cloudy");
    if (code == 3) return QStringLiteral("Cloudy");
    if (code == 45 || code == 48) return QStringLiteral("Fog");
    if ((code >= 51 && code <= 67) || (code >= 80 && code <= 82)) return QStringLiteral("Rain Showers");
    if ((code >= 71 && code <= 77) || (code >= 85 && code <= 86)) return QStringLiteral("Snow");
    if (code >= 95) return QStringLiteral("Thunderstorm");
    return QStringLiteral("Weather");
}

QString LiveWeather::codeToIcon(int code) const
{
    if (code == 0) return QStringLiteral("weather-clear");
    if (code == 1 || code == 2) return QStringLiteral("weather-few-clouds");
    if (code == 3) return QStringLiteral("weather-clouds");
    if (code == 45 || code == 48) return QStringLiteral("weather-fog");
    if ((code >= 51 && code <= 67) || (code >= 80 && code <= 82)) return QStringLiteral("weather-showers");
    if ((code >= 71 && code <= 77) || (code >= 85 && code <= 86)) return QStringLiteral("weather-snow");
    if (code >= 95) return QStringLiteral("weather-storm");
    return QStringLiteral("weather-none-available");
}

void LiveWeather::refresh()
{
    if (m_loading) return;
    setLoading(true);
    setStatus(QStringLiteral("Fetching live weather from Open-Meteo..."));

    QUrl url(QStringLiteral("https://api.open-meteo.com/v1/forecast"));
    QUrlQuery query;
    query.addQueryItem(QStringLiteral("latitude"), QStringLiteral("35.0844"));
    query.addQueryItem(QStringLiteral("longitude"), QStringLiteral("-106.6504"));
    query.addQueryItem(QStringLiteral("current"), QStringLiteral("temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,wind_direction_10m,pressure_msl,cloud_cover"));
    query.addQueryItem(QStringLiteral("daily"), QStringLiteral("weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset"));
    query.addQueryItem(QStringLiteral("temperature_unit"), QStringLiteral("fahrenheit"));
    query.addQueryItem(QStringLiteral("wind_speed_unit"), QStringLiteral("mph"));
    query.addQueryItem(QStringLiteral("timezone"), QStringLiteral("auto"));
    url.setQuery(query);

    QNetworkRequest request(url);
    request.setRawHeader("User-Agent", "DynamicWeather/2.4");
    QNetworkReply *reply = m_network.get(request);

    connect(reply, &QNetworkReply::finished, this, [this, reply]() {
        reply->deleteLater();
        setLoading(false);
        if (reply->error() != QNetworkReply::NoError) {
            setStatus(QStringLiteral("Live weather failed: %1").arg(reply->errorString()));
            return;
        }
        QJsonParseError err;
        const QJsonDocument doc = QJsonDocument::fromJson(reply->readAll(), &err);
        if (err.error != QJsonParseError::NoError || !doc.isObject()) {
            setStatus(QStringLiteral("Live weather returned unreadable data."));
            return;
        }
        QJsonObject root = doc.object();
        QJsonObject current = root.value(QStringLiteral("current")).toObject();
        const double temp = current.value(QStringLiteral("temperature_2m")).toDouble(qQNaN());
        const int code = current.value(QStringLiteral("weather_code")).toInt(-1);
        const double wind = current.value(QStringLiteral("wind_speed_10m")).toDouble(qQNaN());
        const double dir = current.value(QStringLiteral("wind_direction_10m")).toDouble(qQNaN());
        const double humidity = current.value(QStringLiteral("relative_humidity_2m")).toDouble(qQNaN());
        const double pressure = current.value(QStringLiteral("pressure_msl")).toDouble(qQNaN());
        const double clouds = current.value(QStringLiteral("cloud_cover")).toDouble(qQNaN());

        if (!qIsNaN(temp)) m_temperatureText = QString::number(qRound(temp)) + QStringLiteral("°F");
        m_conditionText = codeToCondition(code);
        m_iconName = codeToIcon(code);
        if (!qIsNaN(wind)) m_windText = QString::number(wind, 'f', 1) + QStringLiteral(" mph");
        if (!qIsNaN(humidity)) m_humidityText = QString::number(qRound(humidity)) + QStringLiteral("%");
        if (!qIsNaN(pressure)) m_pressureText = QString::number(pressure, 'f', 1) + QStringLiteral(" hPa");
        if (!qIsNaN(clouds)) m_cloudText = QString::number(qRound(clouds)) + QStringLiteral("%");
        setStatus(QStringLiteral("Live weather updated."));
        emit weatherChanged();
    });
}
