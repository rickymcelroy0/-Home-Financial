#pragma once

#include <QObject>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QUrl>

class LiveWeather : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString locationName READ locationName NOTIFY weatherChanged)
    Q_PROPERTY(QString temperatureText READ temperatureText NOTIFY weatherChanged)
    Q_PROPERTY(QString conditionText READ conditionText NOTIFY weatherChanged)
    Q_PROPERTY(QString iconName READ iconName NOTIFY weatherChanged)
    Q_PROPERTY(QString windText READ windText NOTIFY weatherChanged)
    Q_PROPERTY(QString humidityText READ humidityText NOTIFY weatherChanged)
    Q_PROPERTY(QString pressureText READ pressureText NOTIFY weatherChanged)
    Q_PROPERTY(QString cloudText READ cloudText NOTIFY weatherChanged)
    Q_PROPERTY(QString status READ status NOTIFY statusChanged)
    Q_PROPERTY(bool loading READ loading NOTIFY loadingChanged)

public:
    explicit LiveWeather(QObject *parent = nullptr);

    QString locationName() const { return m_locationName; }
    QString temperatureText() const { return m_temperatureText; }
    QString conditionText() const { return m_conditionText; }
    QString iconName() const { return m_iconName; }
    QString windText() const { return m_windText; }
    QString humidityText() const { return m_humidityText; }
    QString pressureText() const { return m_pressureText; }
    QString cloudText() const { return m_cloudText; }
    QString status() const { return m_status; }
    bool loading() const { return m_loading; }

    Q_INVOKABLE void refresh();

signals:
    void weatherChanged();
    void statusChanged();
    void loadingChanged();

private:
    QString codeToCondition(int code) const;
    QString codeToIcon(int code) const;
    void setStatus(const QString &status);
    void setLoading(bool loading);

    QNetworkAccessManager m_network;
    QString m_locationName = QStringLiteral("Albuquerque, US");
    QString m_temperatureText;
    QString m_conditionText;
    QString m_iconName = QStringLiteral("weather-none-available");
    QString m_windText;
    QString m_humidityText;
    QString m_pressureText;
    QString m_cloudText;
    QString m_status = QStringLiteral("Ready");
    bool m_loading = false;
};
