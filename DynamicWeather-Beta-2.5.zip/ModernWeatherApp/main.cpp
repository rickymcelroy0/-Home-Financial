#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QCoreApplication>
#include <QUrl>
#include <QIcon>
#include "updatemanager.h"
#include "liveweather.h"

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);
    QCoreApplication::setApplicationName(QStringLiteral("ModernWeatherApp"));
    QCoreApplication::setOrganizationName(QStringLiteral("ModernWeatherApp"));
    QCoreApplication::setApplicationVersion(QStringLiteral("2.5 beta"));
    app.setWindowIcon(QIcon(QStringLiteral(":/assets/branding/dynamicweather-icon.png")));

    UpdateManager updateManager;
    LiveWeather liveWeather;

    QQmlApplicationEngine engine;
    engine.rootContext()->setContextProperty(QStringLiteral("updateManager"), &updateManager);
    engine.rootContext()->setContextProperty(QStringLiteral("liveWeather"), &liveWeather);
    engine.load(QUrl(QStringLiteral("qrc:/main.qml")));

    if (engine.rootObjects().isEmpty())
        return -1;

    return app.exec();
}
