#!/usr/bin/env bash
set -euo pipefail

ZIP_FILE="${1:-}"
APP_ROOT="${2:-}"
EXE_PATH="${3:-}"
APP_PID="${4:-}"

if [[ -z "$ZIP_FILE" || -z "$APP_ROOT" || -z "$EXE_PATH" ]]; then
  echo "Usage: update_dynamicweather.sh <zip> <app-root> <exe-path> <pid>" >&2
  exit 1
fi

if [[ -n "$APP_PID" ]]; then
  for _ in {1..80}; do
    if ! kill -0 "$APP_PID" 2>/dev/null; then
      break
    fi
    sleep 0.25
  done
fi

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="${APP_ROOT}_backup_${STAMP}"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

cp -a "$APP_ROOT" "$BACKUP"
unzip -oq "$ZIP_FILE" -d "$TMP"

SOURCE="$TMP"
if [[ -d "$TMP/ModernWeatherApp" ]]; then
  SOURCE="$TMP/ModernWeatherApp"
fi

find "$APP_ROOT" -mindepth 1 -maxdepth 1 \
  ! -name build \
  ! -name backups \
  -exec rm -rf {} +
cp -a "$SOURCE"/. "$APP_ROOT"/

chmod +x "$APP_ROOT/tools/update_dynamicweather.sh" 2>/dev/null || true

(
  cd "$APP_ROOT"
  rm -rf build
  if command -v ninja >/dev/null 2>&1; then
    cmake -S . -B build -G Ninja
    cmake --build build
  else
    cmake -S . -B build
    cmake --build build -j"$(nproc)"
  fi
)

if [[ -f "$APP_ROOT/build/modernweather" ]]; then
  install -Dm755 "$APP_ROOT/build/modernweather" /usr/local/bin/dynamicweather
fi

nohup "$EXE_PATH" >/tmp/dynamicweather-relaunch.log 2>&1 &
