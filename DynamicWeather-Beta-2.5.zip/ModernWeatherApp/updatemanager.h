#pragma once

#include <QObject>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QJsonObject>
#include <QUrl>

class UpdateManager : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString currentVersion READ currentVersion CONSTANT)
    Q_PROPERTY(int currentBuild READ currentBuild CONSTANT)
    Q_PROPERTY(QString updateUrl READ updateUrl WRITE setUpdateUrl NOTIFY updateUrlChanged)
    Q_PROPERTY(QString status READ status NOTIFY statusChanged)
    Q_PROPERTY(QString latestVersion READ latestVersion NOTIFY updateInfoChanged)
    Q_PROPERTY(int latestBuild READ latestBuild NOTIFY updateInfoChanged)
    Q_PROPERTY(QString releaseDate READ releaseDate NOTIFY updateInfoChanged)
    Q_PROPERTY(QString channel READ channel NOTIFY updateInfoChanged)
    Q_PROPERTY(QString message READ message NOTIFY updateInfoChanged)
    Q_PROPERTY(QString releaseNotes READ releaseNotes NOTIFY updateInfoChanged)
    Q_PROPERTY(QString downloadUrl READ downloadUrl NOTIFY updateInfoChanged)
    Q_PROPERTY(bool updateAvailable READ updateAvailable NOTIFY updateInfoChanged)
    Q_PROPERTY(bool busy READ busy NOTIFY busyChanged)
    Q_PROPERTY(bool canInstall READ canInstall NOTIFY updateInfoChanged)

public:
    explicit UpdateManager(QObject *parent = nullptr);

    QString currentVersion() const { return QStringLiteral("2.5 beta"); }
    int currentBuild() const { return 250; }

    QString updateUrl() const { return m_updateUrl.toString(); }
    void setUpdateUrl(const QString &url);

    QString status() const { return m_status; }
    QString latestVersion() const { return m_latestVersion; }
    int latestBuild() const { return m_latestBuild; }
    QString releaseDate() const { return m_releaseDate; }
    QString channel() const { return m_channel; }
    QString message() const { return m_message; }
    QString releaseNotes() const { return m_releaseNotes; }
    QString downloadUrl() const { return m_downloadUrl; }
    bool updateAvailable() const { return m_latestBuild > currentBuild(); }
    bool busy() const { return m_busy; }
    bool canInstall() const { return updateAvailable() && !m_downloadUrl.isEmpty(); }

    Q_INVOKABLE void checkForUpdates();
    Q_INVOKABLE void installUpdate();
    Q_INVOKABLE void openUpdatePage();
    Q_INVOKABLE void openDownloadPage();

signals:
    void statusChanged();
    void busyChanged();
    void updateInfoChanged();
    void updateUrlChanged();

private:
    QJsonObject parseJsonFromReply(const QByteArray &data) const;
    void setStatus(const QString &status);
    void setBusy(bool busy);
    void applyUpdateInfo(const QJsonObject &obj);

    QNetworkAccessManager m_network;
    QUrl m_updateUrl;
    QString m_status;
    QString m_latestVersion;
    int m_latestBuild = 0;
    QString m_releaseDate;
    QString m_channel;
    QString m_message;
    QString m_releaseNotes;
    QString m_downloadUrl;
    bool m_busy = false;
};
