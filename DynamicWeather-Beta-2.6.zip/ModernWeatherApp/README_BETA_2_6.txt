DynamicWeather Beta 2.6 Build 260

Fixes included:
- Updates now use a standalone update window instead of the old embedded Tools panel.
- Updater helper path is fixed for /opt/DynamicWeather.
- Updater launches xterm correctly for sudo authentication.
- Installer helper validates that the downloaded file is a real ZIP.
- Helper logs to /tmp/dynamicweather-update.log.
- MetNo provider debug leftovers were cleaned.
- currentPlace and sunRiseSetFlag standalone Qt issues were patched.

GitHub version.json should point download_url to:
https://raw.githubusercontent.com/rickymcelroy0/-Home-Financial/main/DynamicWeather-Beta-2.6.zip
