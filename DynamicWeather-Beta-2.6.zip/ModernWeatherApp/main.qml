import QtQuick
import QtQuick.Layouts
import QtQuick.Controls
import QtQuick.Window
import "libweather" as LibWeather

ApplicationWindow {
    id: root

    title: "DynamicWeather Beta 2.6 • Build 260"
    visibility: Window.FullScreen
    width: Screen.width
    height: Screen.height
    color: "#050816"

    property string cityName: "Albuquerque, US"
    property string homeUrl: "https://sites.google.com/view/dynamicweather/home"
    property string learnMoreUrl: "https://sites.google.com/view/dynamicweather/learnmore-dynamicweather"
    property real sceneTime: 0
    property bool compactMode: false
    property int featureTab: 0
    property string buildBadge: "BETA 2.6 • BUILD 260"
    property int dayTab: 0
    property bool featureDrawerOpen: false
    property bool autoRefreshEnabled: true

    function cleanIconName(name) {
        var n = String(name || "weather-none-available")
        if (n.indexOf("qrc:/") === 0) return n
        if (n.indexOf("images/") === 0) return n
        if (n.slice(-4) !== ".png") n += ".png"
        return n
    }

    readonly property string severeAlertText: root.stormy ? "Thunderstorm conditions possible — stay weather aware." : (weatherData.intWindSpeed && weatherData.intWindSpeed() >= 25 ? "Wind advisory style conditions — gusty winds detected." : "No active severe-weather alert detected in the app data.")
    readonly property bool hasSevereAlert: root.stormy || (weatherData.intWindSpeed && weatherData.intWindSpeed() >= 25)
    readonly property string sunriseText: weatherData.currentWeather && weatherData.currentWeather.sunrise ? new Date(weatherData.currentWeather.sunrise * 1000).toLocaleTimeString(Qt.locale(), "h:mm AP") : "Coming soon"
    readonly property string sunsetText: weatherData.currentWeather && weatherData.currentWeather.sunset ? new Date(weatherData.currentWeather.sunset * 1000).toLocaleTimeString(Qt.locale(), "h:mm AP") : "Coming soon"
    readonly property string moonPhaseText: moonPhaseName(new Date())

    readonly property real scaleFactor: Math.max(0.82, Math.min(width / 1366, height / 780))
    readonly property bool isNight: weatherData.currentWeather && weatherData.currentWeather.isDay === false
    readonly property string conditionText: liveWeather.conditionText || weatherData.currentConditions || "Weather loading"
    readonly property string placeText: liveWeather.locationName || weatherData.location || root.cityName || "Albuquerque, US"
    readonly property string conditionKey: ((liveWeather.iconName || weatherData.currentConditionIconName || "") + " " + root.conditionText).toLowerCase()
    readonly property bool rainy: conditionKey.indexOf("rain") >= 0 || conditionKey.indexOf("shower") >= 0 || conditionKey.indexOf("drizzle") >= 0 || conditionKey.indexOf("storm") >= 0
    readonly property bool snowy: conditionKey.indexOf("snow") >= 0 || conditionKey.indexOf("sleet") >= 0 || conditionKey.indexOf("ice") >= 0
    readonly property bool stormy: conditionKey.indexOf("storm") >= 0 || conditionKey.indexOf("thunder") >= 0 || conditionKey.indexOf("lightning") >= 0
    readonly property bool foggy: conditionKey.indexOf("fog") >= 0 || conditionKey.indexOf("mist") >= 0 || conditionKey.indexOf("haze") >= 0
    readonly property bool cloudy: conditionKey.indexOf("cloud") >= 0 || conditionKey.indexOf("overcast") >= 0
    readonly property real windBoost: Math.max(0.25, weatherData.intWindSpeed ? weatherData.intWindSpeed() / 18 : 0.45)

    LibWeather.WeatherData { id: weatherData }

    function toggleWindowSize() {
        if (root.visibility === Window.FullScreen || root.visibility === Window.Maximized) {
            root.visibility = Window.Windowed
            root.width = Math.min(1180, Screen.width - 110)
            root.height = Math.min(760, Screen.height - 110)
            root.x = Math.round((Screen.width - root.width) / 2)
            root.y = Math.round((Screen.height - root.height) / 2)
            root.compactMode = true
        } else {
            root.visibility = Window.FullScreen
            root.compactMode = false
        }
    }

    function minimizeApp() {
        root.showMinimized()
    }

    function openUpdateCenter() {
        updateDialog.open()
        updateManager.checkForUpdates()
    }

    function moonPhaseName(date) {
        var lp = 2551443
        var now = date.getTime() / 1000
        var newMoon = new Date(2001, 0, 24, 13, 7, 0).getTime() / 1000
        var phase = ((now - newMoon) % lp) / lp
        if (phase < 0.03 || phase > 0.97) return "New Moon"
        if (phase < 0.22) return "Waxing Crescent"
        if (phase < 0.28) return "First Quarter"
        if (phase < 0.47) return "Waxing Gibbous"
        if (phase < 0.53) return "Full Moon"
        if (phase < 0.72) return "Waning Gibbous"
        if (phase < 0.78) return "Last Quarter"
        return "Waning Crescent"
    }

    Component.onCompleted: {
        weatherData.temperatureUnitId = 1
        if (weatherData.displayUnits)
            weatherData.displayUnits.temperatureUnitId = 1
        weatherData.refresh()
        liveWeather.refresh()
        updateManager.checkForUpdates()
    }

    menuBar: MenuBar {
        Menu {
            title: "DynamicWeather Beta 2.6 • Build 260"
            Action { text: "About ModernWeatherApp"; onTriggered: aboutDialog.open() }
            Action { text: "Refresh Live Weather"; onTriggered: { weatherData.refresh(); liveWeather.refresh() } }
            Action { text: "Minimize"; onTriggered: root.minimizeApp() }
            Action { text: root.compactMode ? "Big" : "Small"; onTriggered: root.toggleWindowSize() }
            MenuSeparator {}
            Action { text: "Exit"; shortcut: StandardKey.Quit; onTriggered: Qt.quit() }
        }
    }

    Timer {
        interval: 16
        running: true
        repeat: true
        onTriggered: {
            root.sceneTime += 0.016
            sky.requestPaint()
            lightOverlay.requestPaint()
        }
    }

    Timer {
        id: liveRefreshTimer
        interval: 10 * 60 * 1000
        running: root.autoRefreshEnabled
        repeat: true
        onTriggered: { weatherData.refresh(); liveWeather.refresh() }
    }

    Dialog {
        id: aboutDialog
        modal: true
        title: "About ModernWeatherApp"
        anchors.centerIn: Overlay.overlay
        standardButtons: Dialog.Ok
        background: Rectangle { radius: 30; color: "#fbffffff"; border.color: "#a0ffffff"; border.width: 1 }
        contentItem: ScrollView {
            implicitWidth: Math.min(root.width * 0.86, 650)
            implicitHeight: Math.min(root.height * 0.78, 620)
            clip: true
            ColumnLayout {
                width: parent.availableWidth
                spacing: 14
                Image { source: "assets/branding/dynamicweather-logo.png"; Layout.preferredWidth: 260; Layout.preferredHeight: 146; Layout.alignment: Qt.AlignHCenter; fillMode: Image.PreserveAspectFit; smooth: true }
                Label { text: "DynamicWeather"; font.pixelSize: 32; font.bold: true; color: "#0f172a"; Layout.fillWidth: true; horizontalAlignment: Text.AlignHCenter }
                Label { text: "Version 2.6 beta • Build 260"; font.pixelSize: 18; color: "#334155"; Layout.fillWidth: true; horizontalAlignment: Text.AlignHCenter }
                Label { text: "Developer: Ricky McElroy"; font.pixelSize: 17; font.bold: true; color: "#1e293b"; Layout.fillWidth: true; horizontalAlignment: Text.AlignHCenter }
                Rectangle { Layout.fillWidth: true; height: 1; color: "#d7e2ee" }
                Label { text: "Updates completed"; font.pixelSize: 18; font.bold: true; color: "#0f172a"; Layout.fillWidth: true }
                Label {
                    text: "• Apple/Google-inspired glass redesign\n• Stronger text contrast and cleaner spacing\n• Live animated sky with drifting cloud layers\n• Moving rain, snow, fog, stars, sun glow, and storm lightning\n• Top controls for About, Live Weather, Minimize, Small/Big, and Exit\n• Fahrenheit display by default\n• Home Page and Learn More website buttons\n• New Radar, Sun/Moon, Alerts, and Maps feature panels
• Beta 2.0 graphic top tabs and day-by-day animated forecast experience
• DynamicWeather app icon and stronger branded identity
• Auto-refresh support for live weather updates
• Lightning Lab, satellite motion, and richer weather tools drawer
• Beta 2.3 Auto Update Center with KDrive version checking
• Install Update flow that can download a new ZIP, launch the updater helper, rebuild, and relaunch"
                    wrapMode: Text.WordWrap
                    color: "#334155"
                    lineHeight: 1.14
                    Layout.fillWidth: true
                }
                Label { text: "Future updates coming soon"; font.pixelSize: 18; font.bold: true; color: "#0f172a"; Layout.fillWidth: true }
                Label {
                    text: "• Interactive weather radar\n• Severe-weather notifications\n• Built-in city search and saved locations\n• Custom themes and accent colors\n• Sunrise, sunset, and moon-phase panels\n• Weather maps and satellite imagery\n• Deeper forecast insights and historical weather statistics\n• More cinematic animations and smoother day/night transitions
• Live radar tile provider integration
• More detailed moon and sunrise forecast cards
• Push-style severe weather notifications
• Full self-updating release channel using KDrive ZIP downloads"
                    wrapMode: Text.WordWrap
                    color: "#334155"
                    lineHeight: 1.14
                    Layout.fillWidth: true
                }
                RowLayout {
                    Layout.alignment: Qt.AlignHCenter
                    spacing: 12
                    Button { text: "Home Page"; onClicked: Qt.openUrlExternally(root.homeUrl) }
                    Button { text: "Learn More"; onClicked: Qt.openUrlExternally(root.learnMoreUrl) }
                }
            }
        }
    }


    Dialog {
        id: updateDialog
        modal: true
        title: updateManager.updateAvailable ? "Update Available" : "DynamicWeather Updates"
        anchors.centerIn: Overlay.overlay
        width: Math.min(root.width * 0.62, 780)
        height: Math.min(root.height * 0.72, 620)
        padding: 18
        closePolicy: Popup.CloseOnEscape | Popup.CloseOnPressOutside
        background: Rectangle {
            radius: 28
            color: root.isNight ? "#f2121b2f" : "#f7ffffff"
            border.color: updateManager.updateAvailable ? "#f0abfc" : "#a5f3fc"
            border.width: 1
        }
        contentItem: ColumnLayout {
            width: updateDialog.availableWidth
            height: updateDialog.availableHeight
            spacing: 14

            RowLayout {
                Layout.fillWidth: true
                Image { source: "assets/branding/dynamicweather-icon.png"; Layout.preferredWidth: 58; Layout.preferredHeight: 58; fillMode: Image.PreserveAspectFit }
                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 0
                    Label { text: updateManager.updateAvailable ? "Update Available" : "You are up to date"; color: "#0f172a"; font.pixelSize: 24; font.bold: true; Layout.fillWidth: true }
                    Label { text: updateManager.status; color: "#334155"; font.pixelSize: 14; Layout.fillWidth: true; elide: Text.ElideRight }
                }
                Rectangle {
                    Layout.preferredWidth: 164
                    Layout.preferredHeight: 44
                    radius: 22
                    color: updateManager.updateAvailable ? "#7c3aed" : "#0891b2"
                    Label { anchors.centerIn: parent; text: updateManager.updateAvailable ? "READY" : "CURRENT"; color: "white"; font.bold: true }
                }
                PillButton { text: "✕"; implicitWidth: 52; onClicked: updateDialog.close() }
            }

            GridLayout {
                Layout.fillWidth: true
                columns: 2
                columnSpacing: 12
                rowSpacing: 12
                FeatureInfoCard { title: "Current Version"; value: updateManager.currentVersion; detail: "Installed build " + updateManager.currentBuild }
                FeatureInfoCard { title: "Latest Version"; value: updateManager.latestVersion === "" ? "Checking..." : updateManager.latestVersion; detail: updateManager.latestBuild > 0 ? ("Remote build " + updateManager.latestBuild) : "Waiting for version.json" }
                FeatureInfoCard { title: "Channel"; value: updateManager.channel === "" ? "Beta" : updateManager.channel; detail: updateManager.releaseDate === "" ? "GitHub raw JSON" : updateManager.releaseDate }
                FeatureInfoCard { title: "Status"; value: updateManager.updateAvailable ? "Ready" : "Up to date"; detail: updateManager.updateAvailable ? "A newer ZIP can be installed." : "No newer build detected." }
            }

            GlassPanel {
                Layout.fillWidth: true
                Layout.fillHeight: true
                color: updateManager.updateAvailable ? "#884c1d95" : "#66364e63"
                border.color: updateManager.updateAvailable ? "#f0abfc" : "#93c5fd"
                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: 16
                    spacing: 8
                    Label { text: updateManager.message === "" ? "DynamicWeather checks your GitHub version.json feed for updates." : updateManager.message; color: "white"; font.bold: true; font.pixelSize: 16; wrapMode: Text.WordWrap; Layout.fillWidth: true; style: Text.Raised; styleColor: "#80000000" }
                    ScrollView {
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        clip: true
                        Label { width: parent.availableWidth; text: updateManager.releaseNotes === "" ? "When latest_build is higher than the installed build, Install Update turns on. Add a direct ZIP link in download_url to enable one-click install." : updateManager.releaseNotes; color: "#e0f2fe"; wrapMode: Text.WordWrap }
                    }
                }
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: 10
                PillButton { text: updateManager.busy ? "Checking..." : "Check Again"; enabled: !updateManager.busy; onClicked: updateManager.checkForUpdates() }
                PillButton { text: "Install Update"; enabled: updateManager.canInstall && !updateManager.busy; glow: updateManager.canInstall; onClicked: updateManager.installUpdate() }
                PillButton { text: "Open Download"; onClicked: updateManager.openDownloadPage() }
                PillButton { text: "Open Version JSON"; onClicked: updateManager.openUpdatePage() }
            }
        }
    }

    Item {
        id: page
        anchors.fill: parent
        clip: true

        Rectangle {
            anchors.fill: parent
            gradient: Gradient {
                GradientStop { position: 0.0; color: root.isNight ? "#020617" : "#0756d8" }
                GradientStop { position: 0.42; color: root.isNight ? "#111b3c" : "#37a9ff" }
                GradientStop { position: 1.0; color: root.isNight ? "#31124d" : "#d8f7ff" }
            }
        }

        Canvas {
            id: sky
            anchors.fill: parent
            opacity: 1
            onPaint: {
                var ctx = getContext("2d")
                var w = width, h = height, t = root.sceneTime
                ctx.clearRect(0, 0, w, h)
                drawCelestial(ctx, w, h, t)
                drawCloudLayer(ctx, w, h, t, 0.16, 1.25, 0.18, 0.22)
                drawCloudLayer(ctx, w, h, t, 0.33, 1.85, 0.13, 0.36)
                drawCloudLayer(ctx, w, h, t, 0.58, 2.25, 0.09, -0.25)
                if (root.rainy) drawRain(ctx, w, h, t, root.stormy ? 180 : 115)
                if (root.snowy) drawSnow(ctx, w, h, t, 120)
                if (root.foggy || root.cloudy || root.rainy) drawFog(ctx, w, h, t)
                if (root.stormy) drawLightning(ctx, w, h, t)
                drawGroundGlow(ctx, w, h, t)
            }
            function drawCelestial(ctx, w, h, t) {
                if (root.isNight) {
                    for (var i = 0; i < 125; ++i) {
                        var x = (i * 103) % Math.max(1, w)
                        var y = (i * 47) % Math.max(1, h * 0.58)
                        var r = 0.7 + (i % 5) * 0.28
                        ctx.globalAlpha = 0.18 + Math.abs(Math.sin(t * 1.4 + i * 0.7)) * 0.55
                        ctx.fillStyle = "white"
                        ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill()
                    }
                    ctx.globalAlpha = 1
                    var moonX = w * 0.78 + Math.sin(t * 0.12) * 10
                    var moonY = h * 0.18 + Math.cos(t * 0.10) * 7
                    var moon = ctx.createRadialGradient(moonX, moonY, 4, moonX, moonY, 115)
                    moon.addColorStop(0, "rgba(255,255,245,0.95)")
                    moon.addColorStop(0.22, "rgba(205,220,255,0.35)")
                    moon.addColorStop(1, "rgba(255,255,255,0)")
                    ctx.fillStyle = moon
                    ctx.beginPath(); ctx.arc(moonX, moonY, 115, 0, Math.PI * 2); ctx.fill()
                } else {
                    var sunX = w * 0.79 + Math.sin(t * 0.16) * 16
                    var sunY = h * 0.19 + Math.cos(t * 0.13) * 9
                    var sun = ctx.createRadialGradient(sunX, sunY, 10, sunX, sunY, Math.max(w, h) * 0.35)
                    sun.addColorStop(0, "rgba(255,255,230,0.98)")
                    sun.addColorStop(0.16, "rgba(255,219,116,0.55)")
                    sun.addColorStop(1, "rgba(255,255,255,0)")
                    ctx.fillStyle = sun
                    ctx.beginPath(); ctx.arc(sunX, sunY, Math.max(w, h) * 0.35, 0, Math.PI * 2); ctx.fill()
                }
                ctx.globalAlpha = 1
            }
            function drawCloudLayer(ctx, w, h, t, yFactor, scale, alpha, offset) {
                var speed = (14 + root.windBoost * 18) / scale
                var x = ((t * speed + offset * w) % (w + 620 * scale)) - 620 * scale
                drawCloud(ctx, x, h * yFactor + Math.sin(t * 0.25 + offset) * 9, scale, alpha)
                drawCloud(ctx, x + 520 * scale, h * (yFactor + 0.03), scale * 0.82, alpha * 0.72)
            }
            function drawCloud(ctx, x, y, s, alpha) {
                ctx.save()
                ctx.fillStyle = "rgba(255,255,255," + alpha + ")"
                ctx.beginPath()
                ctx.ellipse(x + 80*s, y + 42*s, 84*s, 36*s, 0, 0, Math.PI*2)
                ctx.ellipse(x + 158*s, y + 20*s, 98*s, 52*s, 0, 0, Math.PI*2)
                ctx.ellipse(x + 254*s, y + 44*s, 118*s, 47*s, 0, 0, Math.PI*2)
                ctx.ellipse(x + 340*s, y + 57*s, 86*s, 34*s, 0, 0, Math.PI*2)
                ctx.fill(); ctx.restore()
            }
            function drawRain(ctx, w, h, t, count) {
                ctx.save()
                ctx.strokeStyle = root.stormy ? "rgba(220,238,255,0.72)" : "rgba(210,235,255,0.55)"
                ctx.lineWidth = root.stormy ? 2.25 : 1.45
                for (var i = 0; i < count; ++i) {
                    var x = (i * 67 + t * (270 + root.windBoost * 95)) % (w + 190) - 95
                    var y = (i * 109 + t * (660 + root.windBoost * 140)) % (h + 210) - 110
                    ctx.globalAlpha = 0.25 + (i % 6) * 0.08
                    ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x - 26 - root.windBoost * 9, y + 62); ctx.stroke()
                }
                ctx.globalAlpha = 1; ctx.restore()
            }
            function drawSnow(ctx, w, h, t, count) {
                ctx.save(); ctx.fillStyle = "rgba(255,255,255,0.86)"
                for (var i = 0; i < count; ++i) {
                    var x = (i * 83 + Math.sin(t * 0.9 + i) * 52 + t * 18) % (w + 120) - 60
                    var y = (i * 59 + t * (55 + (i % 8) * 7)) % (h + 100) - 50
                    var r = 1.25 + (i % 6) * 0.55
                    ctx.globalAlpha = 0.34 + (i % 7) * 0.075
                    ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI*2); ctx.fill()
                }
                ctx.globalAlpha = 1; ctx.restore()
            }
            function drawFog(ctx, w, h, t) {
                ctx.save()
                for (var i = 0; i < 5; ++i) {
                    var y = h * (0.48 + i * 0.10) + Math.sin(t * 0.35 + i) * 14
                    var grad = ctx.createLinearGradient(0, y - 32, 0, y + 32)
                    grad.addColorStop(0, "rgba(255,255,255,0)")
                    grad.addColorStop(0.5, root.isNight ? "rgba(255,255,255,0.07)" : "rgba(255,255,255,0.17)")
                    grad.addColorStop(1, "rgba(255,255,255,0)")
                    ctx.fillStyle = grad
                    var x = ((t * (12 + i * 3)) % (w + 260)) - 260
                    ctx.fillRect(x, y - 36, w + 520, 72)
                }
                ctx.restore()
            }
            function drawLightning(ctx, w, h, t) {
                if ((Math.floor(t * 1.1) % 8) !== 0 || Math.sin(t * 22) < 0.72) return
                ctx.save(); ctx.strokeStyle = "rgba(255,255,255,0.95)"; ctx.lineWidth = 3.2; ctx.shadowBlur = 30; ctx.shadowColor = "white"
                var x = w * (0.52 + 0.18 * Math.sin(t * 0.7)); var y = h * 0.06
                ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x - 40, y + 96); ctx.lineTo(x + 24, y + 88); ctx.lineTo(x - 30, y + 210); ctx.lineTo(x + 8, y + 170); ctx.stroke(); ctx.restore()
            }
            function drawGroundGlow(ctx, w, h, t) {
                var g = ctx.createLinearGradient(0, h * 0.54, 0, h)
                g.addColorStop(0, "rgba(255,255,255,0)")
                g.addColorStop(1, root.isNight ? "rgba(3,7,18,0.46)" : "rgba(255,255,255,0.24)")
                ctx.fillStyle = g; ctx.fillRect(0, h * 0.54, w, h)
            }
        }

        Canvas {
            id: lightOverlay
            anchors.fill: parent
            opacity: root.stormy ? 0.55 : 0.25
            onPaint: {
                var ctx = getContext("2d")
                ctx.clearRect(0, 0, width, height)
                if (root.stormy && (Math.floor(root.sceneTime * 1.1) % 8) === 0 && Math.sin(root.sceneTime * 22) > 0.72) {
                    ctx.fillStyle = "rgba(255,255,255,0.25)"
                    ctx.fillRect(0, 0, width, height)
                }
            }
        }

        Rectangle { anchors.fill: parent; color: root.isNight ? "#28000000" : "#11000000" }

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: Math.max(22, 30 * root.scaleFactor)
            spacing: Math.round(16 * root.scaleFactor)

            GlassBar {
                Layout.fillWidth: true
                Layout.preferredHeight: Math.round(92 * root.scaleFactor)
                RowLayout {
                    anchors.fill: parent
                    anchors.leftMargin: 18; anchors.rightMargin: 10
                    spacing: 10
                    Image { source: "assets/branding/dynamicweather-icon.png"; Layout.preferredWidth: 56; Layout.preferredHeight: 56; fillMode: Image.PreserveAspectFit; opacity: 0.98 }
                    ColumnLayout {
                        Layout.preferredWidth: Math.round(270 * root.scaleFactor)
                        spacing: 1
                        Label { text: "DynamicWeather"; color: "white"; font.pixelSize: Math.round(25 * root.scaleFactor); font.bold: true; elide: Text.ElideRight; Layout.fillWidth: true; style: Text.Raised; styleColor: "#70000000" }
                        Label { text: root.buildBadge; color: "#e9fbff"; font.pixelSize: Math.round(13 * root.scaleFactor); font.bold: true; elide: Text.ElideRight; Layout.fillWidth: true }
                        Label { text: root.placeText; color: "#dff7ff"; font.pixelSize: Math.round(12 * root.scaleFactor); elide: Text.ElideRight; Layout.fillWidth: true }
                        Label { text: weatherData.errorMessage || root.conditionText; color: weatherData.errorMessage ? "#ffffc7c7" : "#ccffffff"; font.pixelSize: Math.round(12 * root.scaleFactor); font.capitalization: Font.Capitalize; elide: Text.ElideRight; Layout.fillWidth: true }
                    }
                    Item { Layout.fillWidth: true }
                    Rectangle {
                        Layout.preferredWidth: Math.round(185 * root.scaleFactor)
                        Layout.preferredHeight: 46
                        radius: 23
                        color: updateManager.updateAvailable ? "#7c22c55e" : "#3022d3ee"
                        border.color: updateManager.updateAvailable ? "#f0abfc" : "#a5f3fc"
                        border.width: 1
                        RowLayout {
                            anchors.fill: parent
                            anchors.leftMargin: 12
                            anchors.rightMargin: 12
                            spacing: 8
                            Label { text: updateManager.updateAvailable ? "⚡" : "✓"; color: "white"; font.pixelSize: 18 }
                            ColumnLayout {
                                Layout.fillWidth: true
                                spacing: -1
                                Label { text: root.buildBadge; color: "white"; font.pixelSize: 11; font.bold: true; Layout.fillWidth: true; elide: Text.ElideRight }
                                Label { text: updateManager.updateAvailable ? "Update found" : "Current build"; color: "#dff7ff"; font.pixelSize: 10; Layout.fillWidth: true; elide: Text.ElideRight }
                            }
                        }
                        MouseArea {
                            anchors.fill: parent
                            cursorShape: Qt.PointingHandCursor
                            onClicked: root.openUpdateCenter()
                        }
                    }
                    PillButton { text: liveWeather.loading ? "Updating…" : "Live"; enabled: !liveWeather.loading; onClicked: { weatherData.refresh(); liveWeather.refresh() } }
                    PillButton { text: "About"; onClicked: aboutDialog.open() }
                    PillButton { text: "—"; implicitWidth: 48; onClicked: root.minimizeApp() }
                    PillButton { text: root.compactMode ? "Big" : "Small"; implicitWidth: 72; onClicked: root.toggleWindowSize() }
                    PillButton { text: "Exit"; implicitWidth: 68; onClicked: Qt.quit() }
                }
            }

            GlassBar {
                Layout.fillWidth: true
                Layout.preferredHeight: Math.round(76 * root.scaleFactor)
                color: root.isNight ? "#5b07111f" : "#3dffffff"
                RowLayout {
                    anchors.fill: parent
                    anchors.leftMargin: 16
                    anchors.rightMargin: 16
                    spacing: 10
                    Label { text: "Categories"; color: "white"; font.bold: true; font.pixelSize: Math.round(15 * root.scaleFactor); style: Text.Raised; styleColor: "#80000000" }
                    TopNavButton { text: "7 Days"; emoji: "📅"; selected: root.featureDrawerOpen && root.featureTab === 4; onClicked: { root.featureTab = 4; root.featureDrawerOpen = true } }
                    TopNavButton { text: "Radar"; emoji: "📡"; selected: root.featureDrawerOpen && root.featureTab === 0; onClicked: { root.featureTab = 0; root.featureDrawerOpen = true } }
                    TopNavButton { text: "Sun/Moon"; emoji: "🌙"; selected: root.featureDrawerOpen && root.featureTab === 1; onClicked: { root.featureTab = 1; root.featureDrawerOpen = true } }
                    TopNavButton { text: "Alerts"; emoji: "⚠"; selected: root.featureDrawerOpen && root.featureTab === 2; onClicked: { root.featureTab = 2; root.featureDrawerOpen = true } }
                    TopNavButton { text: "Maps"; emoji: "🛰"; selected: root.featureDrawerOpen && root.featureTab === 3; onClicked: { root.featureTab = 3; root.featureDrawerOpen = true } }
                    TopNavButton { text: "Lightning"; emoji: "⚡"; selected: root.featureDrawerOpen && root.featureTab === 5; onClicked: { root.featureTab = 5; root.featureDrawerOpen = true } }
                    TopNavButton { text: updateManager.updateAvailable ? "Update!" : "Updates"; emoji: "⬆"; selected: updateDialog.visible; onClicked: root.openUpdateCenter() }
                }
            }

            GlassPanel {
                Layout.fillWidth: true
                Layout.preferredHeight: root.hasSevereAlert ? Math.round(58 * root.scaleFactor) : 0
                visible: root.hasSevereAlert
                color: "#9a5b1717"
                border.color: "#fca5a5"
                RowLayout {
                    anchors.fill: parent
                    anchors.margins: 14
                    spacing: 12
                    Label { text: "⚠"; font.pixelSize: 24; color: "#fff7ed" }
                    Label { text: root.severeAlertText; color: "white"; font.bold: true; font.pixelSize: Math.round(15 * root.scaleFactor); Layout.fillWidth: true; wrapMode: Text.WordWrap; style: Text.Raised; styleColor: "#70000000" }
                    PillButton { text: "Refresh"; implicitWidth: 88; onClicked: weatherData.refresh() }
                }
            }

            Item { Layout.fillHeight: true }

            RowLayout {
                Layout.fillWidth: true
                spacing: Math.round(34 * root.scaleFactor)
                Item {
                    Layout.preferredWidth: Math.round(230 * root.scaleFactor)
                    Layout.preferredHeight: Math.round(230 * root.scaleFactor)
                    Image {
                        anchors.centerIn: parent
                        width: parent.width
                        height: parent.height
                        source: "images/" + root.cleanIconName(liveWeather.iconName || weatherData.currentConditionIconName || "weather-none-available")
                        fillMode: Image.PreserveAspectFit
                        opacity: 0.98
                        scale: 1 + Math.sin(root.sceneTime * 1.35) * 0.025
                        rotation: root.stormy ? Math.sin(root.sceneTime * 8.5) * 1.8 : Math.sin(root.sceneTime * 0.75) * 1.0
                    }
                }
                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 4
                    Label { text: liveWeather.temperatureText || weatherData.currentTempFormatted || "--°"; color: "white"; font.pixelSize: Math.round(132 * root.scaleFactor); font.weight: Font.Light; lineHeight: 0.86; style: Text.Raised; styleColor: "#70000000" }
                    Label { text: root.rainy ? "Live rain motion across the glass" : root.snowy ? "Soft animated snow and winter motion" : root.stormy ? "Storm lighting and active sky effects" : root.foggy ? "Layered mist and atmospheric motion" : "Clean, cinematic live weather"; color: "#efffffff"; font.pixelSize: Math.round(19 * root.scaleFactor); font.bold: true; style: Text.Raised; styleColor: "#50000000" }
                }
            }

            Item { Layout.fillHeight: true }

            GridLayout {
                Layout.fillWidth: true
                columns: width > 820 ? 4 : 2
                columnSpacing: 14
                rowSpacing: 14
                MetricCard { title: "Wind"; value: liveWeather.windText || weatherData.windDisplay || "--"; icon: "weather-wind" }
                MetricCard { title: "Humidity"; value: liveWeather.humidityText || (weatherData.currentWeather.humidity !== undefined ? Math.round(weatherData.currentWeather.humidity) + "%" : "--"); icon: "weather-showers" }
                MetricCard { title: "Pressure"; value: liveWeather.pressureText || (weatherData.currentWeather.pressureHpa ? weatherData.displayUnits.formatPressure(weatherData.currentWeather.pressureHpa) : "--"); icon: "weather-many-clouds" }
                MetricCard { title: "Clouds"; value: liveWeather.cloudText || (weatherData.currentWeather.cloudiness !== undefined ? Math.round(weatherData.currentWeather.cloudiness) + "%" : "--"); icon: "weather-clouds" }
            }

            ListView {
                Layout.fillWidth: true
                Layout.preferredHeight: Math.round(132 * root.scaleFactor)
                orientation: ListView.Horizontal
                spacing: 14
                clip: true
                visible: weatherData.dailyForecastModel && weatherData.dailyForecastModel.count > 0
                model: weatherData.dailyForecastModel
                delegate: ForecastCard {
                    day: dayLabel || ""
                    low: tempLow !== undefined ? weatherData.displayUnits.formatTemperature(tempLow, true) : "--"
                    high: tempHigh !== undefined ? weatherData.displayUnits.formatTemperature(tempHigh, true) : "--"
                    iconSource: forecastIcon || "weather-none-available"
                    cardWidth: Math.round(160 * root.scaleFactor)
                    MouseArea { anchors.fill: parent; onClicked: { root.dayTab = index; root.featureTab = 4; root.featureDrawerOpen = true } }
                }
            }

        }


        Rectangle {
            id: scrim
            anchors.fill: parent
            color: "#66000000"
            visible: root.featureDrawerOpen
            opacity: root.featureDrawerOpen ? 1 : 0
            Behavior on opacity { NumberAnimation { duration: 180 } }
            MouseArea { anchors.fill: parent; onClicked: root.featureDrawerOpen = false }
        }

        GlassPanel {
            id: featureDrawer
            width: Math.min(root.width * 0.86, Math.round(430 * root.scaleFactor))
            height: Math.min(root.height - 110, Math.round(650 * root.scaleFactor))
            x: root.featureDrawerOpen ? root.width - width - Math.round(28 * root.scaleFactor) : root.width + 40
            y: Math.round(104 * root.scaleFactor)
            z: 50
            color: root.isNight ? "#b707111f" : "#ccf8fbff"
            border.color: "#d8ffffff"
            layer.enabled: true
            Behavior on x { NumberAnimation { duration: 300; easing.type: Easing.OutCubic } }

            Rectangle {
                anchors.fill: parent
                anchors.margins: -2
                radius: parent.radius + 2
                color: "transparent"
                border.color: "#70a5f3fc"
                border.width: 2
                opacity: 0.75 + Math.sin(root.sceneTime * 2.2) * 0.18
            }

            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 18
                spacing: 12

                RowLayout {
                    Layout.fillWidth: true
                    Label {
                        text: "Tools"
                        Layout.fillWidth: true
                        color: root.isNight ? "white" : "#071322"
                        font.pixelSize: Math.round(27 * root.scaleFactor)
                        font.bold: true
                        style: Text.Raised
                        styleColor: "#55000000"
                    }
                    PillButton { text: "✕"; implicitWidth: 52; onClicked: root.featureDrawerOpen = false }
                }

                Label {
                    text: "Radar, sun/moon, alerts, and satellite views stay tucked away until you need them."
                    Layout.fillWidth: true
                    wrapMode: Text.WordWrap
                    color: root.isNight ? "#e5f4ff" : "#26384c"
                    font.pixelSize: Math.round(14 * root.scaleFactor)
                }

                GridLayout {
                    Layout.fillWidth: true
                    columns: 2
                    columnSpacing: 9
                    rowSpacing: 9
                    FeatureMenuButton { text: "Radar"; emoji: "📡"; selected: root.featureTab === 0; onClicked: root.featureTab = 0 }
                    FeatureMenuButton { text: "Sun + Moon"; emoji: "🌙"; selected: root.featureTab === 1; onClicked: root.featureTab = 1 }
                    FeatureMenuButton { text: "Alerts"; emoji: "⚠️"; selected: root.featureTab === 2; onClicked: root.featureTab = 2 }
                    FeatureMenuButton { text: "Maps"; emoji: "🛰️"; selected: root.featureTab === 3; onClicked: root.featureTab = 3 }
                    FeatureMenuButton { text: "7-Day"; emoji: "📅"; selected: root.featureTab === 4; onClicked: root.featureTab = 4 }
                    FeatureMenuButton { text: "Lightning"; emoji: "⚡"; selected: root.featureTab === 5; onClicked: root.featureTab = 5 }
                    FeatureMenuButton { text: updateManager.updateAvailable ? "Update Available" : "Updates"; emoji: "⬆"; selected: updateDialog.visible; onClicked: root.openUpdateCenter() }
                }

                StackLayout {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    currentIndex: root.featureTab

                    DrawerFeaturePage {
                        title: "Interactive Radar"
                        subtitle: "Animated radar preview for precipitation movement."
                        RadarCanvas { anchors.fill: parent; anchors.margins: 0 }
                        Label { anchors.left: parent.left; anchors.right: parent.right; anchors.bottom: parent.bottom; anchors.margins: 14; text: "Next step: connect live radar tiles from your chosen provider/API key."; color: "white"; wrapMode: Text.WordWrap; font.bold: true; style: Text.Raised; styleColor: "#90000000" }
                    }

                    DrawerFeaturePage {
                        title: "Sunrise + Moon"
                        subtitle: "Daily light timing and moon phase tracking."
                        GridLayout {
                            anchors.fill: parent
                            anchors.topMargin: 74
                            columns: 1
                            rowSpacing: 10
                            FeatureInfoCard { title: "Sunrise"; value: root.sunriseText; detail: "Morning light tracking" }
                            FeatureInfoCard { title: "Sunset"; value: root.sunsetText; detail: "Evening sky timing" }
                            FeatureInfoCard { title: "Moon Phase"; value: root.moonPhaseText; detail: "Calculated lunar phase" }
                        }
                    }

                    DrawerFeaturePage {
                        title: root.hasSevereAlert ? "Active Weather Notice" : "Severe Alerts"
                        subtitle: root.severeAlertText
                        ColumnLayout {
                            anchors.fill: parent
                            anchors.topMargin: 72
                            spacing: 14
                            Label { text: root.hasSevereAlert ? "⚠" : "✓"; color: root.hasSevereAlert ? "#fecaca" : "#bbf7d0"; font.pixelSize: 76; Layout.alignment: Qt.AlignHCenter }
                            Label { text: root.severeAlertText; color: "white"; wrapMode: Text.WordWrap; font.pixelSize: Math.round(17 * root.scaleFactor); font.bold: true; Layout.fillWidth: true; horizontalAlignment: Text.AlignHCenter; style: Text.Raised; styleColor: "#80000000" }
                            Label { text: "Future live notifications can connect to NWS, OpenWeatherMap alerts, or another severe-weather feed."; color: "#dbeafe"; wrapMode: Text.WordWrap; Layout.fillWidth: true; horizontalAlignment: Text.AlignHCenter }
                            Item { Layout.fillHeight: true }
                            PillButton { text: "Refresh Live Weather"; Layout.alignment: Qt.AlignHCenter; onClicked: weatherData.refresh() }
                        }
                    }

                    DrawerFeaturePage {
                        title: "Maps + Satellite"
                        subtitle: "A polished weather map space for satellite/radar layers."
                        MapCanvas { anchors.fill: parent }
                        Label { anchors.left: parent.left; anchors.right: parent.right; anchors.bottom: parent.bottom; anchors.margins: 14; text: "Live satellite imagery can be wired in when you choose a provider/API key."; color: "white"; wrapMode: Text.WordWrap; font.bold: true; style: Text.Raised; styleColor: "#90000000" }
                    }


                    DrawerFeaturePage {
                        title: "Animated 7-Day Forecast"
                        subtitle: "Tap a day to preview a cinematic mini weather card."
                        ColumnLayout {
                            anchors.fill: parent
                            anchors.topMargin: 72
                            anchors.leftMargin: 10
                            anchors.rightMargin: 10
                            spacing: 10
                            ListView {
                                Layout.fillWidth: true
                                Layout.preferredHeight: 118
                                orientation: ListView.Horizontal
                                spacing: 10
                                clip: true
                                model: weatherData.dailyForecastModel
                                delegate: DayPickerCard {
                                    day: dayLabel || "Day"
                                    low: tempLow !== undefined ? weatherData.displayUnits.formatTemperature(tempLow, true) : "--"
                                    high: tempHigh !== undefined ? weatherData.displayUnits.formatTemperature(tempHigh, true) : "--"
                                    iconSource: forecastIcon || "weather-none-available"
                                    modelIndex: index
                                    selected: index === root.dayTab
                                }
                            }
                            ForecastDetailCard { Layout.fillWidth: true; Layout.fillHeight: true }
                        }
                    }

                    DrawerFeaturePage {
                        title: "Lightning Lab"
                        subtitle: "Storm energy, pulse effects, and an animated lightning field."
                        LightningCanvas { anchors.fill: parent }
                        ColumnLayout { anchors.left: parent.left; anchors.right: parent.right; anchors.bottom: parent.bottom; anchors.margins: 16; spacing: 8
                            Label { text: root.stormy ? "Storm mode is active from current conditions." : "Preview mode: lightning effects activate automatically during storm conditions."; color: "white"; wrapMode: Text.WordWrap; font.bold: true; style: Text.Raised; styleColor: "#90000000" }
                            PillButton { text: "Refresh Storm Data"; Layout.alignment: Qt.AlignHCenter; onClicked: weatherData.refresh() }
                        }
                    }

                    DrawerFeaturePage {
                        title: updateManager.updateAvailable ? "Update Available" : "Update Center"
                        subtitle: updateManager.status
                        ColumnLayout {
                            anchors.fill: parent
                            anchors.topMargin: 72
                            anchors.leftMargin: 10
                            anchors.rightMargin: 10
                            spacing: 12

                            GridLayout {
                                Layout.fillWidth: true
                                columns: 2
                                columnSpacing: 10
                                rowSpacing: 10
                                FeatureInfoCard { title: "Current Version"; value: updateManager.currentVersion; detail: "Installed build " + updateManager.currentBuild }
                                FeatureInfoCard { title: "Latest Version"; value: updateManager.latestVersion === "" ? "Checking..." : updateManager.latestVersion; detail: updateManager.latestBuild > 0 ? ("Remote build " + updateManager.latestBuild) : "Waiting for version.json" }
                                FeatureInfoCard { title: "Channel"; value: updateManager.channel === "" ? "Beta" : updateManager.channel; detail: updateManager.releaseDate === "" ? "GitHub source" : updateManager.releaseDate }
                                FeatureInfoCard { title: updateManager.updateAvailable ? "Status" : "Status"; value: updateManager.updateAvailable ? "Ready" : "Up to date"; detail: updateManager.updateAvailable ? "A newer ZIP can be installed." : "No newer build detected." }
                            }

                            GlassPanel {
                                Layout.fillWidth: true
                                Layout.preferredHeight: 96
                                color: updateManager.updateAvailable ? "#884c1d95" : "#6620475f"
                                border.color: updateManager.updateAvailable ? "#f0abfc" : "#93c5fd"
                                ColumnLayout {
                                    anchors.fill: parent
                                    anchors.margins: 14
                                    spacing: 8
                                    Label { text: updateManager.message === "" ? "GitHub update check is connected." : updateManager.message; color: "white"; font.bold: true; font.pixelSize: 16; wrapMode: Text.WordWrap; Layout.fillWidth: true; style: Text.Raised; styleColor: "#80000000" }
                                    Label { text: updateManager.releaseNotes === "" ? "Shows build number, release notes, and install button when a newer build is found." : updateManager.releaseNotes; color: "#e0f2fe"; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                                }
                            }

                            RowLayout {
                                Layout.fillWidth: true
                                spacing: 10
                                PillButton { text: updateManager.busy ? "Checking..." : "Check Now"; enabled: !updateManager.busy; onClicked: updateManager.checkForUpdates() }
                                PillButton { text: "Install Update"; enabled: updateManager.canInstall && !updateManager.busy; glow: updateManager.canInstall; onClicked: updateManager.installUpdate() }
                                PillButton { text: "Open Version JSON"; onClicked: updateManager.openUpdatePage() }
                            }

                            Label {
                                text: "Use Check Now to test GitHub. If latest_build is higher than this build, Install Update turns on."
                                Layout.fillWidth: true
                                wrapMode: Text.WordWrap
                                color: "#dbeafe"
                                font.pixelSize: 12
                            }
                        }
                    }
                }
            }
        }


        Button {
            id: sevenDayArrow
            z: 60
            anchors.right: parent.right
            anchors.verticalCenter: parent.verticalCenter
            anchors.rightMargin: root.featureDrawerOpen ? Math.round(390 * root.scaleFactor) : 0
            width: 54
            height: 180
            text: root.featureDrawerOpen && root.featureTab === 4 ? "›" : "‹"
            onClicked: { root.featureTab = 4; root.featureDrawerOpen = !root.featureDrawerOpen }
            contentItem: ColumnLayout {
                spacing: 4
                Label { text: sevenDayArrow.text; color: "white"; font.pixelSize: 30; font.bold: true; Layout.alignment: Qt.AlignHCenter }
                Label { text: "Detailed\n7-Day"; color: "white"; font.pixelSize: 11; font.bold: true; horizontalAlignment: Text.AlignHCenter; Layout.alignment: Qt.AlignHCenter; style: Text.Raised; styleColor: "#80000000" }
            }
            background: Rectangle {
                radius: 24
                color: sevenDayArrow.hovered ? "#665eead4" : "#4d0f172a"
                border.color: "#a5f3fc"
                border.width: 1
                Rectangle { anchors.fill: parent; radius: parent.radius; color: "transparent"; border.color: "#67e8f9"; border.width: 2; opacity: 0.45 + Math.sin(root.sceneTime * 3) * 0.20 }
            }
        }

        BusyIndicator { anchors.centerIn: parent; running: weatherData.isLoading; visible: running }
    }

    component PillButton: Button {
        id: pill
        property bool glow: false
        implicitHeight: 44
        implicitWidth: Math.max(92, contentItem.implicitWidth + 34)
        contentItem: Label { text: pill.text; color: "white"; font.bold: true; horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter; style: Text.Raised; styleColor: "#66000000" }
        background: Rectangle {
            radius: height / 2
            color: pill.down ? "#62ffffff" : pill.hovered ? "#46ffffff" : pill.glow ? "#58a5f3fc" : "#2dffffff"
            border.color: pill.glow ? "#d8f9ff" : "#68ffffff"
            border.width: 1
            Behavior on color { ColorAnimation { duration: 130 } }
            Rectangle { anchors.fill: parent; radius: parent.radius; color: "transparent"; border.color: "#9be8ff"; border.width: 2; opacity: pill.glow ? 0.7 + Math.sin(root.sceneTime * 3) * 0.22 : 0 }
        }
        scale: pill.down ? 0.97 : pill.hovered ? 1.035 : 1.0
        Behavior on scale { NumberAnimation { duration: 140; easing.type: Easing.OutCubic } }
    }

    component GlassBar: Rectangle {
        radius: 28
        color: root.isNight ? "#7207121f" : "#4dffffff"
        border.color: "#82ffffff"
        border.width: 1
    }

    component GlassPanel: Rectangle {
        radius: 26
        color: root.isNight ? "#7307111f" : "#82ffffff"
        border.color: root.isNight ? "#78ffffff" : "#c0ffffff"
        border.width: 1
        scale: hover.hovered ? 1.022 : 1.0
        Behavior on scale { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }
        HoverHandler { id: hover }
    }

    component MetricCard: GlassPanel {
        property string title
        property string value
        property string icon
        Layout.fillWidth: true
        Layout.preferredHeight: Math.round(96 * root.scaleFactor)
        RowLayout {
            anchors.fill: parent
            anchors.margins: 16
            spacing: 14
            Image { source: "images/" + root.cleanIconName(icon); Layout.preferredWidth: 42; Layout.preferredHeight: 42; fillMode: Image.PreserveAspectFit; opacity: 0.95; rotation: Math.sin(root.sceneTime * 0.8) * 1.3 }
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 2
                Label { text: title; color: root.isNight ? "#ecffffff" : "#243244"; font.pixelSize: Math.round(12 * root.scaleFactor); font.bold: true }
                Label { text: value; color: root.isNight ? "white" : "#071322"; font.pixelSize: Math.round(21 * root.scaleFactor); font.bold: true; elide: Text.ElideRight; Layout.fillWidth: true }
            }
        }
    }

    component ForecastCard: GlassPanel {
        property string day
        property string low
        property string high
        property string iconSource
        property int cardWidth: 150
        width: cardWidth
        height: ListView.view ? ListView.view.height - 8 : 120
        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 9
            spacing: 2
            Label { text: day; color: root.isNight ? "white" : "#071322"; font.bold: true; horizontalAlignment: Text.AlignHCenter; Layout.fillWidth: true; elide: Text.ElideRight }
            Image { source: "images/" + root.cleanIconName(iconSource); Layout.alignment: Qt.AlignHCenter; Layout.preferredWidth: 48; Layout.preferredHeight: 48; fillMode: Image.PreserveAspectFit; y: Math.sin(root.sceneTime * 1.1 + index) * 2 }
            Label { text: high + " / " + low; color: root.isNight ? "#ecffffff" : "#1e293b"; font.bold: true; horizontalAlignment: Text.AlignHCenter; Layout.fillWidth: true }
        }
    }

    component FeatureTabButton: Button {
        id: tab
        property bool selected: false
        implicitHeight: 38
        Layout.fillWidth: true
        contentItem: Label { text: tab.text; color: "white"; font.bold: true; horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter; style: Text.Raised; styleColor: "#70000000" }
        background: Rectangle { radius: 18; color: tab.selected ? "#72ffffff" : tab.hovered ? "#38ffffff" : "#20ffffff"; border.color: "#70ffffff"; border.width: 1 }
    }



    component TopNavButton: Button {
        id: nav
        property string emoji: ""
        property bool selected: false
        implicitHeight: 54
        Layout.fillWidth: true
        contentItem: ColumnLayout {
            spacing: 0
            Label { text: nav.emoji; font.pixelSize: 18; Layout.alignment: Qt.AlignHCenter; horizontalAlignment: Text.AlignHCenter }
            Label { text: nav.text; color: "white"; font.bold: true; font.pixelSize: Math.round(11 * root.scaleFactor); horizontalAlignment: Text.AlignHCenter; Layout.fillWidth: true; style: Text.Raised; styleColor: "#80000000" }
        }
        background: Rectangle {
            radius: 20
            gradient: Gradient {
                GradientStop { position: 0; color: nav.selected ? "#8eeaffff" : nav.hovered ? "#4fffffff" : "#24ffffff" }
                GradientStop { position: 1; color: nav.selected ? "#663b82f6" : nav.hovered ? "#305eead4" : "#160ea5e9" }
            }
            border.color: nav.selected ? "#e0fbff" : "#65ffffff"
            border.width: nav.selected ? 2 : 1
            Rectangle { anchors.fill: parent; radius: parent.radius; color: "transparent"; border.color: "#a5f3fc"; border.width: 2; opacity: nav.selected ? 0.7 + Math.sin(root.sceneTime * 3.4) * 0.22 : 0 }
        }
        scale: nav.down ? 0.97 : nav.hovered ? 1.04 : 1.0
        Behavior on scale { NumberAnimation { duration: 120; easing.type: Easing.OutCubic } }
    }

    component DayPickerCard: Button {
        id: dayCard
        property string day
        property string low
        property string high
        property string iconSource
        property bool selected: false
        property int modelIndex: 0
        width: 112
        height: 108
        onClicked: root.dayTab = dayCard.modelIndex
        contentItem: ColumnLayout {
            anchors.margins: 4
            Label { text: dayCard.day; color: "white"; font.bold: true; horizontalAlignment: Text.AlignHCenter; Layout.fillWidth: true; elide: Text.ElideRight; style: Text.Raised; styleColor: "#80000000" }
            Image { source: "images/" + root.cleanIconName(dayCard.iconSource); Layout.alignment: Qt.AlignHCenter; Layout.preferredWidth: 42; Layout.preferredHeight: 42; fillMode: Image.PreserveAspectFit; y: Math.sin(root.sceneTime * 1.4 + index) * 3 }
            Label { text: dayCard.high + " / " + dayCard.low; color: "#f8fdff"; font.pixelSize: 12; font.bold: true; horizontalAlignment: Text.AlignHCenter; Layout.fillWidth: true }
        }
        background: Rectangle { radius: 22; color: dayCard.selected ? "#72a5f3fc" : dayCard.hovered ? "#42ffffff" : "#25ffffff"; border.color: dayCard.selected ? "#e0fbff" : "#68ffffff"; border.width: dayCard.selected ? 2 : 1 }
    }

    component ForecastDetailCard: GlassPanel {
        readonly property var itemData: weatherData.dailyForecastModel && weatherData.dailyForecastModel.count > root.dayTab ? weatherData.dailyForecastModel.get(root.dayTab) : null
        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 18
            spacing: 8
            RowLayout { Layout.fillWidth: true
                Label { text: itemData ? (itemData.dayLabel || "Forecast") : "Forecast"; color: root.isNight ? "white" : "#071322"; font.pixelSize: 26; font.bold: true; Layout.fillWidth: true }
                Image { source: "images/" + root.cleanIconName(itemData && itemData.forecastIcon ? itemData.forecastIcon : "weather-none-available"); Layout.preferredWidth: 64; Layout.preferredHeight: 64; fillMode: Image.PreserveAspectFit; rotation: Math.sin(root.sceneTime * 1.1) * 2 }
            }
            Label { text: itemData ? ((itemData.tempHigh !== undefined ? weatherData.displayUnits.formatTemperature(itemData.tempHigh, true) : "--") + " high • " + (itemData.tempLow !== undefined ? weatherData.displayUnits.formatTemperature(itemData.tempLow, true) : "--") + " low") : "Weather details loading"; color: root.isNight ? "#e0f2fe" : "#1f2c3d"; font.pixelSize: 19; font.bold: true; Layout.fillWidth: true }
            Label { text: "Animated daily preview: sky motion, day/night glow, moon phase, and storm effects respond to live conditions. Auto-refresh updates every 10 minutes while the app is open."; color: root.isNight ? "#dbeafe" : "#334155"; wrapMode: Text.WordWrap; Layout.fillWidth: true }
            Item { Layout.fillHeight: true }
            MiniSkyCanvas { Layout.fillWidth: true; Layout.preferredHeight: 96 }
        }
    }
    component FeatureMenuButton: Button {
        id: menuButton
        property string emoji: ""
        property bool selected: false
        Layout.fillWidth: true
        implicitHeight: 62
        contentItem: RowLayout {
            spacing: 8
            Label { text: menuButton.emoji; font.pixelSize: 22; Layout.alignment: Qt.AlignVCenter }
            Label { text: menuButton.text; color: "white"; font.bold: true; font.pixelSize: Math.round(14 * root.scaleFactor); Layout.fillWidth: true; verticalAlignment: Text.AlignVCenter; style: Text.Raised; styleColor: "#70000000" }
        }
        background: Rectangle {
            radius: 20
            color: menuButton.selected ? "#62a5f3fc" : menuButton.hovered ? "#3dffffff" : "#24ffffff"
            border.color: menuButton.selected ? "#e0fbff" : "#70ffffff"
            border.width: menuButton.selected ? 2 : 1
            Rectangle { anchors.fill: parent; radius: parent.radius; color: "transparent"; border.color: "#a5f3fc"; border.width: 2; opacity: menuButton.selected ? 0.55 + Math.sin(root.sceneTime * 3.2) * 0.2 : 0 }
            Behavior on color { ColorAnimation { duration: 160 } }
        }
        scale: menuButton.down ? 0.98 : menuButton.hovered ? 1.025 : 1.0
        Behavior on scale { NumberAnimation { duration: 130; easing.type: Easing.OutCubic } }
    }

    component DrawerFeaturePage: Item {
        property string title
        property string subtitle
        clip: true
        Rectangle {
            anchors.fill: parent
            radius: 24
            color: root.isNight ? "#5b020617" : "#4d0f172a"
            border.color: "#75ffffff"
            border.width: 1
        }
        Label {
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: parent.top
            anchors.margins: 16
            text: title
            color: "white"
            font.pixelSize: Math.round(22 * root.scaleFactor)
            font.bold: true
            style: Text.Raised
            styleColor: "#80000000"
            z: 5
        }
        Label {
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: parent.top
            anchors.topMargin: 48
            anchors.leftMargin: 16
            anchors.rightMargin: 16
            text: subtitle
            color: "#e0f2fe"
            wrapMode: Text.WordWrap
            font.pixelSize: Math.round(13 * root.scaleFactor)
            style: Text.Raised
            styleColor: "#80000000"
            z: 5
        }
    }

    component FeatureInfoCard: GlassPanel {
        property string title
        property string value
        property string detail
        Layout.fillWidth: true
        Layout.fillHeight: true
        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 14
            spacing: 6
            Label { text: title; color: root.isNight ? "#dbeafe" : "#1d4ed8"; font.pixelSize: Math.round(13 * root.scaleFactor); font.bold: true; Layout.fillWidth: true }
            Label { text: value; color: root.isNight ? "white" : "#071322"; font.pixelSize: Math.round(22 * root.scaleFactor); font.bold: true; wrapMode: Text.WordWrap; Layout.fillWidth: true }
            Label { text: detail; color: root.isNight ? "#dbeafe" : "#334155"; font.pixelSize: Math.round(12 * root.scaleFactor); wrapMode: Text.WordWrap; Layout.fillWidth: true }
        }
    }

    component RadarCanvas: Canvas {
        opacity: 0.96
        onPaint: {
            var ctx = getContext("2d"), w = width, h = height, t = root.sceneTime
            ctx.clearRect(0, 0, w, h)
            var g = ctx.createLinearGradient(0, 0, w, h)
            g.addColorStop(0, "rgba(14,165,233,0.45)"); g.addColorStop(1, "rgba(15,23,42,0.42)")
            ctx.fillStyle = g; ctx.fillRect(0, 0, w, h)
            ctx.strokeStyle = "rgba(255,255,255,0.18)"; ctx.lineWidth = 1
            for (var x = -80; x < w + 80; x += 54) { ctx.beginPath(); ctx.moveTo(x + Math.sin(t)*12, 0); ctx.lineTo(x - 90, h); ctx.stroke() }
            for (var y = 18; y < h; y += 44) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y + Math.sin(t + y)*8); ctx.stroke() }
            var cx = w * 0.52, cy = h * 0.48
            for (var r = 28; r < Math.max(w,h); r += 42) { ctx.strokeStyle = "rgba(255,255,255," + (0.22 - r/900) + ")"; ctx.beginPath(); ctx.arc(cx, cy, r + Math.sin(t*2 + r)*3, 0, Math.PI*2); ctx.stroke() }
            var blobs = [[0.33,0.45,55,"rgba(34,197,94,0.62)"],[0.55,0.36,42,"rgba(250,204,21,0.58)"],[0.66,0.58,66,"rgba(59,130,246,0.58)"],[0.44,0.63,32,"rgba(239,68,68,0.55)"]]
            for (var i=0;i<blobs.length;i++){ var b=blobs[i]; ctx.fillStyle=b[3]; ctx.beginPath(); ctx.ellipse(w*b[0]+Math.sin(t+i)*18,h*b[1]+Math.cos(t*0.9+i)*12,b[2],b[2]*0.55,Math.sin(t+i),0,Math.PI*2); ctx.fill() }
            ctx.strokeStyle = "rgba(255,255,255,0.9)"; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(cx-10,cy); ctx.lineTo(cx+10,cy); ctx.moveTo(cx,cy-10); ctx.lineTo(cx,cy+10); ctx.stroke()
        }
    }

    component MapCanvas: Canvas {
        opacity: 0.98
        onPaint: {
            var ctx = getContext("2d"), w = width, h = height, t = root.sceneTime
            ctx.clearRect(0, 0, w, h)
            var g = ctx.createLinearGradient(0, 0, w, h)
            g.addColorStop(0, "rgba(56,189,248,0.35)"); g.addColorStop(0.55, "rgba(30,64,175,0.34)"); g.addColorStop(1, "rgba(2,6,23,0.55)")
            ctx.fillStyle = g; ctx.fillRect(0,0,w,h)
            ctx.fillStyle = "rgba(34,197,94,0.28)"; ctx.beginPath(); ctx.ellipse(w*0.28,h*0.45,w*0.25,h*0.33,0.22,0,Math.PI*2); ctx.fill()
            ctx.beginPath(); ctx.ellipse(w*0.72,h*0.48,w*0.22,h*0.30,-0.22,0,Math.PI*2); ctx.fill()
            ctx.strokeStyle = "rgba(255,255,255,0.22)"; ctx.lineWidth = 1
            for (var i=0;i<8;i++){ var yy=(i+1)*h/9; ctx.beginPath(); ctx.moveTo(0,yy+Math.sin(t+i)*4); ctx.lineTo(w,yy+Math.cos(t+i)*4); ctx.stroke() }
            for (var j=0;j<11;j++){ var xx=(j+1)*w/12; ctx.beginPath(); ctx.moveTo(xx+Math.sin(t+j)*4,0); ctx.lineTo(xx+Math.cos(t+j)*4,h); ctx.stroke() }
            ctx.fillStyle = "rgba(255,255,255,0.20)"
            for (var c=0;c<10;c++){ ctx.beginPath(); ctx.ellipse((c*113+t*12)%(w+140)-70, (c*47)%h, 65, 20, Math.sin(c), 0, Math.PI*2); ctx.fill() }
        }
    }


    component MiniSkyCanvas: Canvas {
        onPaint: {
            var ctx=getContext("2d"), w=width, h=height, t=root.sceneTime
            ctx.clearRect(0,0,w,h)
            var g=ctx.createLinearGradient(0,0,w,h); g.addColorStop(0, root.isNight ? "#0f172a" : "#38bdf8"); g.addColorStop(1, root.isNight ? "#312e81" : "#fde68a"); ctx.fillStyle=g; ctx.fillRect(0,0,w,h)
            ctx.fillStyle=root.isNight ? "rgba(255,255,255,0.95)" : "rgba(255,240,160,0.95)"; ctx.beginPath(); ctx.arc(w*0.78,h*0.28,26+Math.sin(t)*2,0,Math.PI*2); ctx.fill()
            ctx.fillStyle="rgba(255,255,255,0.48)"; for(var i=0;i<5;i++){ ctx.beginPath(); ctx.ellipse((i*110+t*18)%(w+120)-60,h*(0.25+0.11*(i%3)),70,22,0,0,Math.PI*2); ctx.fill() }
            if(root.rainy||root.stormy){ ctx.strokeStyle="rgba(220,245,255,0.75)"; ctx.lineWidth=2; for(var r=0;r<36;r++){ var x=(r*31+t*260)%w; var y=(r*53+t*390)%h; ctx.beginPath(); ctx.moveTo(x,y); ctx.lineTo(x-10,y+28); ctx.stroke() }}
            if(root.snowy){ ctx.fillStyle="rgba(255,255,255,0.9)"; for(var s=0;s<40;s++){ ctx.beginPath(); ctx.arc((s*37+t*24)%w,(s*29+t*42)%h,2+(s%3),0,Math.PI*2); ctx.fill() }}
            ctx.fillStyle="rgba(255,255,255,0.16)"; ctx.fillRect(0,h-28,w,28)
        }
        Timer { interval: 33; running: true; repeat: true; onTriggered: parent.requestPaint() }
    }

    component LightningCanvas: Canvas {
        onPaint: {
            var ctx=getContext("2d"), w=width, h=height, t=root.sceneTime
            ctx.clearRect(0,0,w,h)
            var g=ctx.createRadialGradient(w*0.5,h*0.1,10,w*0.5,h*0.5,Math.max(w,h)); g.addColorStop(0,"rgba(147,197,253,0.32)"); g.addColorStop(1,"rgba(2,6,23,0.78)"); ctx.fillStyle=g; ctx.fillRect(0,0,w,h)
            ctx.strokeStyle="rgba(255,255,255,0.12)"; for(var y=20;y<h;y+=34){ ctx.beginPath(); ctx.moveTo(0,y+Math.sin(t+y)*5); ctx.lineTo(w,y+Math.cos(t+y)*5); ctx.stroke() }
            var flash = root.stormy ? (0.25 + Math.max(0, Math.sin(t*7.5))*0.75) : (0.08 + Math.max(0, Math.sin(t*2.4))*0.25)
            ctx.strokeStyle="rgba(255,255,255,"+flash+")"; ctx.lineWidth=4
            for(var b=0;b<3;b++){ var x=w*(0.25+b*0.22)+Math.sin(t+b)*30; var y0=25; ctx.beginPath(); ctx.moveTo(x,y0); for(var k=0;k<7;k++){ x += (k%2?1:-1)*(18+8*b); y0 += 28; ctx.lineTo(x,y0) } ctx.stroke() }
            ctx.fillStyle="rgba(96,165,250,0.20)"; ctx.beginPath(); ctx.ellipse(w*0.5,h*0.72,w*0.42,h*0.18,0,0,Math.PI*2); ctx.fill()
        }
        Timer { interval: 33; running: true; repeat: true; onTriggered: parent.requestPaint() }
    }

}
