#!/usr/bin/env bash
set -u

LOG="/tmp/dynamicweather-update.log"
exec > >(tee "$LOG") 2>&1

echo "DynamicWeather updater started"
echo "ZIP: ${1:-missing}"
echo "APP_ROOT: ${2:-missing}"
echo "EXE_PATH: ${3:-missing}"
echo "PID: ${4:-missing}"

ZIP="${1:-}"
APP_ROOT="${2:-/opt/DynamicWeather}"
EXE_PATH="${3:-/usr/local/bin/dynamicweather}"
PID="${4:-}"

if [ -z "$ZIP" ] || [ ! -f "$ZIP" ]; then
  echo "ERROR: update ZIP not found: $ZIP"
  read -p "Press Enter to close..."
  exit 1
fi

echo "Checking ZIP archive..."
if ! file "$ZIP" | grep -qi "zip"; then
  echo "ERROR: downloaded file is not a ZIP archive."
  file "$ZIP"
  echo "The download_url must be a raw/direct ZIP link, not a GitHub blob page."
  read -p "Press Enter to close..."
  exit 1
fi

TMP="/tmp/dynamicweather-extract"
BACKUP="/opt/DynamicWeather_backup_$(date +%Y%m%d-%H%M%S)"

echo "Stopping app..."
if [ -n "$PID" ]; then
  kill "$PID" 2>/dev/null || true
  sleep 1
fi

echo "Extracting update..."
rm -rf "$TMP"
mkdir -p "$TMP"
unzip -o "$ZIP" -d "$TMP"

echo "Finding extracted app folder..."
if [ -d "$TMP/ModernWeatherApp" ]; then
  NEWROOT="$TMP/ModernWeatherApp"
else
  NEWROOT="$(find "$TMP" -maxdepth 3 -name CMakeLists.txt -printf '%h\n' | head -1)"
fi

if [ -z "${NEWROOT:-}" ] || [ ! -d "$NEWROOT" ]; then
  echo "ERROR: Could not find extracted app folder with CMakeLists.txt"
  find "$TMP" -maxdepth 3 -type f | head -80
  read -p "Press Enter to close..."
  exit 1
fi

echo "New app root: $NEWROOT"

echo "Backing up current app..."
sudo cp -a "$APP_ROOT" "$BACKUP"

echo "Replacing app..."
sudo rm -rf "$APP_ROOT"
sudo mkdir -p "$APP_ROOT"
sudo cp -a "$NEWROOT"/. "$APP_ROOT"/
sudo chmod +x "$APP_ROOT/tools/update_dynamicweather.sh" 2>/dev/null || true

echo "Building app..."
cd "$APP_ROOT"
sudo rm -rf build
sudo cmake -S . -B build -G Ninja
sudo cmake --build build

echo "Installing launcher binary..."
sudo install -Dm755 "$APP_ROOT/build/modernweather" /usr/local/bin/dynamicweather

echo "Update complete. Relaunching DynamicWeather..."
nohup /usr/local/bin/dynamicweather >/tmp/dynamicweather-run.log 2>&1 &

echo "Done."
sleep 3
