#include "updatemanager.h"

#include <QCoreApplication>
#include <QDesktopServices>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QJsonArray>
#include <QJsonDocument>
#include <QProcess>
#include <QRegularExpression>
#include <QStandardPaths>
#include <QTemporaryDir>
#include <QTextDocumentFragment>
#include <QTimer>

UpdateManager::UpdateManager(QObject *parent) : QObject(parent)
{
    setUpdateUrl(QStringLiteral("https://raw.githubusercontent.com/rickymcelroy0/-Home-Financial/main/version.json"));
    setStatus(QStringLiteral("Ready to check for DynamicWeather updates."));
}

void UpdateManager::setUpdateUrl(const QString &url)
{
    QUrl next(url.trimmed());
    if (next == m_updateUrl)
        return;
    m_updateUrl = next;
    emit updateUrlChanged();
}

void UpdateManager::setStatus(const QString &status)
{
    if (m_status == status)
        return;
    m_status = status;
    emit statusChanged();
}

void UpdateManager::setBusy(bool busy)
{
    if (m_busy == busy)
        return;
    m_busy = busy;
    emit busyChanged();
}

QJsonObject UpdateManager::parseJsonFromReply(const QByteArray &data) const
{
    QJsonParseError error;
    QJsonDocument doc = QJsonDocument::fromJson(data, &error);
    if (error.error == QJsonParseError::NoError && doc.isObject())
        return doc.object();

    QString raw = QString::fromUtf8(data);
    QString text = QTextDocumentFragment::fromHtml(raw).toPlainText();
    text.replace(QChar(0x00a0), QLatin1Char(' '));

    auto tryCandidate = [&](QString candidate) -> QJsonObject {
        candidate.replace(QRegularExpression(QStringLiteral("^\\s*\\d+\\s+"), QRegularExpression::MultilineOption), QString());
        candidate = candidate.trimmed();
        QJsonParseError e;
        QJsonDocument d = QJsonDocument::fromJson(candidate.toUtf8(), &e);
        if (e.error == QJsonParseError::NoError && d.isObject())
            return d.object();
        return {};
    };

    // KDrive's code preview often includes line numbers and HTML markup. First try a balanced JSON object from the decoded text.
    for (const QString &source : {text, raw}) {
        int start = source.indexOf('{');
        while (start >= 0) {
            int depth = 0;
            bool inString = false;
            bool escape = false;
            for (int i = start; i < source.size(); ++i) {
                const QChar ch = source.at(i);
                if (inString) {
                    if (escape) escape = false;
                    else if (ch == QLatin1Char('\\')) escape = true;
                    else if (ch == QLatin1Char('"')) inString = false;
                } else {
                    if (ch == QLatin1Char('"')) inString = true;
                    else if (ch == QLatin1Char('{')) ++depth;
                    else if (ch == QLatin1Char('}')) {
                        --depth;
                        if (depth == 0) {
                            QJsonObject obj = tryCandidate(source.mid(start, i - start + 1));
                            if (!obj.isEmpty())
                                return obj;
                            break;
                        }
                    }
                }
            }
            start = source.indexOf('{', start + 1);
        }
    }

    // Final fallback: build a JSON object from visible key/value pairs in KDrive preview text.
    QJsonObject obj;
    auto stringValue = [&](const QString &key) -> QString {
        QRegularExpression re(QStringLiteral("\\\"") + key + QStringLiteral("\\\"\\s*:\\s*\\\"([^\\\"]*)\\\""));
        auto m = re.match(text);
        if (!m.hasMatch()) m = re.match(raw);
        return m.hasMatch() ? m.captured(1) : QString();
    };
    auto intValue = [&](const QString &key) -> int {
        QRegularExpression re(QStringLiteral("\\\"") + key + QStringLiteral("\\\"\\s*:\\s*(\\d+)"));
        auto m = re.match(text);
        if (!m.hasMatch()) m = re.match(raw);
        return m.hasMatch() ? m.captured(1).toInt() : 0;
    };

    obj.insert(QStringLiteral("app"), stringValue(QStringLiteral("app")));
    obj.insert(QStringLiteral("latest_version"), stringValue(QStringLiteral("latest_version")));
    obj.insert(QStringLiteral("latest_build"), intValue(QStringLiteral("latest_build")));
    obj.insert(QStringLiteral("release_date"), stringValue(QStringLiteral("release_date")));
    obj.insert(QStringLiteral("channel"), stringValue(QStringLiteral("channel")));
    obj.insert(QStringLiteral("message"), stringValue(QStringLiteral("message")));
    obj.insert(QStringLiteral("download_url"), stringValue(QStringLiteral("download_url")));
    if (obj.value(QStringLiteral("latest_build")).toInt() > 0 || !obj.value(QStringLiteral("latest_version")).toString().isEmpty())
        return obj;

    return {};
}

void UpdateManager::applyUpdateInfo(const QJsonObject &obj)
{
    m_latestVersion = obj.value(QStringLiteral("latest_version")).toString(obj.value(QStringLiteral("version")).toString());
    m_latestBuild = obj.value(QStringLiteral("latest_build")).toInt(obj.value(QStringLiteral("build")).toInt());
    m_releaseDate = obj.value(QStringLiteral("release_date")).toString();
    m_channel = obj.value(QStringLiteral("channel")).toString(QStringLiteral("beta"));
    m_message = obj.value(QStringLiteral("message")).toString();
    m_downloadUrl = obj.value(QStringLiteral("download_url")).toString();

    QStringList notes;
    QJsonArray array = obj.value(QStringLiteral("release_notes")).toArray();
    for (const QJsonValue &note : array)
        notes << QStringLiteral("• ") + note.toString();
    m_releaseNotes = notes.join(QStringLiteral("\n"));

    if (m_latestBuild <= 0)
        setStatus(QStringLiteral("Update file was found, but it does not contain a valid build number."));
    else if (updateAvailable())
        setStatus(QStringLiteral("Update available: DynamicWeather %1.").arg(m_latestVersion));
    else
        setStatus(QStringLiteral("DynamicWeather is up to date."));

    emit updateInfoChanged();
}

void UpdateManager::checkForUpdates()
{
    if (!m_updateUrl.isValid()) {
        setStatus(QStringLiteral("Update source is not a valid URL."));
        return;
    }

    setBusy(true);
    setStatus(QStringLiteral("Checking GitHub update feed..."));

    QNetworkRequest request(m_updateUrl);
    request.setRawHeader("User-Agent", "DynamicWeather-Updater/2.5");
    QNetworkReply *reply = m_network.get(request);

    connect(reply, &QNetworkReply::finished, this, [this, reply]() {
        reply->deleteLater();
        setBusy(false);

        if (reply->error() != QNetworkReply::NoError) {
            setStatus(QStringLiteral("Could not check updates: %1").arg(reply->errorString()));
            return;
        }

        QJsonObject obj = parseJsonFromReply(reply->readAll());
        if (obj.isEmpty()) {
            setStatus(QStringLiteral("GitHub responded, but no readable version.json was found."));
            return;
        }
        applyUpdateInfo(obj);
    });
}

void UpdateManager::installUpdate()
{
    if (!canInstall()) {
        setStatus(QStringLiteral("No installable update is available yet. Add download_url to version.json."));
        return;
    }

    setBusy(true);
    setStatus(QStringLiteral("Downloading DynamicWeather %1...").arg(m_latestVersion));

    QUrl url(m_downloadUrl);
    QNetworkRequest request(url);
    request.setRawHeader("User-Agent", "DynamicWeather-Updater/2.5");
    QNetworkReply *reply = m_network.get(request);

    connect(reply, &QNetworkReply::finished, this, [this, reply]() {
        reply->deleteLater();
        setBusy(false);

        if (reply->error() != QNetworkReply::NoError) {
            setStatus(QStringLiteral("Download failed: %1").arg(reply->errorString()));
            return;
        }

        QString tempPath = QStandardPaths::writableLocation(QStandardPaths::TempLocation) + QStringLiteral("/DynamicWeather-update.zip");
        QFile file(tempPath);
        if (!file.open(QIODevice::WriteOnly)) {
            setStatus(QStringLiteral("Could not save downloaded update ZIP."));
            return;
        }
        file.write(reply->readAll());
        file.close();

        QString appRoot = QStringLiteral("/opt/DynamicWeather");
        QString script = QStringLiteral("/opt/DynamicWeather/tools/update_dynamicweather.sh");

        if (!QFileInfo::exists(script)) {
            setStatus(QStringLiteral("Updater helper script was not found at /opt/DynamicWeather/tools/update_dynamicweather.sh."));
            return;
        }
        QString relaunchPath = QFileInfo::exists(QStringLiteral("/usr/local/bin/dynamicweather"))
            ? QStringLiteral("/usr/local/bin/dynamicweather")
            : QCoreApplication::applicationFilePath();

        QString program;
        QStringList finalArgs;
        if (QFileInfo::exists(QStringLiteral("/usr/bin/xterm"))) {
            program = QStringLiteral("/usr/bin/xterm");
            finalArgs << QStringLiteral("-T") << QStringLiteral("DynamicWeather Updater")
                      << QStringLiteral("-e") << QStringLiteral("bash")
                      << script << tempPath << appRoot << relaunchPath << QString::number(QCoreApplication::applicationPid());
            setStatus(QStringLiteral("Opening updater terminal for administrator password."));
        } else {
            program = QStringLiteral("/bin/bash");
            finalArgs << script << tempPath << appRoot << relaunchPath << QString::number(QCoreApplication::applicationPid());
            setStatus(QStringLiteral("Running updater helper."));
        }

        bool started = QProcess::startDetached(program, finalArgs);
        if (!started) {
            setStatus(QStringLiteral("Could not start updater helper."));
            return;
        }

        QTimer::singleShot(250, qApp, &QCoreApplication::quit);
    });
}

void UpdateManager::openUpdatePage()
{
    if (m_updateUrl.isValid())
        QDesktopServices::openUrl(m_updateUrl);
}

void UpdateManager::openDownloadPage()
{
    if (!m_downloadUrl.isEmpty())
        QDesktopServices::openUrl(QUrl(m_downloadUrl));
    else
        openUpdatePage();
}
