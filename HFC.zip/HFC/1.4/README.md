# Home Financial Center

This version keeps the filenames exactly as:

- `index.html`
- `script.js`
- `account.html`
- `account.js`

## What was changed

- admin is now the master account
- admin can create users
- the system generates account numbers automatically using `settings/nextAccountNumber`
- admin can open and close users
- admin can delete users
- admin can adjust any user's checking or staging balance
- admin can manage bills and view the full institution ledger
- integration settings are stored under `settings/integration`
- every dashboard tile still opens its own dedicated account window
- balances are stored under `balances/`

## Expected Firebase paths

- `users/`
- `balances/`
- `bills/`
- `ledger/`
- `settings/integration`
- `settings/nextAccountNumber`

## Important note

This is still a client-side Firebase app. It is appropriate for prototyping and internal use, but real financial production use needs Firebase Authentication, database security rules, and server-side enforcement.
