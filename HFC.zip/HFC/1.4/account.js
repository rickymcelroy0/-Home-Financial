const firebaseConfig = {
  databaseURL: 'https://homefund-3b81a-default-rtdb.firebaseio.com/',
  projectId: 'homefund-3b81a',
  authDomain: 'homefund-3b81a.firebaseapp.com',
  storageBucket: 'homefund-3b81a.appspot.com'
};
if (!firebase.apps.length) firebase.initializeApp(firebaseConfig);
const db = firebase.database();

const params = new URLSearchParams(window.location.search);
const kind = params.get('kind') || 'checking';
const userId = params.get('user') || 'admin';

let users = {}, balances = {}, bills = {}, ledger = {}, settings = {};

function money(n){ return new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(Number(n || 0)); }
function bal(uid){ return balances[uid] || { personal:0, staging:0 }; }
function openBillsForUser(uid){ return Object.values(bills).filter(b => b.userId === uid && b.status === 'open'); }
function paidBillsForUser(uid){ return Object.values(bills).filter(b => b.userId === uid && b.status === 'paid'); }
function ledgerItemsForUser(uid){ return Object.values(ledger).filter(x => x.userId === uid).sort((a,b)=>new Date(b.createdAt||0)-new Date(a.createdAt||0)); }
function systemLedger(){ return Object.values(ledger).sort((a,b)=>new Date(b.createdAt||0)-new Date(a.createdAt||0)); }
function card(label, value){ return `<div class="col-md-4"><div class="card-lite"><div class="kicker">${label}</div><h3 class="mt-2 mb-0">${value}</h3></div></div>`; }
function renderSummary(cards){ document.getElementById('summary-row').innerHTML = cards.join(''); }
function renderLedger(items){
  const pane = document.getElementById('ledger-pane');
  if (!items.length) return pane.innerHTML = '<div class="soft">No activity yet.</div>';
  pane.innerHTML = items.slice(0, 20).map(item => `<div class="list-row"><div class="d-flex justify-content-between gap-3"><div><div class="fw-semibold">${item.title || 'Activity'}</div><div class="soft small">${item.description || ''}</div><div class="soft small">${item.actor ? `Actor: ${item.actor}` : ''}</div></div><div class="text-end"><div class="fw-semibold">${item.amount != null ? money(item.amount) : ''}</div><div class="soft small">${new Date(item.createdAt || Date.now()).toLocaleString()}</div></div></div></div>`).join('');
}
function table(headers, rows){ return `<div class="table-responsive"><table class="table align-middle mb-0"><thead><tr>${headers.map(h => `<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.length ? rows.join('') : `<tr><td colspan="${headers.length}" class="soft">No records.</td></tr>`}</tbody></table></div>`; }

function render(){
  const user = users[userId] || { name:userId, role:'unknown', status:'unknown' };
  const userBal = bal(userId);
  const detail = document.getElementById('detail-pane');
  const openTotal = openBillsForUser(userId).reduce((sum,b)=>sum + Number(b.amount || 0), 0);
  const integration = settings.integration || { systemName:'Home Financial Center', routingPrefix:'HFC' };

  if (kind === 'checking') {
    document.getElementById('window-title').textContent = `${user.name} · Checking`;
    document.getElementById('window-subtitle').textContent = `Account ${user.accountNumber || 'pending'} · available checking funds`;
    renderSummary([
      card('Checking Balance', money(userBal.personal)),
      card('Open Bills', money(openTotal)),
      card('Account Number', user.accountNumber || 'Pending')
    ]);
    detail.innerHTML = table(['Type','Description','Amount','When'], ledgerItemsForUser(userId).filter(x => ['client_created','transfer','admin_adjustment','bill_paid','bill_created'].includes(x.type)).map(item => `<tr><td>${item.title || item.type}</td><td>${item.description || ''}</td><td>${item.amount != null ? money(item.amount) : ''}</td><td>${new Date(item.createdAt || Date.now()).toLocaleString()}</td></tr>`));
    renderLedger(ledgerItemsForUser(userId));
    return;
  }

  if (kind === 'staging') {
    document.getElementById('window-title').textContent = `${user.name} · Bill Staging`;
    document.getElementById('window-subtitle').textContent = 'Reserved funds used to cover recorded bills';
    renderSummary([
      card('Staging Balance', money(userBal.staging)),
      card('Open Bill Count', String(openBillsForUser(userId).length)),
      card('Coverage Delta', money(userBal.staging - openTotal))
    ]);
    detail.innerHTML = table(['Bill','Due','Amount','Status'], openBillsForUser(userId).map(b => `<tr><td>${b.name}</td><td>${b.dueDate || '—'}</td><td>${money(b.amount)}</td><td>${b.status}</td></tr>`));
    renderLedger(ledgerItemsForUser(userId).filter(x => ['transfer','bill_paid','bill_created','admin_adjustment'].includes(x.type)));
    return;
  }

  if (kind === 'bills') {
    document.getElementById('window-title').textContent = `${user.name} · Bills`;
    document.getElementById('window-subtitle').textContent = 'Open and paid bill detail';
    renderSummary([
      card('Open Bills', String(openBillsForUser(userId).length)),
      card('Paid Bills', String(paidBillsForUser(userId).length)),
      card('Open Bill Total', money(openTotal))
    ]);
    const rows = [...openBillsForUser(userId), ...paidBillsForUser(userId)].sort((a,b)=>new Date(b.createdAt||0)-new Date(a.createdAt||0)).map(b => `<tr><td>${b.name}</td><td>${b.dueDate || '—'}</td><td>${money(b.amount)}</td><td>${b.status}</td></tr>`);
    detail.innerHTML = table(['Bill','Due','Amount','Status'], rows);
    renderLedger(ledgerItemsForUser(userId).filter(x => ['bill_created','bill_paid'].includes(x.type)));
    return;
  }

  if (kind === 'client_overview') {
    document.getElementById('window-title').textContent = `${user.name} · Client Overview`;
    document.getElementById('window-subtitle').textContent = `User ${userId} · ${user.accountNumber || 'No account #'} · ${user.status || 'active'}`;
    renderSummary([
      card('Checking', money(userBal.personal)),
      card('Staging', money(userBal.staging)),
      card('Open Bills', money(openTotal))
    ]);
    detail.innerHTML = `<div class="row g-3"><div class="col-md-6"><div class="card-lite"><div class="kicker">Profile</div><div class="mt-2"><strong>${user.name}</strong><div class="soft">Username: ${userId}</div><div class="soft">Role: ${user.role}</div><div class="soft">Status: ${user.status || 'active'}</div><div class="soft">Account #: ${user.accountNumber || 'Pending'}</div></div></div></div><div class="col-md-6"><div class="card-lite"><div class="kicker">Integration</div><div class="mt-2 soft">Institution: ${integration.systemName || 'Home Financial Center'}</div><div class="soft">Routing Prefix: ${integration.routingPrefix || 'HFC'}</div><div class="soft">Generated account numbers follow this routing prefix.</div></div></div></div>`;
    renderLedger(ledgerItemsForUser(userId));
    return;
  }

  if (kind === 'admin_master_account') {
    const adminBal = bal('admin');
    document.getElementById('window-title').textContent = 'Admin · Master Account';
    document.getElementById('window-subtitle').textContent = 'Primary institution control account';
    renderSummary([
      card('Admin Checking', money(adminBal.personal)),
      card('Admin Staging', money(adminBal.staging)),
      card('Institution', integration.systemName || 'Home Financial Center')
    ]);
    detail.innerHTML = `<div class="card-lite"><div class="kicker">Control Scope</div><div class="mt-2 soft">The admin account is the master account for balances, transactions, user status, user deletion, bill control, and system integration settings.</div></div>`;
    renderLedger(ledgerItemsForUser('admin'));
    return;
  }

  if (kind === 'admin_global_cash') {
    const totalChecking = Object.values(balances).reduce((sum,b)=>sum + Number(b.personal || 0), 0);
    document.getElementById('window-title').textContent = 'Admin · Total Checking';
    document.getElementById('window-subtitle').textContent = 'System-wide checking funds by account';
    renderSummary([
      card('Total Checking', money(totalChecking)),
      card('Accounts', String(Object.keys(users).length)),
      card('Clients', String(Object.values(users).filter(u => u.role === 'client').length))
    ]);
    detail.innerHTML = table(['User','Account #','Role','Checking'], Object.entries(users).map(([uid,u]) => `<tr><td>${u.name || uid}</td><td>${u.accountNumber || '—'}</td><td>${u.role}</td><td>${money(bal(uid).personal)}</td></tr>`));
    renderLedger(systemLedger());
    return;
  }

  if (kind === 'admin_global_staging') {
    const totalStaging = Object.values(balances).reduce((sum,b)=>sum + Number(b.staging || 0), 0);
    document.getElementById('window-title').textContent = 'Admin · Total Staging';
    document.getElementById('window-subtitle').textContent = 'System-wide reserved funds for bills';
    renderSummary([
      card('Total Staging', money(totalStaging)),
      card('Open Bills', String(Object.values(bills).filter(b => b.status === 'open').length)),
      card('Open Bill Total', money(Object.values(bills).filter(b => b.status === 'open').reduce((sum,b)=>sum + Number(b.amount || 0), 0)))
    ]);
    detail.innerHTML = table(['User','Account #','Staging','Open Bill Total'], Object.entries(users).filter(([_,u]) => u.role === 'client').map(([uid,u]) => `<tr><td>${u.name || uid}</td><td>${u.accountNumber || '—'}</td><td>${money(bal(uid).staging)}</td><td>${money(openBillsForUser(uid).reduce((sum,b)=>sum + Number(b.amount || 0), 0))}</td></tr>`));
    renderLedger(systemLedger().filter(x => ['transfer','bill_paid','bill_created','admin_adjustment'].includes(x.type)));
    return;
  }

  if (kind === 'admin_open_bills') {
    document.getElementById('window-title').textContent = 'Admin · Open Bills';
    document.getElementById('window-subtitle').textContent = 'All institution bills across users';
    renderSummary([
      card('Open Bill Total', money(Object.values(bills).filter(b => b.status === 'open').reduce((sum,b)=>sum + Number(b.amount || 0), 0))),
      card('Open Bills', String(Object.values(bills).filter(b => b.status === 'open').length)),
      card('Paid Bills', String(Object.values(bills).filter(b => b.status === 'paid').length))
    ]);
    detail.innerHTML = table(['User','Bill','Due','Amount','Status'], Object.values(bills).sort((a,b)=>new Date(b.createdAt||0)-new Date(a.createdAt||0)).map(b => `<tr><td>${users[b.userId]?.name || b.userId}</td><td>${b.name}</td><td>${b.dueDate || '—'}</td><td>${money(b.amount)}</td><td>${b.status}</td></tr>`));
    renderLedger(systemLedger().filter(x => ['bill_created','bill_paid'].includes(x.type)));
    return;
  }
}

db.ref('users').on('value', snap => { users = snap.val() || {}; render(); });
db.ref('balances').on('value', snap => { balances = snap.val() || {}; render(); });
db.ref('bills').on('value', snap => { bills = snap.val() || {}; render(); });
db.ref('ledger').on('value', snap => { ledger = snap.val() || {}; render(); });
db.ref('settings').on('value', snap => { settings = snap.val() || {}; render(); });
