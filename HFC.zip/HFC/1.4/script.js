const firebaseConfig = {
  databaseURL: 'https://homefund-3b81a-default-rtdb.firebaseio.com/',
  projectId: 'homefund-3b81a',
  authDomain: 'homefund-3b81a.firebaseapp.com',
  storageBucket: 'homefund-3b81a.appspot.com'
};

if (!firebase.apps.length) firebase.initializeApp(firebaseConfig);
const db = firebase.database();

let currentUser = null;
let users = {};
let balances = {};
let bills = {};
let ledger = {};
let settings = {};
let clockHandle = null;

const SESSION_KEY = 'hfc_session_user';

const clientModal = () => new bootstrap.Modal(document.getElementById('clientModal'));
const billModal = () => new bootstrap.Modal(document.getElementById('billModal'));
const transferModal = () => new bootstrap.Modal(document.getElementById('transferModal'));
const adjustBalanceModal = () => new bootstrap.Modal(document.getElementById('adjustBalanceModal'));
const integrationModal = () => new bootstrap.Modal(document.getElementById('integrationModal'));

function money(n){ return new Intl.NumberFormat('en-US',{style:'currency', currency:'USD'}).format(Number(n || 0)); }
function nowIso(){ return new Date().toISOString(); }
function sanitizeUsername(value){ return String(value || '').trim().toLowerCase().replace(/[^a-z0-9._-]/g,''); }
function appSettings(){ return settings.integration || { systemName:'Home Financial Center', routingPrefix:'HFC', webhookUrl:'', mode:'manual', notes:'' }; }
function getBalance(uid){ return balances[uid] || { personal:0, staging:0 }; }
function getUser(uid){ return users[uid] || null; }
function openBillsForUser(uid){ return Object.entries(bills).filter(([_,b]) => b.userId === uid && b.status === 'open'); }
function ledgerItemsForUser(uid){ return Object.values(ledger).filter(x => x.userId === uid).sort((a,b)=>new Date(b.createdAt||0)-new Date(a.createdAt||0)); }
function totalOpenBills(uid){ return openBillsForUser(uid).reduce((sum,[,bill]) => sum + Number(bill.amount || 0), 0); }
function adminTotalChecking(){ return Object.values(balances).reduce((sum,b) => sum + Number(b.personal || 0), 0); }
function adminTotalStaging(){ return Object.values(balances).reduce((sum,b) => sum + Number(b.staging || 0), 0); }
function sortUsers(){ return Object.entries(users).sort((a,b) => String(a[1].name || a[0]).localeCompare(String(b[1].name || b[0]))); }

function showToast(message, type='info'){
  const wrap = document.getElementById('toast-container');
  const el = document.createElement('div');
  el.className = `toast align-items-center text-white border-0 show mb-2 bg-${type === 'danger' ? 'danger' : type === 'warning' ? 'warning' : type === 'success' ? 'success' : 'primary'}`;
  el.innerHTML = `<div class="d-flex"><div class="toast-body">${message}</div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div>`;
  wrap.appendChild(el);
  setTimeout(() => el.remove(), 3800);
}

function setLoginError(message){
  const el = document.getElementById('login-err');
  el.textContent = message;
  el.classList.remove('d-none');
}
function clearLoginError(){ document.getElementById('login-err').classList.add('d-none'); }

function switchView(view){
  document.querySelectorAll('.view').forEach(el => el.classList.remove('active'));
  document.getElementById(`view-${view}`)?.classList.add('active');
}

// FIXED: Now properly removes 'd-flex' and adds 'd-none' to completely hide login
function setSession(uid){
  currentUser = uid;
  localStorage.setItem(SESSION_KEY, uid);

  const loginWrapper = document.getElementById('login-wrapper');
  loginWrapper.classList.remove('d-flex');
  loginWrapper.classList.add('d-none');

  document.getElementById('app-wrapper').style.display = 'block';

  const user = getUser(uid) || { role:'client', name:uid };
  document.getElementById('session-user-label').textContent = `${user.name || uid} · ${user.role || 'user'}`;
  if (user.role === 'admin') switchView('admin'); else switchView('client');
  render();
  startClock();
}

// FIXED: Restores 'd-flex' properly on logout
function logoutUser(){
  currentUser = null;
  localStorage.removeItem(SESSION_KEY);

  document.getElementById('app-wrapper').style.display = 'none';

  const loginWrapper = document.getElementById('login-wrapper');
  loginWrapper.classList.remove('d-none');
  loginWrapper.classList.add('d-flex');

  document.getElementById('login-pin').value = '';
  showToast('Session terminated', 'warning');
}

function startClock(){
  if (clockHandle) clearInterval(clockHandle);
  const tick = () => document.getElementById('clockTime').textContent = new Date().toLocaleTimeString([], { hour12:false });
  tick();
  clockHandle = setInterval(tick, 1000);
}

async function bootstrapAdmin(){
  const updates = {};
  if (!users.admin) {
    updates['users/admin'] = {
      username:'admin',
      name:'System Admin',
      pin:'0000',
      role:'admin',
      status:'active',
      accountNumber:'HFC-00000000',
      createdAt:nowIso()
    };
  }
  if (!balances.admin) updates['balances/admin'] = { personal:0, staging:0 };
  if (!settings.integration) {
    updates['settings/integration'] = {
      systemName:'Home Financial Center',
      routingPrefix:'HFC',
      webhookUrl:'',
      mode:'manual',
      notes:''
    };
  }
  if (settings.nextAccountNumber == null) updates['settings/nextAccountNumber'] = 10000001;
  if (Object.keys(updates).length) await db.ref().update(updates);
}

async function authenticateUser(){
  clearLoginError();
  const username = sanitizeUsername(document.getElementById('login-user').value);
  const pin = document.getElementById('login-pin').value.trim();
  if (!username || !pin) return setLoginError('Enter both username and PIN.');
  const user = getUser(username);
  if (!user || user.pin !== pin || user.status !== 'active') return setLoginError('Authentication failed.');
  setSession(username);
}

async function generateAccountNumber(){
  const result = await db.ref('settings/nextAccountNumber').transaction(current => (current == null ? 10000002 : current + 1));
  const next = Number(result.snapshot.val() || 10000002) - 1;
  const prefix = (appSettings().routingPrefix || 'HFC').toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,6) || 'HFC';
  return `${prefix}-${String(next).padStart(8,'0')}`;
}

async function addLedger(entry){
  const ref = db.ref('ledger').push();
  await ref.set({ ...entry, createdAt: entry.createdAt || nowIso() });
}

async function createUser(){
  const username = sanitizeUsername(document.getElementById('new-client-username').value);
  const name = document.getElementById('new-client-name').value.trim();
  const pin = document.getElementById('new-client-pin').value.trim();
  const opening = Number(document.getElementById('new-client-opening').value || 0);
  if (!username || !name || !pin) return showToast('Fill out all user fields.', 'warning');
  if (users[username]) return showToast('That username already exists.', 'danger');
  const accountNumber = await generateAccountNumber();
  await db.ref(`users/${username}`).set({
    username, name, pin,
    role:'client', status:'active',
    accountNumber,
    createdAt: nowIso(),
                                        createdBy: currentUser
  });
  await db.ref(`balances/${username}`).set({ personal: opening, staging:0 });
  await addLedger({ userId:username, type:'client_created', title:'User created', description:`${name} opened with account ${accountNumber}`, amount:opening, actor:currentUser });
  clientModal().hide();
  document.getElementById('new-client-username').value = '';
  document.getElementById('new-client-name').value = '';
  document.getElementById('new-client-pin').value = '';
  document.getElementById('new-client-opening').value = '0';
  showToast(`Created ${name} · ${accountNumber}`, 'success');
}

async function recordBill(){
  const userId = document.getElementById('bill-user').value;
  const name = document.getElementById('bill-name').value.trim();
  const amount = Number(document.getElementById('bill-amount').value || 0);
  const dueDate = document.getElementById('bill-due-date').value;
  if (!userId || !name || amount <= 0) return showToast('Enter a user, bill name, and amount.', 'warning');
  const ref = db.ref('bills').push();
  await ref.set({ userId, name, amount, dueDate: dueDate || '', status:'open', createdAt: nowIso(), createdBy: currentUser });
  await addLedger({ userId, type:'bill_created', title:'Bill recorded', description:name, amount, actor:currentUser });
  billModal().hide();
  document.getElementById('bill-name').value = '';
  document.getElementById('bill-amount').value = '';
  document.getElementById('bill-due-date').value = '';
  showToast('Bill recorded.', 'success');
}

async function saveTransfer(){
  const direction = document.getElementById('transfer-direction').value;
  const amount = Number(document.getElementById('transfer-amount').value || 0);
  if (!currentUser || amount <= 0) return showToast('Enter a transfer amount.', 'warning');
  const balRef = db.ref(`balances/${currentUser}`);
  const tx = await balRef.transaction(current => {
    const base = current || { personal:0, staging:0 };
    let personal = Number(base.personal || 0);
    let staging = Number(base.staging || 0);
    if (direction === 'personal_to_staging') {
      if (personal < amount) return;
      personal -= amount; staging += amount;
    } else {
      if (staging < amount) return;
      staging -= amount; personal += amount;
    }
    return { personal:Number(personal.toFixed(2)), staging:Number(staging.toFixed(2)) };
  });
  if (!tx.committed) return showToast('Insufficient funds for transfer.', 'danger');
  await addLedger({ userId:currentUser, type:'transfer', title:'Transfer posted', description:direction === 'personal_to_staging' ? 'Checking to staging' : 'Staging to checking', amount, actor:currentUser });
  transferModal().hide();
  document.getElementById('transfer-amount').value = '';
  showToast('Transfer completed.', 'success');
}

async function adjustBalance(){
  const userId = document.getElementById('adjust-user-id').value;
  const bucket = document.getElementById('adjust-balance-type').value;
  const operation = document.getElementById('adjust-operation').value;
  const amount = Number(document.getElementById('adjust-amount').value || 0);
  if (!userId || amount < 0) return showToast('Enter a valid amount.', 'warning');
  const tx = await db.ref(`balances/${userId}`).transaction(current => {
    const base = current || { personal:0, staging:0 };
    let val = Number(base[bucket] || 0);
    if (operation === 'credit') val += amount;
    if (operation === 'debit') {
      if (val < amount) return;
      val -= amount;
    }
    if (operation === 'set') val = amount;
    base[bucket] = Number(val.toFixed(2));
    return base;
  });
  if (!tx.committed) return showToast('Adjustment could not be applied.', 'danger');
  await addLedger({ userId, type:'admin_adjustment', title:'Admin balance adjustment', description:`${operation} ${bucket}`, amount, actor:currentUser });
  adjustBalanceModal().hide();
  document.getElementById('adjust-amount').value = '';
  showToast('Balance updated.', 'success');
}

async function toggleUserStatus(userId){
  const user = getUser(userId);
  if (!user || user.role === 'admin') return;
  const nextStatus = user.status === 'active' ? 'closed' : 'active';
  await db.ref(`users/${userId}/status`).set(nextStatus);
  await addLedger({ userId, type:'status_change', title:'User status changed', description:`Account ${nextStatus}`, actor:currentUser });
  showToast(`User ${nextStatus}.`, 'success');
}

async function deleteUser(userId){
  const user = getUser(userId);
  if (!user || user.role === 'admin') return;
  const ok = window.confirm(`Delete ${user.name || userId}? This removes balances, bills, and ledger entries for that user.`);
  if (!ok) return;
  const updates = {
    [`users/${userId}`]: null,
    [`balances/${userId}`]: null
  };
  Object.entries(bills).forEach(([billId, bill]) => { if (bill.userId === userId) updates[`bills/${billId}`] = null; });
  Object.entries(ledger).forEach(([entryId, item]) => { if (item.userId === userId) updates[`ledger/${entryId}`] = null; });
  await db.ref().update(updates);
  showToast('User deleted.', 'warning');
}

async function payBill(billId){
  const bill = bills[billId];
  if (!bill || bill.status !== 'open') return;
  const amount = Number(bill.amount || 0);
  const userId = bill.userId;
  const tx = await db.ref(`balances/${userId}`).transaction(current => {
    const base = current || { personal:0, staging:0 };
    const staging = Number(base.staging || 0);
    if (staging < amount) return;
    base.staging = Number((staging - amount).toFixed(2));
    return base;
  });
  if (!tx.committed) return showToast('Not enough staging funds.', 'danger');
  await db.ref(`bills/${billId}/status`).set('paid');
  await db.ref(`bills/${billId}/paidAt`).set(nowIso());
  await addLedger({ userId, type:'bill_paid', title:'Bill paid', description:bill.name, amount, actor:currentUser });
  showToast('Bill paid from staging.', 'success');
}

async function saveIntegration(){
  const payload = {
    systemName: document.getElementById('integration-system-name').value.trim() || 'Home Financial Center',
    routingPrefix: document.getElementById('integration-routing-prefix').value.trim() || 'HFC',
    webhookUrl: document.getElementById('integration-webhook-url').value.trim(),
    mode: document.getElementById('integration-mode').value,
    notes: document.getElementById('integration-notes').value.trim()
  };
  await db.ref('settings/integration').set(payload);
  integrationModal().hide();
  showToast('Integration settings saved.', 'success');
}

function openWindow(kind, userId=currentUser){
  if (!userId) return;
  window.open(`account.html?kind=${encodeURIComponent(kind)}&user=${encodeURIComponent(userId)}`, '_blank', 'width=1160,height=820,resizable=yes,scrollbars=yes');
}

function renderUserOptions(){
  const select = document.getElementById('bill-user');
  const currentValue = select.value;
  const rows = sortUsers().filter(([uid,u]) => u.role === 'client');
  select.innerHTML = rows.map(([uid,u]) => `<option value="${uid}">${u.name || uid} · ${u.accountNumber || 'No account #'}</option>`).join('');
  if (currentUser && getUser(currentUser)?.role === 'client') select.value = currentUser;
  else if (rows.some(([uid]) => uid === currentValue)) select.value = currentValue;
}

function ledgerRow(item){
  return `<div class="list-row">
  <div class="d-flex justify-content-between gap-3 align-items-start">
  <div>
  <div class="fw-semibold">${item.title || 'Activity'}</div>
  <div class="text-soft small">${item.description || ''}</div>
  <div class="text-soft small">${item.actor ? `Actor: ${item.actor}` : ''}</div>
  </div>
  <div class="text-end">
  <div class="fw-semibold">${item.amount != null ? money(item.amount) : ''}</div>
  <div class="text-soft small">${new Date(item.createdAt || Date.now()).toLocaleString()}</div>
  </div>
  </div>
  </div>`;
}

function renderAdminUsers(){
  const tbody = document.getElementById('adminUsersBody');
  const query = document.getElementById('user-search').value.trim().toLowerCase();
  const rows = sortUsers().filter(([uid,u]) => {
    if (u.role === 'admin') return true;
    const text = `${uid} ${u.name || ''} ${u.accountNumber || ''}`.toLowerCase();
    return !query || text.includes(query);
  });
  tbody.innerHTML = rows.map(([uid,u]) => {
    const bal = getBalance(uid);
    const openTotal = totalOpenBills(uid);
    return `<tr>
    <td><strong>${u.name || uid}</strong><div class="text-soft small">${uid}</div></td>
    <td>${u.accountNumber || '—'}</td>
    <td><span class="badge ${u.status === 'active' ? 'bg-success' : 'bg-secondary'}">${u.status || 'active'}</span></td>
    <td>${money(bal.personal)}</td>
    <td>${money(bal.staging)}</td>
    <td>${money(openTotal)}</td>
    <td>
    <div class="dropdown">
    <button class="btn btn-glass btn-sm dropdown-toggle" data-bs-toggle="dropdown">Manage</button>
    <ul class="dropdown-menu">
    <li><button class="dropdown-item" onclick="openWindow('client_overview','${uid}')">Open account window</button></li>
    <li><button class="dropdown-item" onclick="promptAdjustBalance('${uid}')">Adjust balances</button></li>
    ${uid !== 'admin' ? `<li><button class="dropdown-item" onclick="toggleUserStatus('${uid}')">${u.status === 'active' ? 'Close user' : 'Reopen user'}</button></li>` : ''}
    ${uid !== 'admin' ? `<li><button class="dropdown-item text-danger" onclick="deleteUser('${uid}')">Delete user</button></li>` : ''}
    </ul>
    </div>
    </td>
    </tr>`;
  }).join('');
}

function renderClientDashboard(){
  const user = getUser(currentUser) || { name: currentUser };
  const bal = getBalance(currentUser);
  document.getElementById('client-welcome-name').textContent = `Welcome, ${user.name || currentUser}`;
  document.getElementById('dash-personal-bal').textContent = money(bal.personal);
  document.getElementById('dash-staging-bal').textContent = money(bal.staging);
  document.getElementById('client-total-due').textContent = money(totalOpenBills(currentUser));
  document.getElementById('client-account-number').textContent = user.accountNumber ? `Account # ${user.accountNumber}` : 'Account # pending';
  document.getElementById('client-ledger-feed').innerHTML = ledgerItemsForUser(currentUser).slice(0, 12).map(ledgerRow).join('') || '<div class="text-soft">No activity yet.</div>';
}

function renderAdminDashboard(){
  document.getElementById('admin-total-checking').textContent = money(adminTotalChecking());
  document.getElementById('admin-total-staging').textContent = money(adminTotalStaging());
  document.getElementById('admin-open-bills-total').textContent = money(Object.values(bills).filter(b => b.status === 'open').reduce((sum,b)=>sum + Number(b.amount || 0), 0));
  document.getElementById('admin-master-balance').textContent = money(getBalance('admin').personal);
  renderAdminUsers();
  const ledgerItems = Object.values(ledger).sort((a,b)=>new Date(b.createdAt||0)-new Date(a.createdAt||0));
  document.getElementById('ledger-count').textContent = `${ledgerItems.length} entries`;
  document.getElementById('admin-ledger-feed').innerHTML = ledgerItems.slice(0, 16).map(ledgerRow).join('') || '<div class="text-soft">No activity yet.</div>';
  const cfg = appSettings();
  document.getElementById('integration-name').textContent = cfg.systemName || 'Home Financial Center';
  document.getElementById('routing-prefix-label').textContent = cfg.routingPrefix || 'HFC';
  document.getElementById('webhook-label').textContent = cfg.webhookUrl || 'Not configured';
}

function render(){
  renderUserOptions();
  if (currentUser && getUser(currentUser)?.role === 'admin') renderAdminDashboard();
  if (currentUser && getUser(currentUser)?.role === 'client') renderClientDashboard();
}

function promptAdjustBalance(userId){
  const user = getUser(userId);
  document.getElementById('adjust-user-id').value = userId;
  document.getElementById('adjust-user-label').value = `${user?.name || userId} (${userId})`;
  document.getElementById('adjust-amount').value = '';
  adjustBalanceModal().show();
}

function bindEvents(){
  document.getElementById('login-btn').addEventListener('click', authenticateUser);
  document.getElementById('login-user').addEventListener('keyup', e => { if (e.key === 'Enter') authenticateUser(); });
  document.getElementById('login-pin').addEventListener('keyup', e => { if (e.key === 'Enter') authenticateUser(); });
  document.getElementById('logout-btn').addEventListener('click', logoutUser);
  document.getElementById('open-create-client-modal').addEventListener('click', () => clientModal().show());
  document.getElementById('open-create-bill-modal-admin').addEventListener('click', () => billModal().show());
  document.getElementById('open-create-bill-modal-admin-2').addEventListener('click', () => billModal().show());
  document.getElementById('open-create-bill-modal-client').addEventListener('click', () => {
    renderUserOptions();
    billModal().show();
  });
  document.getElementById('open-transfer-modal').addEventListener('click', () => transferModal().show());
  document.getElementById('save-client-btn').addEventListener('click', createUser);
  document.getElementById('save-bill-btn').addEventListener('click', recordBill);
  document.getElementById('save-transfer-btn').addEventListener('click', saveTransfer);
  document.getElementById('save-adjust-balance-btn').addEventListener('click', adjustBalance);
  document.getElementById('open-adjust-admin-balance').addEventListener('click', () => promptAdjustBalance('admin'));
  document.getElementById('open-integration-modal').addEventListener('click', () => {
    const cfg = appSettings();
    document.getElementById('integration-system-name').value = cfg.systemName || '';
    document.getElementById('integration-routing-prefix').value = cfg.routingPrefix || 'HFC';
    document.getElementById('integration-webhook-url').value = cfg.webhookUrl || '';
    document.getElementById('integration-mode').value = cfg.mode || 'manual';
    document.getElementById('integration-notes').value = cfg.notes || '';
    integrationModal().show();
  });
  document.getElementById('save-integration-btn').addEventListener('click', saveIntegration);
  document.getElementById('user-search').addEventListener('input', renderAdminUsers);

  document.querySelectorAll('[data-open-window]').forEach(el => {
    el.addEventListener('click', () => {
      const kind = el.dataset.openWindow;
      const targetUser = kind.startsWith('admin_') ? 'admin' : currentUser;
      openWindow(kind, targetUser);
    });
  });
}

function restoreSession(){
  const saved = localStorage.getItem(SESSION_KEY);
  if (saved && users[saved] && users[saved].status === 'active') setSession(saved);
}

window.openWindow = openWindow;
window.promptAdjustBalance = promptAdjustBalance;
window.toggleUserStatus = toggleUserStatus;
window.deleteUser = deleteUser;
window.payBill = payBill;

async function init(){
  bindEvents();

  db.ref('users').on('value', snap => { users = snap.val() || {}; if (!users.admin) bootstrapAdmin(); if (!currentUser) restoreSession(); render(); });
  db.ref('balances').on('value', snap => { balances = snap.val() || {}; render(); });
  db.ref('bills').on('value', snap => { bills = snap.val() || {}; render(); });
  db.ref('ledger').on('value', snap => { ledger = snap.val() || {}; render(); });
  db.ref('settings').on('value', snap => { settings = snap.val() || {}; bootstrapAdmin(); render(); });
}

init();
