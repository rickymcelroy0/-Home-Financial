# Home Financial Center

This version is set up with the exact filenames:

- `index.html`
- `script.js`
- `account.html`
- `account.js`

## What changed

- admin is now the treasury control center
- treasury reserve is the source account for admin-to-user funding
- admin can transfer treasury funds into any user's checking or staging balance
- all bills are created and reviewed in the admin bill control center
- users can still add bills and pay their own bills
- bill payments are deducted from staging and written to the ledger
- users can be opened, closed, and deleted by the administrator
- system-generated account numbers are created automatically for new users
- dedicated account windows still work for dashboard tiles
- account windows now include administrator treasury views

## Database paths used

- `users/`
- `balances/`
- `bills/`
- `ledger/`
- `system/treasury/reserve`

## Notes

- default administrator login is `admin / 0000`
- this is still a client-side Firebase app
- for real production use, add strict Firebase security rules and move sensitive operations server-side
- the current web config uses the Realtime Database URL and inferred project fields only
- if your Firebase project requires the full config, add `apiKey`, `appId`, and `messagingSenderId`
