const firebaseConfig = {
  databaseURL: 'https://homefund-3b81a-default-rtdb.firebaseio.com/',
  projectId: 'homefund-3b81a',
  authDomain: 'homefund-3b81a.firebaseapp.com',
  storageBucket: 'homefund-3b81a.appspot.com'
};
if (!firebase.apps.length) firebase.initializeApp(firebaseConfig);
const db = firebase.database();

const SESSION_KEY = 'hfc_session_v2';
const params = new URLSearchParams(window.location.search);
const kind = params.get('kind') || 'checking';
const userId = params.get('user') || 'admin';
const sessionUser = localStorage.getItem(SESSION_KEY) || 'admin';

let users = {}, balances = {}, bills = {}, ledger = {}, system = { treasury: { reserve: 0 } };

const money = (n) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(Number(n || 0));
const number = (n) => Number(Number(n || 0).toFixed(2));
const sortNewest = (arr) => [...arr].sort((a,b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
const isAdmin = () => users[sessionUser]?.role === 'admin';

// Protect private ledger items from the admin
const ledgerItemsForUser = (uid) => sortNewest(Object.values(ledger).filter((x) => x.userId === uid && (!isAdmin() || !x.isPrivate)));

// Filter out private bills if an admin is looking
const visibleBills = () => Object.entries(bills).filter(([_, b]) => !isAdmin() || !b.isPrivate);
const openBillsForUser = (uid) => visibleBills().filter(([_, b]) => b.userId === uid && b.status === 'open');
const paidBillsForUser = (uid) => visibleBills().filter(([_, b]) => b.userId === uid && b.status === 'paid');


function renderSummary(cards){
  document.getElementById('summary-row').innerHTML = cards.map((card) => `
  <div class="col-md-4"><div class="mini h-100"><div class="label">${card.label}</div><div class="hero mt-2">${card.value}</div></div></div>`).join('');
}

function renderLedger(items){
  const pane = document.getElementById('ledger-pane');
  if (!items.length) return pane.innerHTML = `<div class="text-muted">No activity yet.</div>`;
  pane.innerHTML = items.slice(0,20).map((item) => `<div class="list-row"><div><div class="fw-semibold">${item.title || 'Activity'} ${item.isPrivate ? '<span class="private-badge ms-2"><i class="fa-solid fa-lock"></i></span>' : ''}</div><div class="small text-muted">${item.description || ''}</div></div><div class="text-end"><div class="fw-semibold">${item.amount != null ? money(item.amount) : ''}</div><div class="small text-muted">${new Date(item.createdAt || Date.now()).toLocaleString()}</div></div></div>`).join('');
}

function renderTable(headers, rows){
  return `<div class="table-responsive"><table class="table align-middle mb-0"><thead><tr>${headers.map((h) => `<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.length ? rows.join('') : `<tr><td colspan="${headers.length}" class="text-muted">No records.</td></tr>`}</tbody></table></div>`;
}

async function payBill(billId){
  const bill = bills[billId];
  if (!bill || bill.status !== 'open') return alert('Bill is not open.');
  if (!isAdmin() && sessionUser !== bill.userId) return alert('You cannot pay this bill.');

  const amount = number(bill.amount);
  const stagingKey = bill.isPrivate ? 'privateStaging' : 'staging';

  const debit = await db.ref(`balances/${bill.userId}/${stagingKey}`).transaction((cur) => {
    cur = number(cur);
    if (cur < amount) return;
    return number(cur - amount);
  });

  if (!debit.committed) return alert(`Not enough funds in ${bill.isPrivate ? 'Private Vault' : 'Bill Staging'}.`);

  await db.ref(`bills/${billId}`).update({ status: 'paid', paidAt: new Date().toISOString(), paidBy: sessionUser });
  await db.ref('ledger').push({ type:'bill_paid', userId: bill.userId, amount, title:'Bill paid', description:`${bill.name} paid from ${bill.isPrivate ? 'Private Vault' : 'Staging'}.`, isPrivate: bill.isPrivate || false, createdAt:new Date().toISOString() });
}
window.payBill = payBill;

function render(){
  const user = users[userId] || { name:userId, role:'unknown', accountNumber:'—', status:'unknown' };
  const userBals = balances[userId] || { personal:0, staging:0, privateStaging:0 };
  const detail = document.getElementById('detail-pane');
  const subtitle = document.getElementById('window-subtitle');
  const actionBtn = document.getElementById('action-btn');
  actionBtn.classList.add('d-none');

  if (kind === 'checking'){
    document.getElementById('window-title').textContent = `${user.name} · Checking`;
    subtitle.textContent = `Account ${user.accountNumber || '—'}`;
    renderSummary([
      { label:'Checking Balance', value: money(userBals.personal) },
                  { label:'Open Bills', value: money(openBillsForUser(userId).reduce((s,[_,b]) => s + number(b.amount), 0)) },
                  { label:'Paid Bills', value: String(paidBillsForUser(userId).length) }
    ]);
    detail.innerHTML = `<div class="mb-3 text-muted">Checking holds available funds transferred from treasury or from staging.</div>` + renderTable(['Type','Description','Amount','When'], ledgerItemsForUser(userId).filter((x) => ['client_created','treasury_transfer','transfer'].includes(x.type)).slice(0,15).map((item) => `<tr><td>${item.title || item.type} ${item.isPrivate ? '<span class="private-badge ms-2"><i class="fa-solid fa-lock"></i></span>' : ''}</td><td>${item.description || ''}</td><td>${item.amount != null ? money(item.amount) : ''}</td><td>${new Date(item.createdAt || Date.now()).toLocaleString()}</td></tr>`));
    renderLedger(ledgerItemsForUser(userId));
    return;
  }

  if (kind === 'staging'){
    document.getElementById('window-title').textContent = `${user.name} · Bill Staging`;
    subtitle.textContent = 'Reserved funds for paying public bills';
    const publicOpenBills = openBillsForUser(userId).filter(([_,b]) => !b.isPrivate);
    renderSummary([
      { label:'Staging Balance', value: money(userBals.staging) },
                  { label:'Open Public Bills', value: String(publicOpenBills.length) },
                  { label:'Coverage Delta', value: money(userBals.staging - publicOpenBills.reduce((s,[_,b]) => s + number(b.amount), 0)) }
    ]);
    detail.innerHTML = renderTable(['Bill','Due Date','Amount','Status'], publicOpenBills.map(([_,b]) => `<tr><td>${b.name}</td><td>${b.dueDate || '—'}</td><td>${money(b.amount)}</td><td>${b.status}</td></tr>`));
    renderLedger(ledgerItemsForUser(userId).filter((x) => ['transfer','bill_paid','treasury_transfer'].includes(x.type) && !x.isPrivate));
    return;
  }

  if (kind === 'private_vault'){
    document.getElementById('window-title').textContent = `${user.name} · Private Vault`;
    subtitle.textContent = 'Locked funds for your personal bills';
    const privateOpenBills = openBillsForUser(userId).filter(([_,b]) => b.isPrivate);
    renderSummary([
      { label:'Private Balance', value: money(userBals.privateStaging) },
                  { label:'Open Private Bills', value: String(privateOpenBills.length) },
                  { label:'Coverage Delta', value: money(userBals.privateStaging - privateOpenBills.reduce((s,[_,b]) => s + number(b.amount), 0)) }
    ]);
    detail.innerHTML = renderTable(['Bill','Due Date','Amount','Status'], privateOpenBills.map(([_,b]) => `<tr><td>${b.name} <span class="private-badge ms-2">Private</span></td><td>${b.dueDate || '—'}</td><td>${money(b.amount)}</td><td>${b.status}</td></tr>`));
    renderLedger(ledgerItemsForUser(userId).filter((x) => ['transfer','bill_paid'].includes(x.type) && x.isPrivate));
    return;
  }

  if (kind === 'bills'){
    document.getElementById('window-title').textContent = `${user.name} · Bills`;
    subtitle.textContent = 'Open and paid bill ledger';
    renderSummary([
      { label:'Open Bill Total', value: money(openBillsForUser(userId).reduce((s,[_,b]) => s + number(b.amount), 0)) },
                  { label:'Open Bills', value: String(openBillsForUser(userId).length) },
                  { label:'Paid Bills', value: String(paidBillsForUser(userId).length) }
    ]);
    detail.innerHTML = renderTable(['Bill','Due','Amount','Status','Action'], sortNewest(visibleBills().filter(([_,b]) => b.userId === userId)).map(([billId,b]) => `<tr><td>${b.name} ${b.isPrivate ? '<span class="private-badge ms-2"><i class="fa-solid fa-lock"></i> Private</span>' : ''}</td><td>${b.dueDate || '—'}</td><td>${money(b.amount)}</td><td>${b.status}</td><td>${b.status === 'open' && (isAdmin() || sessionUser === userId) ? `<button class="btn btn-sm btn-primary" onclick="payBill('${billId}')">Pay</button>` : ''}</td></tr>`));
    renderLedger(ledgerItemsForUser(userId).filter((x) => ['bill_created','bill_paid'].includes(x.type)));
    return;
  }

  if (kind === 'client_overview'){
    document.getElementById('window-title').textContent = `${user.name} · Client Overview`;
    subtitle.textContent = `${user.accountNumber || '—'} · ${user.status}`;
    renderSummary([
      { label:'Checking', value: money(userBals.personal) },
                  { label:'Staging', value: money(userBals.staging) },
                  { label:'Open Bills', value: money(openBillsForUser(userId).reduce((s,[_,b]) => s + number(b.amount), 0)) }
    ]);
    detail.innerHTML = `<div class="row g-3 mb-3"><div class="col-md-6"><div class="mini h-100"><div class="label">Profile</div><div class="mt-2"><strong>${user.name}</strong><div class="text-muted">${userId}</div><div class="text-muted">${user.accountNumber || '—'}</div><div class="text-muted">Status: ${user.status}</div></div></div></div><div class="col-md-6"><div class="mini h-100"><div class="label">Bill Summary</div><div class="mt-2 text-muted">${openBillsForUser(userId).length} open, ${paidBillsForUser(userId).length} paid.</div></div></div></div>` + renderTable(['Bill','Amount','Status'], sortNewest(visibleBills().filter(([_,b]) => b.userId === userId)).slice(0,10).map(([_,b]) => `<tr><td>${b.name} ${b.isPrivate ? '<span class="private-badge ms-2"><i class="fa-solid fa-lock"></i></span>' : ''}</td><td>${money(b.amount)}</td><td>${b.status}</td></tr>`));
    renderLedger(ledgerItemsForUser(userId));
    return;
  }

  if (kind === 'admin_treasury'){
    document.getElementById('window-title').textContent = `Administrator · Treasury`;
    subtitle.textContent = 'Master source account and public bill center';
    renderSummary([
      { label:'Treasury Reserve', value: money(system?.treasury?.reserve) },
                  { label:'Open Bills', value: String(Object.values(bills).filter((b) => b.status === 'open' && !b.isPrivate).length) },
                  { label:'Open Bill Total', value: money(Object.values(bills).filter((b) => b.status === 'open' && !b.isPrivate).reduce((s,b) => s + number(b.amount), 0)) }
    ]);
    detail.innerHTML = renderTable(['Client','Bill','Due','Amount','Status'], sortNewest(visibleBills()).map(([_,b]) => `<tr><td>${users[b.userId]?.name || b.userId}</td><td>${b.name}</td><td>${b.dueDate || '—'}</td><td>${money(b.amount)}</td><td>${b.status}</td></tr>`));
    renderLedger(sortNewest(Object.values(ledger)).filter((x) => ['treasury_funded','treasury_transfer','bill_created','bill_paid'].includes(x.type) && !x.isPrivate));
    return;
  }

  if (kind === 'admin_global_cash'){
    document.getElementById('window-title').textContent = 'Administrator · User Checking';
    subtitle.textContent = 'Every user checking account';
    renderSummary([
      { label:'Total Checking', value: money(Object.values(balances).reduce((s,b) => s + number(b.personal), 0)) },
                  { label:'Accounts', value: String(Object.keys(users).length) },
                  { label:'Clients', value: String(Object.values(users).filter((u) => u.role === 'client').length) }
    ]);
    detail.innerHTML = renderTable(['User','Account Number','Checking'], Object.entries(users).filter(([_,u]) => u.role === 'client').map(([uid,u]) => `<tr><td>${u.name}</td><td>${u.accountNumber || '—'}</td><td>${money(balances[uid]?.personal || 0)}</td></tr>`));
    renderLedger(sortNewest(Object.values(ledger)).filter((x) => ['treasury_transfer','transfer'].includes(x.type) && !x.isPrivate));
    return;
  }

  if (kind === 'admin_global_staging'){
    document.getElementById('window-title').textContent = 'Administrator · User Staging';
    subtitle.textContent = 'Every reserved public bill balance';
    renderSummary([
      { label:'Total Staging', value: money(Object.values(balances).reduce((s,b) => s + number(b.staging), 0)) },
                  { label:'Open Public Bills', value: String(Object.values(bills).filter((b) => b.status === 'open' && !b.isPrivate).length) },
                  { label:'Paid Public Bills', value: String(Object.values(bills).filter((b) => b.status === 'paid' && !b.isPrivate).length) }
    ]);
    detail.innerHTML = renderTable(['User','Staging','Open Bill Total'], Object.entries(users).filter(([_,u]) => u.role === 'client').map(([uid,u]) => `<tr><td>${u.name}</td><td>${money(balances[uid]?.staging || 0)}</td><td>${money(openBillsForUser(uid).reduce((s,[_,b]) => s + number(b.amount), 0))}</td></tr>`));
    renderLedger(sortNewest(Object.values(ledger)).filter((x) => ['treasury_transfer','bill_paid','transfer'].includes(x.type) && !x.isPrivate));
    return;
  }

  if (kind === 'admin_open_bills'){
    document.getElementById('window-title').textContent = 'Administrator · Open Bills';
    subtitle.textContent = 'System-wide public bill queue';
    const publicOpen = visibleBills().filter(([_, b]) => b.status === 'open');
    renderSummary([
      { label:'Open Bill Total', value: money(publicOpen.reduce((s,[_,b]) => s + number(b.amount), 0)) },
                  { label:'Open Bills', value: String(publicOpen.length) },
                  { label:'Paid Bills', value: String(visibleBills().filter(([_,b]) => b.status === 'paid').length) }
    ]);
    detail.innerHTML = renderTable(['Client','Bill','Due','Amount','Status'], sortNewest(visibleBills()).map(([billId,b]) => `<tr><td>${users[b.userId]?.name || b.userId}</td><td>${b.name}</td><td>${b.dueDate || '—'}</td><td>${money(b.amount)}</td><td>${b.status}${b.status === 'open' ? ` <button class="btn btn-sm btn-primary ms-2" onclick="payBill('${billId}')">Pay</button>` : ''}</td></tr>`));
    renderLedger(sortNewest(Object.values(ledger)).filter((x) => ['bill_created','bill_paid'].includes(x.type) && !x.isPrivate));
    return;
  }
}

db.ref('users').on('value', (snap) => { users = snap.val() || {}; render(); });
db.ref('balances').on('value', (snap) => { balances = snap.val() || {}; render(); });
db.ref('bills').on('value', (snap) => { bills = snap.val() || {}; render(); });
db.ref('ledger').on('value', (snap) => { ledger = snap.val() || {}; render(); });
db.ref('system').on('value', (snap) => { system = snap.val() || { treasury: { reserve: 0 } }; render(); });
