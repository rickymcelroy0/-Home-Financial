const firebaseConfig = {
  databaseURL: 'https://homefund-3b81a-default-rtdb.firebaseio.com/',
  projectId: 'homefund-3b81a',
  authDomain: 'homefund-3b81a.firebaseapp.com',
  storageBucket: 'homefund-3b81a.appspot.com'
};
if (!firebase.apps.length) firebase.initializeApp(firebaseConfig);
const db = firebase.database();

const ADMIN_USER = 'admin';
const ADMIN_PIN = '0000';
const SESSION_KEY = 'hfc_session_v2';

let currentUser = null;
let users = {};
let balances = {};
let bills = {};
let ledger = {};
let system = { treasury: { reserve: 0 } };

let clientModal, billModal, privateBillModal, transferModal, treasuryFundModal;

const $ = (id) => document.getElementById(id);
const money = (n) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(Number(n || 0));
const number = (n) => Number(Number(n || 0).toFixed(2));
const nowIso = () => new Date().toISOString();
const sortNewest = (arr) => [...arr].sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));

// Bill Filters
const openBillsForUser = (uid) => Object.entries(bills).filter(([_, b]) => b.userId === uid && b.status === 'open');
const paidBillsForUser = (uid) => Object.entries(bills).filter(([_, b]) => b.userId === uid && b.status === 'paid');
const publicBills = () => Object.entries(bills).filter(([_, b]) => !b.isPrivate);

const ledgerItemsForUser = (uid) => sortNewest(Object.values(ledger).filter((x) => x.userId === uid));
const activeClientEntries = () => Object.entries(users).filter(([uid, u]) => uid !== ADMIN_USER && u.role === 'client');

function showToast(msg, type = 'info') {
  const container = $('toast-container');
  const toast = document.createElement('div');
  const map = { success: 'success', danger: 'danger', warning: 'warning', info: 'primary' };
  toast.className = `alert alert-${map[type] || 'primary'} shadow-sm border-0 mb-2`;
  toast.style.borderRadius = '16px';
  if(type === 'warning' && msg.includes('Private')) {
    toast.style.background = 'linear-gradient(135deg, #a78bfa, #8b5cf6)';
    toast.style.color = 'white';
  }
  toast.innerHTML = msg;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 3200);
}

function showLoginError(msg) {
  const err = $('login-err');
  err.textContent = msg;
  err.classList.remove('d-none');
}

function clearLoginError() {
  $('login-err').classList.add('d-none');
}

function ensureAdminBootstrap() {
  const updates = {};
  if (!users[ADMIN_USER]) {
    updates['users/admin'] = {
      username: 'admin',
      name: 'System Administrator',
      pin: ADMIN_PIN,
      role: 'admin',
      status: 'active',
      accountNumber: 'TRSY-000001',
      createdAt: nowIso()
    };
  }
  if (!balances[ADMIN_USER]) updates['balances/admin'] = { personal: 0, staging: 0, privateStaging: 0 };
  if (system?.treasury?.reserve == null) updates['system/treasury/reserve'] = 0;
  if (Object.keys(updates).length) db.ref().update(updates);
}

function generateAccountNumber() {
  const existing = new Set(Object.values(users).map((u) => u.accountNumber).filter(Boolean));
  let candidate = '';
  do {
    const digits = String(Math.floor(10000000 + Math.random() * 90000000));
    candidate = `HFC-${digits}`;
  } while (existing.has(candidate));
  return candidate;
}

function setSession(uid) {
  localStorage.setItem(SESSION_KEY, uid);
}

function clearSession() {
  localStorage.removeItem(SESSION_KEY);
}

function authenticateUser() {
  const rawUser = $('login-user').value.trim().toLowerCase();
  const pin = $('login-pin').value.trim();
  if (!rawUser || !pin) return showLoginError('Enter a username and PIN.');

  const user = users[rawUser];
  const valid = user && user.pin === pin && user.status === 'active';
  const adminBootstrap = rawUser === ADMIN_USER && pin === ADMIN_PIN;

  if (!valid && !adminBootstrap) return showLoginError('Authentication failed.');

  currentUser = rawUser;
  setSession(rawUser);
  clearLoginError();
  $('login-pin').value = '';
  $('login-wrapper').style.display = 'none';
  $('app-wrapper').style.display = 'block';
  renderAll();
  startClock();
  showToast(`Session established for <strong>${rawUser}</strong>.`, 'success');
}

function logoutUser() {
  currentUser = null;
  clearSession();
  $('app-wrapper').style.display = 'none';
  $('login-wrapper').style.display = 'flex';
  $('login-user').value = '';
  $('login-pin').value = '';
}

function startClock() {
  if (window.__hfcClockStarted) return;
  window.__hfcClockStarted = true;
  setInterval(() => { $('clockTime').textContent = new Date().toLocaleTimeString([], { hour12: false }); }, 1000);
}

function isAdmin() {
  return currentUser && users[currentUser]?.role === 'admin';
}

function renderView() {
  document.querySelectorAll('.view').forEach((v) => v.classList.remove('active'));
  if (!currentUser) return;
  $('session-user-label').textContent = `${users[currentUser]?.name || currentUser} · ${users[currentUser]?.role || ''}`;
  if (isAdmin()) $('view-admin').classList.add('active');
  else $('view-client').classList.add('active');
}

function ledgerRowHTML(item) {
  return `<div class="list-row"><div><div class="fw-semibold">${item.title || 'Activity'} ${item.isPrivate ? '<span class="private-badge ms-2"><i class="fa-solid fa-lock"></i></span>' : ''}</div><div class="small muted">${item.description || ''}</div></div><div class="text-end"><div class="fw-semibold">${item.amount != null ? money(item.amount) : ''}</div><div class="small muted">${new Date(item.createdAt || Date.now()).toLocaleString()}</div></div></div>`;
}

function billRowHTML([billId, bill], includePay = false) {
  const user = users[bill.userId] || {};
  const canPay = includePay && bill.status === 'open';
  const badge = bill.isPrivate ? `<span class="private-badge ms-2"><i class="fa-solid fa-lock"></i> Private</span>` : '';

  return `<div class="list-row">
  <div>
  <div class="fw-semibold">${bill.name} ${badge}</div>
  <div class="small muted">${user.name || bill.userId} · due ${bill.dueDate || '—'} · ${bill.status}</div>
  </div>
  <div class="text-end">
  <div class="fw-semibold">${money(bill.amount)}</div>
  ${canPay ? `<button class="btn btn-sm btn-primary mt-2" onclick="payBill('${billId}')">Pay Bill</button>` : ''}
  </div>
  </div>`;
}

function renderAdmin() {
  const treasuryReserve = number(system?.treasury?.reserve);
  const checkingTotal = Object.values(balances).reduce((sum, b) => sum + number(b.personal), 0);
  const stagingTotal = Object.values(balances).reduce((sum, b) => sum + number(b.staging), 0);

  // Admin ONLY sees public bills in totals
  const openTotal = publicBills().filter(([_, b]) => b.status === 'open').reduce((sum, [_, b]) => sum + number(b.amount), 0);

  $('treasury-balance').textContent = money(treasuryReserve);
  $('admin-total-cash').textContent = money(checkingTotal);
  $('admin-total-staging').textContent = money(stagingTotal);
  $('admin-open-bills-total').textContent = money(openTotal);

  const userBody = $('adminUsersBody');
  userBody.innerHTML = activeClientEntries().map(([uid, u]) => {
    const b = balances[uid] || { personal: 0, staging: 0 };
    return `<tr>
    <td>
    <div class="fw-semibold">${u.name}</div>
    <div class="small muted mono">${uid} · ${u.accountNumber || 'pending'}</div>
    </td>
    <td>${money(b.personal)}</td>
    <td>${money(b.staging)}</td>
    <td><span class="pill ${u.status === 'active' ? 'status-active' : 'status-closed'}">${u.status}</span></td>
    <td>
    <div class="d-flex flex-wrap gap-2">
    <button class="btn btn-sm btn-outline-primary" onclick="openAccountWindow('client_overview','${uid}')">Open</button>
    <button class="btn btn-sm btn-outline-secondary" onclick="toggleUserStatus('${uid}')">${u.status === 'active' ? 'Close' : 'Open'}</button>
    <button class="btn btn-sm btn-outline-danger" onclick="deleteUser('${uid}')">Delete</button>
    </div>
    </td>
    </tr>`;
  }).join('') || `<tr><td colspan="5" class="muted">No client accounts yet.</td></tr>`;

  // Filter out any private activity from admin ledger view
  const publicLedger = Object.values(ledger).filter(x => !x.isPrivate);
  $('admin-ledger-feed').innerHTML = sortNewest(publicLedger).slice(0, 10).map(ledgerRowHTML).join('') || `<div class="muted">No activity yet.</div>`;

  $('bill-control-feed').innerHTML = sortNewest(publicBills().filter(([_, b]) => b.status === 'open').map(([id, b]) => ({ id, ...b })))
  .slice(0, 8)
  .map((b) => billRowHTML([b.id, b], false))
  .join('') || `<div class="muted">No open bills.</div>`;
}

function renderClient() {
  const user = users[currentUser] || {};
  const b = balances[currentUser] || { personal: 0, staging: 0, privateStaging: 0 };

  const openBillEntries = openBillsForUser(currentUser);
  const totalDue = openBillEntries.reduce((sum, [_, bill]) => sum + number(bill.amount), 0);

  $('client-welcome-name').textContent = `Welcome, ${user.name || currentUser}`;
  $('dash-personal-bal').textContent = money(b.personal);
  $('dash-staging-bal').textContent = money(b.staging);
  $('dash-private-bal').textContent = money(b.privateStaging);
  $('client-total-due').textContent = money(totalDue);

  $('client-ledger-feed').innerHTML = ledgerItemsForUser(currentUser).slice(0, 10).map(ledgerRowHTML).join('') || `<div class="muted">No activity yet.</div>`;
  $('client-bill-feed').innerHTML = openBillEntries.map((entry) => billRowHTML(entry, true)).join('') || `<div class="muted">No open bills.</div>`;
}

function populateUserSelects() {
  const options = activeClientEntries().map(([uid, u]) => `<option value="${uid}">${u.name} (${uid})</option>`).join('');
  $('bill-user').innerHTML = options;
  $('treasury-user').innerHTML = options;
}

function renderAll() {
  ensureAdminBootstrap();
  renderView();
  populateUserSelects();
  if (isAdmin()) renderAdmin();
  else renderClient();
}

function openAccountWindow(kind, uid = currentUser) {
  window.open(`account.html?kind=${encodeURIComponent(kind)}&user=${encodeURIComponent(uid)}`, '_blank', 'width=1120,height=820,resizable=yes');
}

function createLedgerEntry(entry) {
  return db.ref('ledger').push({ createdAt: nowIso(), ...entry });
}

async function createClient() {
  const username = $('new-client-username').value.trim().toLowerCase();
  const name = $('new-client-name').value.trim();
  const pin = $('new-client-pin').value.trim();
  const opening = number($('new-client-opening').value);

  if (!username || !name || !pin) return showToast('Complete every client field.', 'warning');
  if (users[username]) return showToast('That username already exists.', 'danger');

  const accountNumber = generateAccountNumber();
  const updates = {};
  updates[`users/${username}`] = { username, name, pin, role: 'client', status: 'active', accountNumber, createdAt: nowIso() };
  updates[`balances/${username}`] = { personal: 0, staging: 0, privateStaging: 0 };
  await db.ref().update(updates);

  await createLedgerEntry({ type: 'client_created', userId: username, amount: 0, title: 'Client created', description: `${name} created with account ${accountNumber}.` });
  if (opening > 0) await transferFromTreasury(username, 'personal', opening, 'Opening deposit');

  clientModal.hide();
  ['new-client-username', 'new-client-name', 'new-client-pin', 'new-client-opening'].forEach((id) => $(id).value = id === 'new-client-opening' ? '0' : '');
  showToast('Client account created.', 'success');
}

async function toggleUserStatus(uid) {
  const user = users[uid];
  if (!user) return;
  const newStatus = user.status === 'active' ? 'closed' : 'active';
  await db.ref(`users/${uid}/status`).set(newStatus);
  await createLedgerEntry({ type: 'user_status_changed', userId: uid, title: `User ${newStatus}`, description: `${users[currentUser]?.name || currentUser} changed ${uid} to ${newStatus}.` });
  showToast(`User ${newStatus}.`, 'success');
}

async function deleteUser(uid) {
  if (!confirm(`Delete ${uid}? This removes balances, bills, and the user record.`)) return;
  const batch = {};
  batch[`users/${uid}`] = null;
  batch[`balances/${uid}`] = null;
  Object.entries(bills).forEach(([billId, bill]) => { if (bill.userId === uid) batch[`bills/${billId}`] = null; });
  await db.ref().update(batch);
  await createLedgerEntry({ type: 'user_deleted', userId: uid, title: 'User deleted', description: `${users[currentUser]?.name || currentUser} deleted ${uid}.` });
  showToast('User deleted.', 'warning');
}

async function fundTreasury() {
  const amount = number($('treasury-fund-amount').value);
  const memo = $('treasury-fund-note').value.trim() || 'Treasury funded';
  if (amount <= 0) return showToast('Enter an amount to fund treasury.', 'warning');
  await db.ref('system/treasury/reserve').transaction((cur) => number(cur) + amount);
  await createLedgerEntry({ type: 'treasury_funded', userId: ADMIN_USER, amount, title: 'Treasury funded', description: memo });
  treasuryFundModal.hide();
  $('treasury-fund-amount').value = '';
  $('treasury-fund-note').value = '';
  showToast('Treasury reserve increased.', 'success');
}

async function transferFromTreasury(uid, destination, amount, memo) {
  amount = number(amount);
  if (!uid || amount <= 0) return showToast('Choose a user and valid amount.', 'warning');
  const reserve = number(system?.treasury?.reserve);
  if (reserve < amount) return showToast('Treasury reserve is too low.', 'danger');

  const reserveResult = await db.ref('system/treasury/reserve').transaction((cur) => {
    cur = number(cur);
    if (cur < amount) return;
    return number(cur - amount);
  });
  if (!reserveResult.committed) return showToast('Treasury transfer could not be completed.', 'danger');

  await db.ref(`balances/${uid}/${destination}`).transaction((cur) => number(cur) + amount);
  await createLedgerEntry({
    type: 'treasury_transfer',
    userId: uid,
    amount,
    title: 'Treasury transfer',
    description: `${users[currentUser]?.name || currentUser} transferred ${money(amount)} from treasury into ${destination} for ${users[uid]?.name || uid}. ${memo || ''}`.trim()
  });
  showToast('Treasury transfer complete.', 'success');
}

async function executeTreasuryTransfer() {
  return transferFromTreasury($('treasury-user').value, $('treasury-destination').value, $('treasury-amount').value, $('treasury-note').value.trim());
}

async function createBill() {
  const userId = isAdmin() ? $('bill-user').value : currentUser;
  const name = $('bill-name').value.trim();
  const amount = number($('bill-amount').value);
  const dueDate = $('bill-due-date').value;
  if (!userId || !name || amount <= 0) return showToast('Enter a client, bill name, and amount.', 'warning');

  const ref = db.ref('bills').push();
  await ref.set({ userId, name, amount, dueDate: dueDate || '', status: 'open', isPrivate: false, createdAt: nowIso(), createdBy: currentUser });
  await createLedgerEntry({ type: 'bill_created', userId, amount, title: 'Bill recorded', description: `${name} was recorded${dueDate ? ` with due date ${dueDate}` : ''}.` });

  billModal.hide();
  ['bill-name', 'bill-amount', 'bill-due-date'].forEach((id) => $(id).value = '');
  showToast('Public bill recorded.', 'success');
}

async function createPrivateBill() {
  const userId = currentUser;
  const name = $('private-bill-name').value.trim();
  const amount = number($('private-bill-amount').value);
  const dueDate = $('private-bill-due-date').value;

  if (!name || amount <= 0) return showToast('Enter a bill name and amount.', 'warning');

  const ref = db.ref('bills').push();
  await ref.set({ userId, name, amount, dueDate: dueDate || '', status: 'open', isPrivate: true, createdAt: nowIso(), createdBy: currentUser });

  await createLedgerEntry({ type: 'bill_created', userId, amount, title: 'Private Bill created', description: `${name} was saved to your private ledger.`, isPrivate: true });

  privateBillModal.hide();
  ['private-bill-name', 'private-bill-amount', 'private-bill-due-date'].forEach((id) => $(id).value = '');
  showToast('Private bill locked and saved.', 'warning');
}

async function transferBetweenClientBalances() {
  const direction = $('transfer-direction').value;
  const amount = number($('transfer-amount').value);
  const note = $('transfer-note').value.trim() || 'Internal balance transfer';
  if (amount <= 0) return showToast('Enter a valid transfer amount.', 'warning');

  let fromKey, toKey;
  if (direction === 'personal_to_staging') { fromKey = 'personal'; toKey = 'staging'; }
  else if (direction === 'staging_to_personal') { fromKey = 'staging'; toKey = 'personal'; }
  else if (direction === 'personal_to_private') { fromKey = 'personal'; toKey = 'privateStaging'; }
  else if (direction === 'private_to_personal') { fromKey = 'privateStaging'; toKey = 'personal'; }

  const fromBal = number(balances[currentUser]?.[fromKey]);
  if (fromBal < amount) return showToast(`Insufficient funds in ${fromKey}.`, 'danger');

  const debit = await db.ref(`balances/${currentUser}/${fromKey}`).transaction((cur) => {
    cur = number(cur);
    if (cur < amount) return;
    return number(cur - amount);
  });
  if (!debit.committed) return showToast('Transfer failed.', 'danger');

  await db.ref(`balances/${currentUser}/${toKey}`).transaction((cur) => number(cur) + amount);

  const isPrivate = toKey === 'privateStaging' || fromKey === 'privateStaging';

  await createLedgerEntry({
    type: 'transfer',
    userId: currentUser,
    amount,
    title: 'Internal transfer',
    description: `${money(amount)} moved from ${fromKey} to ${toKey}. ${note}`,
                          isPrivate: isPrivate
  });

  transferModal.hide();
  $('transfer-amount').value = '';
  $('transfer-note').value = '';
  showToast('Transfer complete.', 'success');
}

async function payBill(billId) {
  const bill = bills[billId];
  if (!bill || bill.status !== 'open') return showToast('This bill is no longer open.', 'warning');
  if (!isAdmin() && bill.userId !== currentUser) return showToast('You cannot pay this bill.', 'danger');

  const amount = number(bill.amount);
  const stagingKey = bill.isPrivate ? 'privateStaging' : 'staging';
  const stagingRef = db.ref(`balances/${bill.userId}/${stagingKey}`);

  const debit = await stagingRef.transaction((cur) => {
    cur = number(cur);
    if (cur < amount) return;
    return number(cur - amount);
  });
  if (!debit.committed) return showToast(`Not enough funds in your ${bill.isPrivate ? 'Private Vault' : 'Bill Staging'} to pay this.`, 'danger');

  await db.ref(`bills/${billId}`).update({ status: 'paid', paidAt: nowIso(), paidBy: currentUser });
  await createLedgerEntry({
    type: 'bill_paid',
    userId: bill.userId,
    amount,
    title: 'Bill paid',
    description: `${bill.name} paid from ${bill.isPrivate ? 'Private Vault' : 'Staging'}.`,
    isPrivate: bill.isPrivate || false
  });
  showToast('Bill paid and recorded in ledger.', 'success');
}

window.payBill = payBill;
window.toggleUserStatus = toggleUserStatus;
window.deleteUser = deleteUser;
window.openAccountWindow = openAccountWindow;

function bindEvents() {
  $('login-btn').addEventListener('click', authenticateUser);
  $('logout-btn').addEventListener('click', logoutUser);
  $('login-pin').addEventListener('keydown', (e) => e.key === 'Enter' && authenticateUser());
  $('open-create-client-modal').addEventListener('click', () => clientModal.show());
  $('open-create-bill-modal-admin').addEventListener('click', () => billModal.show());
  $('open-create-bill-modal-client').addEventListener('click', () => billModal.show());
  $('open-create-private-bill-modal').addEventListener('click', () => privateBillModal.show());
  $('open-transfer-modal').addEventListener('click', () => transferModal.show());
  $('open-treasury-fund-modal').addEventListener('click', () => treasuryFundModal.show());

  $('save-client-btn').addEventListener('click', createClient);
  $('save-bill-btn').addEventListener('click', createBill);
  $('save-private-bill-btn').addEventListener('click', createPrivateBill);
  $('save-transfer-btn').addEventListener('click', transferBetweenClientBalances);
  $('save-treasury-fund-btn').addEventListener('click', fundTreasury);
  $('execute-treasury-transfer').addEventListener('click', executeTreasuryTransfer);
  document.querySelectorAll('.tile').forEach((tile) => tile.addEventListener('click', () => openAccountWindow(tile.dataset.openWindow)));
}

function initModals() {
  clientModal = new bootstrap.Modal($('clientModal'));
  billModal = new bootstrap.Modal($('billModal'));
  privateBillModal = new bootstrap.Modal($('privateBillModal'));
  transferModal = new bootstrap.Modal($('transferModal'));
  treasuryFundModal = new bootstrap.Modal($('treasuryFundModal'));
}

function attemptSessionRestore() {
  const saved = localStorage.getItem(SESSION_KEY);
  if (saved && users[saved]?.status === 'active') {
    currentUser = saved;
    $('login-wrapper').style.display = 'none';
    $('app-wrapper').style.display = 'block';
  }
}

function subscribe() {
  db.ref('users').on('value', (snap) => { users = snap.val() || {}; ensureAdminBootstrap(); attemptSessionRestore(); renderAll(); });
  db.ref('balances').on('value', (snap) => { balances = snap.val() || {}; renderAll(); });
  db.ref('bills').on('value', (snap) => { bills = snap.val() || {}; renderAll(); });
  db.ref('ledger').on('value', (snap) => { ledger = snap.val() || {}; renderAll(); });
  db.ref('system').on('value', (snap) => { system = snap.val() || { treasury: { reserve: 0 } }; renderAll(); });
}

initModals();
bindEvents();
subscribe();
